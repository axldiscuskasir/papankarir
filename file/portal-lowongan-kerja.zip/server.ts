import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { INITIAL_JOBS } from './src/initialJobs';
import { Job, JobApplication, InterviewSession, Message, FeedPost } from './src/types';

// Load Env
dotenv.config();

// Create Gemini Client
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
} else {
  console.warn("WARNING: GEMINI_API_KEY is not defined in the environment. AI features will fail gracefully.");
}

const app = express();
const PORT = 3000;

// Content parsing
app.use(express.json());

// Persistent database path
const DATA_FILE = path.join(process.cwd(), 'database.json');

const INITIAL_FEED_POSTS: FeedPost[] = [
  {
    id: "post-1",
    authorName: "Hendra Wijaya",
    authorTitle: "VP of Engineering @ TechNusantara",
    authorRole: "rekruter",
    type: "career_advice",
    title: "Bagaimana cara menjawab pertanyaan 'Sebutkan Kelemahan Terbesar Anda'?",
    content: "Banyak kandidat sering bingung menjawab pertanyaan ini saat wawancara teknis. Hindari jawaban klise seperti 'Saya seorang perfeksionis' atau 'Saya bekerja terlalu keras'. \n\nStrategi terbaik:\n1. Sebutkan kelemahan nyata yang tidak krusial bagi pekerjaan utama Anda.\n2. Ceritakan langkah konkret yang sedang Anda ambil untuk memperbaikinya (misalnya, mengambil kelas public speaking atau menerapkan sistem pemantau fokus harian agar lebih terorganisir).\n\nIni menunjukkan kesadaran diri (self-awareness) dan eagerness untuk terus bertumbuh secara profesional.",
    likes: ["Axl Discus", "Siti Aminah"],
    comments: [
      {
        id: "c-1",
        authorName: "Axl Discus",
        authorTitle: "Full Stack Engineer",
        content: "Tips yang sangat taktis Pak! Saya sering kesulitan membedakan antara kelemahan yang merusak reputasi dengan kelemahan yang menunjukkan kemauan belajar.",
        createdAt: "2 jam yang lalu"
      },
      {
        id: "c-2",
        authorName: "Siti Aminah",
        authorTitle: "HR Manager @ SolusiDigital",
        content: "Sangat setuju! Sebagai recruiter, kami mencari kejujuran dan kegigihan introspeksi diri pelamar, bukan jawaban klise.",
        createdAt: "1 jam yang lalu"
      }
    ],
    createdAt: "3 jam yang lalu",
    tag: "#TipsKarir"
  },
  {
    id: "post-2",
    authorName: "Siti Aminah",
    authorTitle: "HR Manager @ SolusiDigital",
    authorRole: "rekruter",
    type: "company_culture",
    title: "Mengintip Budaya Kerja Fleksibel dan Terbuka Kami",
    content: "Di SolusiDigital, kolaborasi tidak dibatasi oleh sekat-sekat meja kantor. Kami merayakan keberagaman kerja hibrida, di mana setiap kontribusi dihargai secara adil. Setiap hari Jumat sore, kami mengadakan sesi 'Share & Care' santai bertukar keahlian lintas divisi. \n\nApakah Anda mencari lingkungan kerja yang mendukung work-life integration serta pimpinan yang suportif? Cek lowongan kerja kami di tab sebelah!",
    likes: ["Hendra Wijaya"],
    comments: [],
    createdAt: "5 jam yang lalu",
    tag: "#BudayaKerja"
  },
  {
    id: "post-3",
    authorName: "Axl Discus",
    authorTitle: "Full Stack Software Engineer",
    authorRole: "kandidat",
    type: "status_update",
    content: "Baru saja menyelesaikan simulasi review CV menggunakan kecerdasan buatan (ATS) di platform Papan Karir Indonesia ini! Skor keselarasan kualifikasi saya meningkat pesat setelah menerapkan tips format resume taktis dari asisten AI. Benar-benar meningkatkan rasa percaya diri saya sebelum melamar posisi impian berikutnya.",
    likes: ["Siti Aminah", "Hendra Wijaya"],
    comments: [
      {
        id: "c-3",
        authorName: "Hendra Wijaya",
        authorTitle: "VP of Engineering @ TechNusantara",
        content: "Hebat Axl! Tetap semangat, persiapkan diri untuk tantangan selanjutnya.",
        createdAt: "20 menit yang lalu"
      }
    ],
    createdAt: "15 menit yang lalu",
    tag: "#Pencapaian"
  }
];

// Memory fallback store
let memoryDb: {
  jobs: Job[];
  applications: JobApplication[];
  interviews: InterviewSession[];
  feed: FeedPost[];
} = {
  jobs: [...INITIAL_JOBS],
  applications: [],
  interviews: [],
  feed: [...INITIAL_FEED_POSTS]
};

// Safe load helper
function loadDb() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      const data = JSON.parse(content);
      if (data.jobs && Array.isArray(data.jobs)) {
        memoryDb.jobs = data.jobs;
      }
      if (data.applications && Array.isArray(data.applications)) {
        memoryDb.applications = data.applications;
      }
      if (data.interviews && Array.isArray(data.interviews)) {
        memoryDb.interviews = data.interviews;
      }
      if (data.feed && Array.isArray(data.feed)) {
        memoryDb.feed = data.feed;
      } else {
        memoryDb.feed = [...INITIAL_FEED_POSTS];
      }
    } else {
      saveDb();
    }
  } catch (error) {
    console.error("Error loading Database, using memory fallback:", error);
  }
}

// Safe save helper
function saveDb() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(memoryDb, null, 2), 'utf-8');
  } catch (error) {
    console.error("Error writing Database, updates active in memory:", error);
  }
}

// Execute initial load
loadDb();

// ==================== API ENDPOINTS ====================

// 1. JOBS ENDPOINTS
app.get('/api/jobs', (req, res) => {
  res.json(memoryDb.jobs);
});

app.post('/api/jobs', async (req, res) => {
  try {
    const { title, company, location, type, category, salary, description, requirements, benefits, isFeatured } = req.body;
    
    if (!title || !company || !location || !type || !category || !salary) {
      return res.status(400).json({ error: "Kolom wajib diisi: title, company, location, type, category, salary" });
    }

    const newJob: Job = {
      id: `job-${Date.now()}`,
      title,
      company,
      logo: "Briefcase",
      logoBg: "bg-blue-100 text-blue-600",
      location,
      type,
      category,
      salary,
      postedAt: "Baru saja",
      description: description || "Deskripsi pekerjaan akan ditambahkan secepatnya.",
      requirements: requirements || [],
      benefits: benefits || [],
      isFeatured: !!isFeatured
    };

    memoryDb.jobs.unshift(newJob);
    saveDb();
    res.status(201).json(newJob);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/jobs/:id', (req, res) => {
  const { id } = req.params;
  const index = memoryDb.jobs.findIndex(j => j.id === id);
  if (index !== -1) {
    memoryDb.jobs.splice(index, 1);
    saveDb();
    res.json({ success: true, message: "Lowongan berhasil dihapus" });
  } else {
    res.status(404).json({ error: "Lowongan tidak ditemukan" });
  }
});

// 2. APPLICATIONS ENDPOINTS
app.get('/api/applications', (req, res) => {
  res.json(memoryDb.applications);
});

// Post Application + TRIGGER AI Auto-Review of Resume
app.post('/api/applications', async (req, res) => {
  try {
    const { jobId, candidateName, candidateEmail, candidatePhone, linkedinUrl, cvText, coverLetter } = req.body;

    if (!jobId || !candidateName || !candidateEmail || !cvText) {
      return res.status(400).json({ error: "Kolom wajib: jobId, candidateName, candidateEmail, cvText (CV Summary)" });
    }

    const job = memoryDb.jobs.find(j => j.id === jobId);
    if (!job) {
      return res.status(404).json({ error: "Pekerjaan tidak ditemukan" });
    }

    const newApp: JobApplication = {
      id: `app-${Date.now()}`,
      jobId,
      jobTitle: job.title,
      companyName: job.company,
      candidateName,
      candidateEmail,
      candidatePhone: candidatePhone || "",
      linkedinUrl: linkedinUrl || "",
      cvText,
      coverLetter: coverLetter || "",
      status: 'Terkirim',
      appliedAt: new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })
    };

    // Trigger Server-Side Gemini AI matching of CV against Job Requirements
    if (ai) {
      try {
        const prompt = `
          Anda adalah Asisten Rekrutmen Cerdas (AI AI-HRD) di Indonesia. Tugas Anda adalah melakukan review CV pelamar secara objektif terhadap lowongan pekerjaan yang dilamar.
          
          DETAIL PEKERJAAN:
          Nama Jabatan: ${job.title}
          Perusahaan: ${job.company}
          Deskripsi pekerjaan: ${job.description}
          Persyaratan: ${job.requirements.join('; ')}

          DETAIL PELAMAR:
          Nama Pelamar: ${candidateName}
          CV / Summary Keahlian & Pengalaman: ${cvText}
          Surat Pengantar (Cover Letter): ${coverLetter || "Tidak dilampirkan"}

          Tugasi skor kecocokan dalam skala 0 sampai 100 berdasarkan relevansi pengalaman, keahlian, dan persyaratannya. Berikan saran detail perbaikan.
          Return a JSON object matching this schema:
          {
            "score": <number 0-100>,
            "fitLevel": "<'Sangat Cocok' | 'Cukup Cocok' | 'Kurang Cocok'>",
            "summary": "<Ulasan singkat kecocokan pelamar dalam Bahasa Indonesia>",
            "strengths": ["<Kelebihan utama pelamar sesuai kebutuhan pekerjaan 1>", "<Kelebihan 2>", ...],
            "gaps": ["<Area yang tidak lengkap atau ketidaksesuaian kualifikasi pelamar 1>", "<Gap 2>", ...],
            "tips": ["<Saran peningkatan taktis dan konkret untuk CV/Keahlian pelamar agar peluang diterima di jabatan ini lebih tinggi>", ...]
          }
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                score: { type: Type.INTEGER },
                fitLevel: { type: Type.STRING },
                summary: { type: Type.STRING },
                strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                gaps: { type: Type.ARRAY, items: { type: Type.STRING } },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["score", "fitLevel", "summary", "strengths", "gaps", "tips"]
            }
          }
        });

        if (response.text) {
          const aiResult = JSON.parse(response.text.trim());
          newApp.aiAnalysis = aiResult;
          // Dynamically adjust status based on fit score to simulate recruiter screening!
          if (aiResult.score >= 80) {
            newApp.status = 'Review';
          }
        }
      } catch (aiErr) {
        console.error("Gemini AI CV Screening failed:", aiErr);
        // Fallback placeholder analysis if AI call crashes or rate limits
        newApp.aiAnalysis = {
          score: 75,
          fitLevel: 'Cukup Cocok',
          summary: "CV berhasil disubmit secara instan. Hasil analisis otomatis AI sedikit tertunda namun kualifikasi Anda sudah masuk antrean.",
          strengths: ["Kesiapan melamar pekerjaan", "Penyampaian CV yang solid"],
          gaps: ["Ulasan mendalam AI tertunda karena kapasitas server"],
          tips: ["Pastikan mencantumkan kontak aktif Anda di halaman CV."]
        };
      }
    } else {
      // Default placeholder if API Key is not set up yet
      newApp.aiAnalysis = {
        score: 80,
        fitLevel: 'Cukup Cocok',
        summary: "Pendaftaran sukses! (Opsional: Hubungkan kunci API Gemini Anda di Secrets Panel untuk mengaktifkan analisis kecocokan instan oleh AI).",
        strengths: ["Pengajuan berkas sukses"],
        gaps: ["Analisis AI off-line"],
        tips: ["Sempurnakan portofolio Anda sebelum diundang wawancara."]
      };
    }

    memoryDb.applications.unshift(newApp);
    saveDb();
    res.status(201).json(newApp);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Update Application Status (Recruiter Panel)
app.patch('/api/applications/:id', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const appIndex = memoryDb.applications.findIndex(a => a.id === id);
  if (appIndex !== -1) {
    memoryDb.applications[appIndex].status = status;
    saveDb();
    res.json(memoryDb.applications[appIndex]);
  } else {
    res.status(404).json({ error: "Aplikasi tidak ditemukan" });
  }
});


// 3. RECRUITER AI TOOL: GENERATE JOB DESCRIPTION
app.post('/api/ai/generate-jd', async (req, res) => {
  try {
    const { title, company, category, keywords } = req.body;
    if (!title || !company) {
      return res.status(400).json({ error: "Harap masukkan judul pekerjaan dan nama perusahaan." });
    }

    if (!ai) {
      // Fallback response if AI is not enabled
      return res.json({
        title: title,
        description: `Bergabunglah dengan ${company} sebagai ${title} professional. Anda bertanggung jawab memajukan divisi ${category || 'teknologi'} kami dengan solusi terbaik yang inovatif.`,
        requirements: [
          `Pengalaman kerja minimal 2 tahun dalam bidang terkait.`,
          `Memiliki keahlian komunikasi dan kerja tim yang baik.`,
          `Mampu beradaptasi dengan lingkungan kerja yang cepat.`
        ],
        benefits: [
          `Gaji pokok di atas rata-rata industri.`,
          `Tunjangan kesehatan dan BPJS.`,
          `Fasilitas pembelajaran dan keanggotaan peningkatan keahlian.`
        ]
      });
    }

    const prompt = `
      Anda adalah AI HR Writer profesional di Indonesia. Ambil input di bawah dan hasilkan Deskripsi Lowongan Kerja (Job Description) yang sangat menarik, profesional, rapi, dan terstruktur dalam Bahasa Indonesia.
      
      INFORMASI UTAMA:
      Judul lowongan: ${title}
      Nama perusahaan: ${company}
      Bidang Kategori: ${category || "General"}
      Kata Kunci / Catatan Khusus: ${keywords || "Tidak ada khusus"}

      Saran: buatlah minimal 4 persyaratan yang logis dan menarik, serta 3-4 keuntungan (benefits) bekerja di perusahaan ini.
      Kembalikan dalam format JSON murni:
      {
        "title": "${title}",
        "description": "<Satu paragraf pembuka menarik mengenai lowongan ini di ${company}>",
        "requirements": ["<Persyaratan 1>", "<Persyaratan 2>", "<Persyaratan 3>", "<Persyaratan 4>"],
        "benefits": ["<Fasilitas/Insentif 1>", "<Fasilitas 2>", "<Fasilitas 3>"]
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            requirements: { type: Type.ARRAY, items: { type: Type.STRING } },
            benefits: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["title", "description", "requirements", "benefits"]
        }
      }
    });

    const jdResult = JSON.parse(response.text?.trim() || "{}");
    res.json(jdResult);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// 4. CANDIDATE AI TOOL: GENERAL RESUME EVALUATOR
app.post('/api/ai/review-cv', async (req, res) => {
  try {
    const { cvText, targetJob } = req.body;
    if (!cvText) {
      return res.status(400).json({ error: "Harap tempel teks atau masukkan keahlian CV terlebih dahulu." });
    }

    if (!ai) {
      return res.json({
        score: 70,
        fitLevel: "Cukup Cocok",
        summary: "Aplikasi Anda berhasil di-review. Hubungkan Gemini API Key untuk ulasan mendalam AI.",
        strengths: ["Kelengkapan profil struktural dasar"],
        gaps: ["Keunikan portofolio atau statistik pencapaian kuantitatif"],
        tips: ["Gunakan tindakan aktif (Kata kerja kuat) di awal pencapaian karir Anda."],
        optimizedCv: `CURRICULUM VITAE (OPTIMASI AI)\n\n[NAMA LENGKAP]\nEmail: [EMAIL] | No. HP: [TELEPON] | LinkedIn: [LINKEDIN]\n\nRINGKASAN EKSEKUTIF\nProfesional berdedikasi tinggi dengan latar belakang di bidang yang relevan. Memiliki hasrat untuk terus belajar, beradaptasi dengan teknologi baru, serta menyelesaikan tantangan bisnis dengan solusi taktis.\n\nKEAHLIAN UTAMA & KOMPETENSI\n- Komunikasi & Kerja sama Tim\n- Analisis Kebutuhan & Adaptabilitas\n- Pemecahan Masalah Secara Kreatif\n\nPENGALAMAN KERJA\n- Staff / Professional [Tahun - Sekarang]\n  * Berkolaborasi dalam koordinasi harian tim serta pimpinan lintas fungsi.\n  * Menerapkan metodologi terbaik demi memastikan kelancaran operasional harian perusahaan.\n\nPEDIDIKAN\n- Gelar Sarjana / Diploma terkait [Tahun Kelulusan]`
      });
    }

    const prompt = `
      Anda adalah Konsultan Karir Senior & Pakar HRD di Indonesia.
      Tinjau keahlian dan riwayat pelamar berikut:
      Riwayat CV/Keahlian: ${cvText}
      Pekerjaan Target (Opsional): ${targetJob || "Umum / Menyesuaikan"}

      Berikan penilaian komprehensif, jujur, mendukung, dan taktis dalam Bahasa Indonesia.
      Tentukan persentase skor kesiapan (0-100).
      Hasil penilaian Anda harus menyertakan draf CV yang sudah diperbaiki / dioptimalkan di bagian 'optimizedCv' dengan struktur profesional Indonesia (Nama, Kontak, Ringkasan Eksekutif, Keahlian Kunci, Pengalaman Kerja, Pendidikan). Draf CV yang dioptimalkan tersebut harus ditulis sangat rapi, matang, dan siap diunduh.

      Return JSON murni:
      {
        "score": <number 0-100>,
        "fitLevel": "<'Sangat Cocok' | 'Cukup Cocok' | 'Kurang Cocok'>",
        "summary": "<Ulasan ringkas karir kandidat dan proyeksi keberhasilan di pasar kerja Indonesia saat ini>",
        "strengths": ["<Kelebihan utama yang terlihat 1>", "<Kelebihan 2>", ...],
        "gaps": ["<Hal penting yang sebaiknya ditambahkan atau kompetensi yang dirasa kurang 1>", "<Gap 2>", ...],
        "tips": ["<Saran aksi langsung (Contoh: sebutkan metodologi Scrum, tambahkan KPI kuantitatif, dsb)>", ...],
        "optimizedCv": "<Draf teks CV lengkap yang sudah dioptimalkan dan ditulis sangat rapi oleh AI untuk target jabatan ini, memuat bagian utama: RINGKASAN PROFIL, KEAHLIAN TEKNIS, PENGALAMAN PROFESIONAL, dan PENDIDIKAN secara detail dan lengkap>"
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.INTEGER },
            fitLevel: { type: Type.STRING },
            summary: { type: Type.STRING },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            gaps: { type: Type.ARRAY, items: { type: Type.STRING } },
            tips: { type: Type.ARRAY, items: { type: Type.STRING } },
            optimizedCv: { type: Type.STRING }
          },
          required: ["score", "fitLevel", "summary", "strengths", "gaps", "tips", "optimizedCv"]
        }
      }
    });

    const cvReview = JSON.parse(response.text?.trim() || "{}");
    res.json(cvReview);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// 4a. CANDIDATE AI TOOL: COVER LETTER GENERATOR
app.post('/api/ai/generate-cover-letter', async (req, res) => {
  try {
    const { cvText, jobTitle, jobCompany, jobDescription, candidateName } = req.body;
    if (!cvText || !jobTitle || !jobCompany) {
      return res.status(400).json({ error: "Kolom wajib diisi: cvText, jobTitle, jobCompany." });
    }

    if (!ai) {
      // Fallback response with beautiful Indonesia cover letter
      const fallbackLetter = `Jakarta, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}

Yth. Tim Rekrutmen ${jobCompany}
Di Tempat

Perihal: Lamaran Pekerjaan - ${jobTitle}

Dengan hormat,

Berdasarkan informasi lowongan pekerjaan yang saya dapatkan, melalui surat ini saya bermaksud untuk mengajukan diri guna melamar posisi sebagai ${jobTitle} di ${jobCompany}.

Saya memiliki latar belakang kualifikasi yang selaras dengan kualifikasi pekerjaan yang dicari. Berdasarkan ringkasan CV saya:
${cvText.slice(0, 300)}...

Dengan pengalaman serta semangat belajar yang tinggi, saya yakin dapat beradaptasi dengan cepat dan memberikan kontribusi nyata yang positif bagi kesuksesan bersama di ${jobCompany}. Saya sangat menghormati reputasi serta budaya kerja inovatif di perusahaan Anda, dan hal tersebut memotivasi saya untuk dapat berkembang bersama tim profesional Anda.

Besar harapan saya untuk diberikan kesempatan wawancara langsung guna mendiskusikan kualifikasi, rekam jejak, dan potensi kontribusi saya secara lebih mendalam.

Terima kasih atas waktu, perhatian, dan pertimbangan yang Bapak/Ibu berikan.

Hormat saya,

${candidateName || "Pelamar Kerja Papan Karir"}`;

      return res.json({
        coverLetter: `*(CATATAN: Hubungkan Gemini API Key di menu Settings > Secrets untuk draf Cover Letter yang dipersonalisasi AI secara mendalam)*\n\n${fallbackLetter}`
      });
    }

    const prompt = `
      Anda adalah Konsultan Karir Profesional & Editor Surat Lamaran Kerja top di Indonesia.
      Tugas Anda adalah membuat Surat Pengantar / Surat Lamaran (Cover Letter) yang profesional, persuasif, menarik, dan dipersonalisasi secara mendalam berdasarkan data CV pelamar dan deskripsi pekerjaan target.

      Informasi Kandidat:
      - Nama: ${candidateName || "Kandidat Papan Karir"}
      - Detail CV: ${cvText}

      Informasi Pekerjaan Target:
      - Judul Pekerjaan: ${jobTitle}
      - Perusahaan: ${jobCompany}
      - Deskripsi Pekerjaan / Persyaratan: ${jobDescription || "Menyesuaikan posisi"}

      Aturan Penulisan Surat Pengantar:
      1. Tulis lengkap dalam Bahasa Indonesia yang formal dan profesional (menggunakan kata ganti "Saya", bahasa yang hormat, e.g. "Yth. Manajer Perekrutan / Tim HRD").
      2. Jangan menggunakan format placeholder kurung siku seperti "[Nama]" atau "[Perusahaan]" untuk hal-hal yang sudah disediakan di atas. Gantilah secara langsung dengan data aslinya.
      3. Struktur Surat Pengantar harus meliputi:
         - Tempat dan Tanggal (Gunakan "Jakarta, " + tanggal hari ini)
         - Alamat/Salam Pembuka (e.g. "Yth. Tim Perekrut ${jobCompany}")
         - Paragraf Pembuka: Sebutkan ketertarikan melamar posisi ${jobTitle} di ${jobCompany}.
         - Paragraf Tubuh: Hubungkan keahlian kunci atau pengalaman dari CV kandidat yang sangat relevan dengan deskripsi pekerjaan. Berikan penekanan taktis mengapa kandidat adalah orang yang tepat.
         - Paragraf Penutup: Ungkapkan ketertarikan kuat dengan budaya perusahaan, sebutkan kesiapan untuk mempelajari tantangan baru, cantumkan harapan untuk dipanggil wawancara, dan salam hormat penutup.
      4. Jaga agar surat lamaran padat, berisi, berbobot, dan tidak bertele-tele (sekitar 3-4 paragraf).

      Return JSON murni dengan format berikut:
      {
        "coverLetter": "<Teks surat lamaran kerja yang sudah diformat dengan baris baru (newline) yang rapi, profesional, santun, dan siap pakai>"
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            coverLetter: { type: Type.STRING }
          },
          required: ["coverLetter"]
        }
      }
    });

    const parsed = JSON.parse(response.text?.trim() || "{}");
    res.json(parsed);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// 4b. CANDIDATE AI TOOL: CAREER ADVISOR COACH
app.post('/api/ai/career-advice', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Pesan tidak boleh kosong." });
    }

    if (!ai) {
      return res.json({
        reply: "Terima kasih atas pertanyaan Anda mengenai karir.\n\n*(Saran: Hubungkan Kunci API Gemini Anda di Secrets Panel untuk mendapatkan respon bimbingan cerdas real-time bahasa Indonesia yang mendalam dari AI Career Coach kami!)*"
      });
    }

    const conversationContext = history && Array.isArray(history)
      ? history.map((h: any) => `${h.sender === 'user' ? 'Kandidat' : 'Konsultan AI'}: ${h.text}`).join('\n')
      : "";

    const prompt = `
      Anda adalah Konsultan Karir Senior, Mentor Profesional & Pakar Industri Kerja Terkemuka di Indonesia.
      Tugas Anda adalah memandu kandidat dalam mencapai karir impian mereka, memberikan saran strategi melamar kerja, meningkatkan hard skill/soft skill, melatih interview, membagikan tips CV ATS, atau membimbing perpindahan karir (career switch) dengan nada bicara yang ramah, sopan, empatik, bijak, inspiratif, dan sangat taktis.

      RIWAYAT PERCAKAPAN SEBELUMNYA (Jika ada):
      ${conversationContext}

      PERTANYAAN/MASALAH BARU KANDIDAT:
      "${message}"

      Berikan tanggapan rincian yang inspiratif, mendalam namun ringkas, ramah, dan berstruktur (menggunakan poin-poin/checklist jika diperlukan), disesuaikan dengan konteks dunia kerja Indonesia masa kini.
      Jawablah dalam format JSON:
      {
        "reply": "<Jawaban atau panduan lengkap Anda dalam Bahasa Indonesia dengan format markdown yang rapi, sertakan tips konkret>"
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING }
          },
          required: ["reply"]
        }
      }
    });

    const adviceResult = JSON.parse(response.text?.trim() || "{}");
    res.json(adviceResult);
  } catch (error: any) {
    console.error("Gemini Career Advice Error:", error);
    res.status(500).json({ error: error.message });
  }
});


// 5. INTERACTIVE MOCK INTERVIEW CHATBOT WITH AI EVALUATION
// Get or create session
app.post('/api/interviews/start', (req, res) => {
  const { jobId, candidateName } = req.body;
  if (!jobId || !candidateName) {
    return res.status(400).json({ error: "jobId dan candidateName wajib dikirimkan." });
  }

  const job = memoryDb.jobs.find(j => j.id === jobId);
  if (!job) {
    return res.status(404).json({ error: "Pekerjaan tersebut tidak ditemukan." });
  }

  // Find if there is an existing active session for this candidate & job
  let session = memoryDb.interviews.find(s => s.jobId === jobId && s.candidateName === candidateName && s.status === 'active');
  
  if (!session) {
    const firstBotMessage: Message = {
      id: `m-start-${Date.now()}`,
      sender: 'ai',
      text: `Halo ${candidateName}, selamat datang di simulasi wawancara interaktif kami! Saya adalah interviewer AI Anda hari ini untuk posisi "${job.title}" di "${job.company}".\n\nMari kita mulai dengan pertanyaan pertama: Bisakah Anda menceritakan secara singkat tentang diri Anda, fokus harian Anda, dan mengapa Anda tertarik mendaftar di posisi ini?`,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };

    session = {
      id: `interview-${Date.now()}`,
      jobId,
      jobTitle: job.title,
      companyName: job.company,
      candidateName,
      messages: [firstBotMessage],
      status: 'active'
    };

    memoryDb.interviews.push(session);
    saveDb();
  }

  res.json(session);
});

// Send candidate answer & get AI response
app.post('/api/interviews/message', async (req, res) => {
  try {
    const { sessionId, text, forceComplete } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: "sessionId wajib diisi." });
    }

    const session = memoryDb.interviews.find(s => s.id === sessionId);
    if (!session) {
      return res.status(404).json({ error: "Sesi wawancara tidak ditemukan." });
    }

    const job = memoryDb.jobs.find(j => j.id === session.jobId);
    if (!job) {
      return res.status(404).json({ error: "Informasi jabatan dalam sesi tidak valid." });
    }

    if (session.status === 'completed') {
      return res.json(session);
    }

    // Add user message if text is supplied
    if (text) {
      const userMsg: Message = {
        id: `m-usr-${Date.now()}`,
        sender: 'user',
        text: text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      session.messages.push(userMsg);
    }

    // Count user replies
    const userMessageCount = session.messages.filter(m => m.sender === 'user').length;
    const shouldFinish = forceComplete || userMessageCount >= 4;

    if (!ai) {
      // Offline fallback handling
      if (shouldFinish) {
        session.status = 'completed';
        session.feedback = {
          score: 80,
          evaluation: `Terima kasih ${session.candidateName} telah menyelesaikan simulasi offline. Jawaban-jawaban Anda menunjukkan kesiapan berkomunikasi yang patut dipresiasi. Tautkan Gemini API Key agar HR AI kami dapat membaca respons Anda dan memilah keahlian teknis Anda secara akurat!`,
          tips: [
            "Selalu dukung jawaban wawancara Anda dengan contoh proyek nyata.",
            "Latihlah artikulasi konsep teknis dasar agar terdengar tenang dan meyakinkan.",
            "Tanyakan minimal satu hal strategis mengenai visi perusahaan di akhir sesi."
          ]
        };
      } else {
        const nextQMsg: Message = {
          id: `m-bot-${Date.now()}`,
          sender: 'ai',
          text: `[Offline Interaktif]: Terima kasih atas tanggapan Anda. Ceritakan tentang tantangan teknis tersulit yang pernah Anda selesaikan dan bagaimana Anda memecahkannya.`,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        };
        session.messages.push(nextQMsg);
      }
      saveDb();
      return res.json(session);
    }

    // Compose Chat History for context
    const formattedHistory = session.messages.map(m => 
      `${m.sender === 'ai' ? 'Interviewer' : 'Kandidat (' + session.candidateName + ')'}: ${m.text}`
    ).join('\n');

    let prompt = "";
    if (shouldFinish) {
      prompt = `
        Anda adalah Pewawancara Kerja Utama (Vanguard Executive Interviewer). Kandidat baru saja mengakhiri simulasi wawancaranya untuk lowongan pekerjaan berikut:
        Jabatan Lowongan: ${job.title}
        Perusahaan: ${job.company}
        Deskripsi lowongan: ${job.description}
        Persyaratan: ${job.requirements.join('; ')}

        BERIKUT ADALAH REKAMAN CHAT HISTORI INTERVIEW:
        ${formattedHistory}

        Evaluasi performa kandidat berdasarkan respons yang dia berikan di atas. Berikan masukan yang sopan, profesional, mendidik, dan konstruktif dalam Bahasa Indonesia. Berikan nilai (score) dari 0-100.
        Penting: Set completed = true.

        Kembalikan respon dalam murni JSON sesuai schema ini:
        {
          "completed": true,
          "nextQuestion": "",
          "feedback": {
            "score": <number 0-100 berdasarkan kualitas respons hardskill & softskill>,
            "evaluation": "<Ulasan menyeluruh yang komprehensif mengulas kelebihan menjawab, tingkat pembawaan, kedalaman kualifikasi, dsb dalam Bahasa Indonesia, minimal 3 kalimat panjang>",
            "tips": ["<Tips taktis 1 untuk melamar kerja nyata>", "<Tips 2>", "<Tips 3>"]
          }
        }
      `;
    } else {
      prompt = `
        Anda adalah Pewawancara Kerja Interaktif untuk lowongan ini:
        Jabatan: ${job.title}
        Perusahaan: ${job.company}
        Persyaratan: ${job.requirements.join('; ')}

        REKAMAN PERCAKAPAN HINGGA SAAT INI:
        ${formattedHistory}

        Tugas Anda adalah merespon jawaban terakhir kandidat dengan ramah, profesional, dan menantang, lalu ajukan SATU pertanyaan lanjutan baru yang relevan dengan riwayat chat tersebut atau menguji pemahaman kandidat terkait syarat pekerjaan ${job.requirements.join('; ')}. Jawablah murni dalam Bahasa Indonesia!
        Jangan berikan penilaian sekarang karena interaksi masih berlangsung. Set completed = false.

        Kembalikan respon dalam murni JSON sesuai schema ini:
        {
          "completed": false,
          "nextQuestion": "<Tanggapan ramah penegasan + SATU kalimat pertanyaan wawancara kerja lanjutan yang segar dan elegan>"
        }
      `;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            completed: { type: Type.BOOLEAN },
            nextQuestion: { type: Type.STRING },
            feedback: {
              type: Type.OBJECT,
              properties: {
                score: { type: Type.INTEGER },
                evaluation: { type: Type.STRING },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          required: ["completed", "nextQuestion"]
        }
      }
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    if (result.completed) {
      session.status = 'completed';
      session.feedback = result.feedback;
      
      const closingMsg: Message = {
        id: `m-bot-end-${Date.now()}`,
        sender: 'ai',
        text: `Terima kasih atas waktu Anda, ${session.candidateName}. Sesi simulasi wawancara telah selesai! Saya telah merangkum feedback performa Anda dalam tab laporan penilaian. Sukses selalu untuk karir Anda!`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      session.messages.push(closingMsg);
    } else {
      const nextQMsg: Message = {
        id: `m-bot-${Date.now()}`,
        sender: 'ai',
        text: result.nextQuestion,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      session.messages.push(nextQMsg);
    }

    saveDb();
    res.json(session);
  } catch (error: any) {
    console.error("Gemini Interview Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// 6. CAREER FEED ENDPOINTS
app.get('/api/feed', (req, res) => {
  res.json(memoryDb.feed || []);
});

app.post('/api/feed', (req, res) => {
  try {
    const { authorName, authorTitle, authorRole, type, title, content, tag } = req.body;
    
    if (!authorName || !content) {
      return res.status(400).json({ error: "Kolom wajib diisi: authorName, content" });
    }

    const newPost: FeedPost = {
      id: `post-${Date.now()}`,
      authorName,
      authorTitle: authorTitle || "Kandidat Papan Karir",
      authorRole: authorRole || 'kandidat',
      type: type || 'status_update',
      title: title || undefined,
      content,
      likes: [],
      comments: [],
      createdAt: "Baru saja",
      tag: tag || undefined
    };

    if (!memoryDb.feed) memoryDb.feed = [];
    memoryDb.feed.unshift(newPost);
    saveDb();
    res.status(201).json(newPost);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/feed/:id/like', (req, res) => {
  try {
    const { id } = req.params;
    const { userName } = req.body;

    if (!userName) {
      return res.status(400).json({ error: "userName wajib dikirim untuk melakukan like." });
    }

    if (!memoryDb.feed) memoryDb.feed = [];
    const postIndex = memoryDb.feed.findIndex(p => p.id === id);
    if (postIndex === -1) {
      return res.status(404).json({ error: "Postingan tidak ditemukan." });
    }

    const post = memoryDb.feed[postIndex];
    if (post.likes.includes(userName)) {
      post.likes = post.likes.filter(name => name !== userName);
    } else {
      post.likes.push(userName);
    }

    saveDb();
    res.json(post);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/feed/:id/comment', (req, res) => {
  try {
    const { id } = req.params;
    const { authorName, authorTitle, content } = req.body;

    if (!authorName || !content) {
      return res.status(400).json({ error: "authorName dan content wajib diisi para komentar." });
    }

    if (!memoryDb.feed) memoryDb.feed = [];
    const postIndex = memoryDb.feed.findIndex(p => p.id === id);
    if (postIndex === -1) {
      return res.status(404).json({ error: "Postingan tidak ditemukan." });
    }

    const newComment = {
      id: `c-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      authorName,
      authorTitle: authorTitle || "Kandidat",
      content,
      createdAt: "Baru saja"
    };

    memoryDb.feed[postIndex].comments.push(newComment);
    saveDb();
    res.status(201).json(memoryDb.feed[postIndex]);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================

// Mount Vite middleware OR Static files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Papan Karir] Express Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
