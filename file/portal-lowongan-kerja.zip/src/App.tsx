import React, { useState, useEffect } from 'react';
import { Job, JobApplication } from './types';
import JobList from './components/JobList';
import JobDetail from './components/JobDetail';
import ResumeReviewer from './components/ResumeReviewer';
import MockInterview from './components/MockInterview';
import RecruiterDashboard from './components/RecruiterDashboard';
import MyApplications from './components/MyApplications';
import UserProfile from './components/UserProfile';
import CareerFeed from './components/CareerFeed';
import { Briefcase, Clock, FileText, Sparkles, MessageSquare, Landmark, User, Heart, Star, LogOut, Search, Bell, Trash2, BellOff, Share2 } from 'lucide-react';
import { motion } from 'motion/react';

type Tab = 'jobs' | 'applications' | 'reviewer' | 'interview' | 'recruiter' | 'profile' | 'feed';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('jobs');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmittingApp, setIsSubmittingApp] = useState(false);
  const [userName, setUserName] = useState('Axl Discus');
  const [userTitle, setUserTitle] = useState('Full Stack Software Engineer');
  const [savedJobIds, setSavedJobIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('cari_kerja_saved_jobs');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Persist saved jobs
  useEffect(() => {
    try {
      localStorage.setItem('cari_kerja_saved_jobs', JSON.stringify(savedJobIds));
    } catch (err) {
      console.error("Failed to save to localStorage", err);
    }
  }, [savedJobIds]);

  // Notifications State Management
  const [notifications, setNotifications] = useState<any[]>(() => {
    try {
      const stored = localStorage.getItem('papan_karir_notifications');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [isNotifOpen, setIsNotifOpen] = useState(false);

  // Persist notifications
  useEffect(() => {
    try {
      localStorage.setItem('papan_karir_notifications', JSON.stringify(notifications));
    } catch (err) {
      console.error("Failed to save notifications", err);
    }
  }, [notifications]);

  // Monitor application status updates to trigger notifications in real time
  useEffect(() => {
    if (loading || !applications || applications.length === 0) return;

    try {
      const storedStatusesStr = localStorage.getItem('papan_karir_app_statuses');
      const cachedStatuses = storedStatusesStr ? JSON.parse(storedStatusesStr) : {};
      
      let changed = false;
      const updatedCache = { ...cachedStatuses };
      const newNotifs: any[] = [];

      applications.forEach(app => {
        const lastStatus = cachedStatuses[app.id];
        
        if (lastStatus === undefined) {
          // First time seeing this application. Register status without triggering alert notifications.
          updatedCache[app.id] = app.status;
          changed = true;
        } else if (lastStatus !== app.status) {
          // Status updated! Create alert notification.
          const notifId = `notif-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
          const timeString = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ', ' + new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
          
          newNotifs.unshift({
            id: notifId,
            applicationId: app.id,
            jobTitle: app.jobTitle,
            companyName: app.companyName,
            oldStatus: lastStatus,
            newStatus: app.status,
            timestamp: timeString,
            isRead: false
          });

          updatedCache[app.id] = app.status;
          changed = true;
        }
      });

      if (changed) {
        localStorage.setItem('papan_karir_app_statuses', JSON.stringify(updatedCache));
      }

      if (newNotifs.length > 0) {
        setNotifications(prev => [...newNotifs, ...prev]);
      }
    } catch (err) {
      console.error("Failed to track application statuses", err);
    }
  }, [applications, loading]);

  // Handle clicking outside of notifications dropdown to close it safely
  useEffect(() => {
    if (!isNotifOpen) return;
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('#notification-center-container')) {
        setIsNotifOpen(false);
      }
    };
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, [isNotifOpen]);

  // Notification management functions
  const handleMarkAsRead = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev =>
      prev.map(n => ({ ...n, isRead: true }))
    );
  };

  const handleDeleteNotification = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setNotifications(prev =>
      prev.filter(n => n.id !== id)
    );
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
  };

  const handleNotifClick = (notif: any) => {
    setNotifications(prev =>
      prev.map(n => n.id === notif.id ? { ...n, isRead: true } : n)
    );
    setActiveTab('applications');
    setSelectedJob(null);
    setIsNotifOpen(false);
  };

  // Sync user details for LinkedIn-style sidebar
  useEffect(() => {
    const syncProfile = () => {
      try {
        const storedName = localStorage.getItem('cari_kerja_user_name');
        if (storedName?.trim()) {
          setUserName(storedName);
        }
        
        // Try getting role title / expertise if stored or use standard based on summary
        const storedProfile = localStorage.getItem('papan_karir_user_profile');
        if (storedProfile) {
          const prof = JSON.parse(storedProfile);
          if (prof.position?.trim()) {
            setUserTitle(prof.position);
          } else if (prof.title?.trim()) {
            setUserTitle(prof.title);
          }
        }
      } catch (e) {
        console.error("Failed to parse user profile structural details", e);
      }
    };

    syncProfile();
    window.addEventListener('storage', syncProfile);
    window.addEventListener('profileUpdated', syncProfile);
    return () => {
      window.removeEventListener('storage', syncProfile);
      window.removeEventListener('profileUpdated', syncProfile);
    };
  }, [activeTab]);

  const handleToggleSave = (jobId: string) => {
    setSavedJobIds(prev =>
      prev.includes(jobId) ? prev.filter(id => id !== jobId) : [...prev, jobId]
    );
  };

  // Initial loading from our Express endpoint
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [jobsRes, appsRes] = await Promise.all([
        fetch('/api/jobs'),
        fetch('/api/applications')
      ]);
      const jobsData = await jobsRes.json();
      const appsData = await appsRes.json();
      setJobs(jobsData);
      setApplications(appsData);
    } catch (err) {
      console.error("Error loading server data:", err);
    } finally {
      setLoading(false);
    }
  };

  // 1. Submit application form
  const handleApplyJob = async (appData: {
    candidateName: string;
    candidateEmail: string;
    candidatePhone: string;
    linkedinUrl: string;
    cvText: string;
    coverLetter: string;
  }) => {
    if (!selectedJob) return;
    setIsSubmittingApp(true);
    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          jobId: selectedJob.id,
          ...appData
        })
      });
      if (!response.ok) {
        throw new Error("HTTP error " + response.status);
      }
      const newApp = await response.json();
      setApplications(prev => [newApp, ...prev]);
    } catch (err) {
      console.error("Application submission failed:", err);
      throw err;
    } finally {
      setIsSubmittingApp(false);
    }
  };

  // 2. Submit general CV optimization
  const handleAnalyzeCV = async (cvText: string, targetJob: string) => {
    const response = await fetch('/api/ai/review-cv', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ cvText, targetJob })
    });
    if (!response.ok) {
      throw new Error("Failed to review resume.");
    }
    return await response.json();
  };

  // 3. Start Wawancara AI session
  const handleStartInterview = async (jobId: string, candidateName: string) => {
    const response = await fetch('/api/interviews/start', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ jobId, candidateName })
    });
    if (!response.ok) {
      throw new Error("Failed to start session.");
    }
    return await response.json();
  };

  // 4. Send interview chat message
  const handleSendInterviewMsg = async (sessionId: string, text: string, forceComplete?: boolean) => {
    const response = await fetch('/api/interviews/message', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ sessionId, text, forceComplete })
    });
    if (!response.ok) {
      throw new Error("Failed to process conversation.");
    }
    return await response.json();
  };

  // 5. Generate Job Description for Recruiter
  const handleGenerateAIJD = async (title: string, company: string, category: string, keywords: string) => {
    const response = await fetch('/api/ai/generate-jd', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ title, company, category, keywords })
    });
    if (!response.ok) {
      throw new Error("Fail generating job specifications.");
    }
    return await response.json();
  };

  // 6. Post a modern job (Recruiter)
  const handlePostJob = async (jobData: any) => {
    const response = await fetch('/api/jobs', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(jobData)
    });
    if (!response.ok) {
      throw new Error("Fail creating job listing.");
    }
    const createdJob = await response.json();
    setJobs(prev => [createdJob, ...prev]);
  };

  // 7. Delete job posting
  const handleDeleteJob = async (jobId: string) => {
    const response = await fetch(`/api/jobs/${jobId}`, {
      method: 'DELETE'
    });
    if (!response.ok) {
      throw new Error("Fail deleting job listing.");
    }
    setJobs(prev => prev.filter(j => j.id !== jobId));
  };

  // 8. Update applicant status (Recruiter zone)
  const handleUpdateAppStatus = async (appId: string, status: string) => {
    const response = await fetch(`/api/applications/${appId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ status })
    });
    if (!response.ok) {
      throw new Error("Fail updating application status.");
    }
    const updated = await response.json();
    setApplications(prev => prev.map(a => a.id === appId ? updated : a));
  };

  const handleSelectJobClick = (job: Job) => {
    setSelectedJob(job);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTabChange = (tab: Tab) => {
    setActiveTab(tab);
    setSelectedJob(null);
  };

  return (
    <div className="min-h-screen bg-[#f3f2f0] flex flex-col font-sans text-slate-800">
      {/* Visual Navigation Header (LinkedIn Style) */}
      <header className="sticky top-0 z-50 bg-white border-b border-[#e0e0e0] shadow-sm px-4 md:px-6 py-2">
        <div className="max-w-6xl mx-auto flex justify-between items-center gap-4">
          
          {/* Logo & Search Bar */}
          <div className="flex items-center gap-2.5 flex-1 max-w-md">
            {/* Logo */}
            <div
              onClick={() => handleTabChange('jobs')}
              className="flex items-center cursor-pointer group select-none shrink-0"
              id="app-logo-container"
              title="Papan Karir Home"
            >
              <div className="w-9 h-9 bg-[#0a66c2] hover:bg-[#004182] rounded-[4px] text-white font-black text-lg tracking-tighter flex items-center justify-center transition-all duration-200">
                pk
              </div>
            </div>

            {/* LinkedIn-style responsive Search Bar connected to jobs filter */}
            <div className="relative w-full hidden sm:block">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                id="header-global-search"
                type="text"
                placeholder="Cari lowongan kerja, perusahaan, atau keahlian..."
                className="w-full bg-[#edf3f8] hover:bg-[#e4ebf1] focus:bg-white focus:ring-2 focus:ring-[#0a66c2] border border-transparent rounded-[4px] pl-9 pr-4 py-1.5 text-xs text-slate-800 placeholder-slate-500 focus:outline-none transition-all duration-150"
                onChange={(e) => {
                  const val = e.target.value;
                  // Set global search session item so JobList can read it
                  localStorage.setItem('cari_kerja_global_search', val);
                  // Dispatch a custom event to notify JobList to update search term
                  window.dispatchEvent(new CustomEvent('globalSearchUpdated', { detail: val }));
                  if (activeTab !== 'jobs') {
                    handleTabChange('jobs');
                  }
                }}
              />
            </div>
          </div>

          {/* Master Tab list - LinkedIn Style: Icon stacked on top of label */}
          <nav className="flex items-center gap-2 md:gap-5 text-slate-500">
            <button
              onClick={() => handleTabChange('jobs')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'jobs' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-jobs"
            >
              <Briefcase className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Lowongan</span>
            </button>
            <button
              onClick={() => handleTabChange('feed')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'feed' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-feed"
            >
              <Share2 className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Feed Karir</span>
            </button>
            <button
              onClick={() => handleTabChange('applications')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'applications' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-applications"
            >
              <Clock className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Lamaran Saya</span>
              {applications.length > 0 && (
                <span className="absolute top-0 right-1 px-1.5 py-0.5 bg-[#0a66c2] text-white text-[9px] font-bold rounded-full leading-none transform translate-x-1/2 -translate-y-1/3">
                  {applications.length}
                </span>
              )}
            </button>
            <button
              onClick={() => handleTabChange('reviewer')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'reviewer' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-reviewer"
            >
              <Sparkles className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Saran CV</span>
            </button>
            <button
              onClick={() => handleTabChange('interview')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'interview' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-interview"
            >
              <MessageSquare className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Latihan Interview</span>
            </button>
            <button
              onClick={() => handleTabChange('profile')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'profile' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-profile"
            >
              <User className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Profil & Gaji</span>
            </button>
            <button
              onClick={() => handleTabChange('recruiter')}
              className={`flex flex-col items-center justify-center py-1 px-2.5 cursor-pointer relative transition-colors duration-150 border-b-2 hover:text-slate-900 ${
                activeTab === 'recruiter' ? 'border-[#191919] text-slate-900 font-medium' : 'border-transparent text-slate-500'
              }`}
              id="tab-btn-recruiter"
            >
              <Landmark className="w-5 h-5 shrink-0" />
              <span className="hidden md:block text-[11px] font-normal tracking-wide mt-0.5">Dashboard HR</span>
            </button>
          </nav>

          {/* Notification Center & User Profile */}
          <div className="flex items-center gap-2.5 md:gap-4 shrink-0 select-none">
            {/* Notification Center Dropdown */}
            <div className="relative" id="notification-center-container">
              <button
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="flex flex-col items-center justify-center p-1.5 rounded-full hover:bg-slate-100 cursor-pointer relative transition-colors duration-150 text-slate-500 hover:text-slate-800"
                title="Notifikasi"
                id="btn-toggle-notifications"
              >
                <Bell className="w-5 h-5 shrink-0" />
                {notifications.filter(n => !n.isRead).length > 0 && (
                  <span 
                    className="absolute top-0 right-0 px-1 py-0.5 bg-rose-500 text-white text-[8px] font-extrabold rounded-full leading-none transform translate-x-1/3 -translate-y-1/3 animate-pulse"
                    id="notif-badge-count"
                  >
                    {notifications.filter(n => !n.isRead).length}
                  </span>
                )}
              </button>

              {isNotifOpen && (
                <div 
                  className="absolute right-0 mt-3.5 w-76 sm:w-85 bg-white border border-slate-200 rounded-xl shadow-xl z-50 text-slate-800 overflow-hidden"
                  id="notification-dropdown-panel"
                  style={{ minWidth: '280px' }}
                >
                  {/* Dropdown Header */}
                  <div className="p-3 bg-slate-50 border-b border-slate-150 flex justify-between items-center text-xs">
                    <span className="font-bold text-[11px] uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                      <Bell className="w-3.5 h-3.5 text-[#0a66c2]" />
                      <span>Notifikasi ({notifications.length})</span>
                    </span>
                    {notifications.length > 0 && (
                      <div className="flex items-center gap-1.5 text-[10px]">
                        <button
                          onClick={handleMarkAllAsRead}
                          className="text-[#0a66c2] hover:text-[#004182] font-semibold hover:underline"
                        >
                          Dibaca semua
                        </button>
                        <span className="text-slate-300">|</span>
                        <button
                          onClick={handleClearAllNotifications}
                          className="text-rose-600 hover:text-rose-800 font-semibold hover:underline"
                        >
                          Hapus
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Notification List Wrapper */}
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-slate-400 space-y-2">
                        <BellOff className="w-7 h-7 text-slate-300 mx-auto" />
                        <p className="font-bold text-[11px] uppercase tracking-wider text-slate-500">Belum ada pemberitahuan</p>
                        <p className="text-[10px] text-slate-400 leading-normal">
                          Status lamaran Anda yang diperbarui oleh HR akan muncul langsung di panel ini.
                        </p>
                      </div>
                    ) : (
                      notifications.map((n) => {
                        // Color styling helpers
                        const getStatusClasses = (status: string) => {
                          switch (status) {
                            case 'Review': return 'bg-amber-50 text-amber-700 border border-amber-200';
                            case 'Wawancara': return 'bg-indigo-50 text-indigo-700 border border-indigo-200';
                            case 'Diterima': return 'bg-emerald-50 text-emerald-700 border border-emerald-200';
                            case 'Ditolak': return 'bg-rose-50 text-rose-700 border border-rose-200';
                            default: return 'bg-blue-50 text-blue-700 border border-blue-200';
                          }
                        };

                        return (
                          <div
                            key={n.id}
                            onClick={() => handleNotifClick(n)}
                            className={`p-3 text-[11px] hover:bg-slate-50/70 cursor-pointer flex gap-2 transition relative items-start ${
                              !n.isRead ? 'bg-blue-50/20' : ''
                            }`}
                            id={`notif-item-${n.id}`}
                          >
                            {/* Blue dot indicator for unread */}
                            {!n.isRead && (
                              <span className="w-1.5 h-1.5 rounded-full bg-[#0a66c2] mt-1.5 shrink-0 self-start" />
                            )}
                            
                            <div className="flex-1 space-y-1">
                              <div className="flex justify-between items-start gap-1">
                                <p className="font-bold text-slate-900 leading-snug">
                                  Pembaruan Lamaran
                                </p>
                                <span className="text-[9px] text-slate-400 font-mono shrink-0">
                                  {n.timestamp.split(', ')[0]}
                                </span>
                              </div>
                              
                              <p className="text-[11px] text-slate-500 leading-relaxed">
                                Lamaran Anda ke <strong className="text-slate-800">{n.companyName}</strong> sebagai <strong className="text-slate-800">{n.jobTitle}</strong> dialihkan dari <span className="line-through text-slate-400 font-medium">{n.oldStatus}</span> ke <span className={`px-1.5 py-0.5 rounded-[4px] font-extrabold text-[9px] tracking-wide uppercase ${getStatusClasses(n.newStatus)}`}>{n.newStatus}</span>.
                              </p>
                              
                              <div className="flex justify-end gap-3 pt-1">
                                {!n.isRead && (
                                  <button
                                    onClick={(e) => handleMarkAsRead(n.id, e)}
                                    className="text-[9px] text-[#0a66c2] hover:underline font-semibold"
                                  >
                                    Tandai dibaca
                                  </button>
                                )}
                                <button
                                  onClick={(e) => handleDeleteNotification(n.id, e)}
                                  className="text-[9px] text-rose-500 hover:text-rose-700 font-semibold flex items-center gap-0.5"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span>Hapus</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                  
                  {/* View all applications link footer */}
                  {notifications.length > 0 && (
                    <div className="p-2 border-t border-slate-100 bg-slate-50 text-center">
                      <button
                        onClick={() => {
                          setActiveTab('applications');
                          setSelectedJob(null);
                          setIsNotifOpen(false);
                        }}
                        className="text-[10px] text-[#0a66c2] hover:text-[#004182] font-semibold"
                      >
                        Lihat Semua Lamaran Saya
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* User Profile avatar menu */}
            <div
              onClick={() => handleTabChange('profile')}
              className="flex items-center gap-2 cursor-pointer group hover:opacity-90 transition shrink-0"
              id="header-user-avatar-btn"
            >
              <div className="w-8 h-8 rounded-full bg-slate-100 text-[#0a66c2] hover:ring-2 hover:ring-[#0a66c2]/60 flex items-center justify-center font-bold text-xs border border-slate-300 transition duration-150">
                AX
              </div>
              <div className="hidden lg:block text-left leading-none">
                <p className="text-[11px] font-semibold text-slate-800">Me</p>
                <p className="text-[9px] text-slate-400 font-medium">Kandidat</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main viewport Container (LinkedIn 4-Column Structured Canvas) */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:py-6">
        {loading ? (
          <div className="min-h-[400px] flex flex-col justify-center items-center gap-3">
            <div className="w-10 h-10 border-4 border-slate-200 border-t-[#0a66c2] rounded-full animate-spin" />
            <p className="text-xs text-slate-500 animate-pulse font-medium">Bekerja dengan AI Papan Karir...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            {/* COLUMN 1: LEFT SIDEBAR (LinkedIn-style Mini Profile & Navigation Shortcuts) */}
            <div className="lg:col-span-1 space-y-4">
              
              {/* Profile Overview Card */}
              <div className="bg-white rounded-lg border border-[#e0e0e0] overflow-hidden shadow-sm">
                {/* Visual Banner backdrop cover */}
                <div className="h-14 bg-gradient-to-r from-[#0a66c2] to-[#004182] relative" />
                
                {/* Profile circular avatar and details */}
                <div className="px-4 pb-4 relative flex flex-col items-center -mt-8 text-center select-none">
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-white overflow-hidden shadow-md shrink-0 flex items-center justify-center font-extrabold text-white text-xl bg-gradient-to-tr from-[#0a66c2] to-blue-500">
                    {userName.substring(0, 2).toUpperCase()}
                  </div>
                  
                  <h3 
                    onClick={() => handleTabChange('profile')}
                    className="font-bold text-slate-900 text-sm hover:underline cursor-pointer mt-3 transition duration-150"
                  >
                    {userName}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-normal mt-1 leading-snug line-clamp-2">
                    {userTitle}
                  </p>
                </div>
                
                {/* Dynamic mini statistics */}
                <div className="border-t border-[#f3f2f0] py-2.5 text-[11px]">
                  <div className="px-4 py-1.5 flex justify-between hover:bg-slate-50 cursor-pointer" onClick={() => handleTabChange('profile')}>
                    <span className="text-slate-500 font-medium">Pengunjung profil Anda</span>
                    <span className="text-[#0a66c2] font-semibold">142</span>
                  </div>
                  <div className="px-4 py-1.5 flex justify-between hover:bg-slate-50 cursor-pointer" onClick={() => handleTabChange('applications')}>
                    <span className="text-slate-500 font-medium">Total lamaran terkirim</span>
                    <span className="text-[#0a66c2] font-semibold">{applications.length}</span>
                  </div>
                </div>

                {/* Bottom interactive navigation hooks */}
                <div className="border-t border-[#f3f2f0] p-3 text-xs bg-slate-50/50 hover:bg-slate-100 transition duration-150">
                  <button 
                    onClick={() => {
                      handleTabChange('jobs');
                    }}
                    className="flex items-center gap-2 font-bold text-slate-700 hover:text-[#0a66c2] transition cursor-pointer text-left w-full"
                  >
                    <Heart className="w-4 h-4 fill-rose-500/10 text-rose-500" />
                    <span>Loker Tersimpan ({savedJobIds.length})</span>
                  </button>
                </div>
              </div>

              {/* Sidebar Quick-Tools Navigation List */}
              <div className="bg-white rounded-lg border border-[#e0e0e0] p-3 shadow-sm hidden lg:block text-xs space-y-1">
                <p className="text-[10px] font-bold text-[#0a66c2] uppercase tracking-wider px-2 py-1 mb-1">
                  Pintasan Alat AI
                </p>
                <button
                  onClick={() => handleTabChange('reviewer')}
                  className={`w-full text-left px-2 py-1.5 rounded-[4px] font-medium transition cursor-pointer hover:bg-slate-50 flex items-center gap-2 ${
                    activeTab === 'reviewer' ? 'text-[#0a66c2] bg-blue-50/50' : 'text-slate-600'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#0a66c2]" />
                  <span>Cek Keselarasan CV ATS</span>
                </button>
                <button
                  onClick={() => handleTabChange('interview')}
                  className={`w-full text-left px-2 py-1.5 rounded-[4px] font-medium transition cursor-pointer hover:bg-slate-50 flex items-center gap-2 ${
                    activeTab === 'interview' ? 'text-[#0a66c2] bg-blue-50/50' : 'text-slate-600'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5 text-[#0a66c2]" />
                  <span>Simulasi Wawancara AI</span>
                </button>
                <button
                  onClick={() => handleTabChange('profile')}
                  className={`w-full text-left px-2 py-1.5 rounded-[4px] font-medium transition cursor-pointer hover:bg-slate-50 flex items-center gap-2 ${
                    activeTab === 'profile' ? 'text-[#0a66c2] bg-blue-50/50' : 'text-slate-600'
                  }`}
                >
                  <User className="w-3.5 h-3.5 text-[#0a66c2]" />
                  <span>Kalkulator Gaji & Pajak</span>
                </button>
              </div>

              {/* Minimal Web Footer in Left Rail */}
              <div className="hidden lg:block text-[10px] text-slate-400 font-normal px-2 space-y-1">
                <p>© {new Date().getFullYear()} Papan Karir Indonesia.</p>
                <p>Platform Rekrutmen Cerdas & Terverifikasi.</p>
              </div>
            </div>

            {/* COLUMN 2 & 3: CENTER FEED CONTENT ZONE (Middle viewport switching card area) */}
            <div className="col-span-1 lg:col-span-2 space-y-4">
              
              {/* Dynamic Sub-View injection */}
              <div className="min-h-[500px]">
                {activeTab === 'jobs' && (
                  selectedJob ? (
                    <JobDetail
                      job={selectedJob}
                      jobs={jobs}
                      savedJobIds={savedJobIds}
                      onToggleSave={handleToggleSave}
                      onBack={() => setSelectedJob(null)}
                      onSubmitApplication={handleApplyJob}
                      isSubmitting={isSubmittingApp}
                    />
                  ) : (
                    <JobList
                      jobs={jobs}
                      savedJobIds={savedJobIds}
                      onToggleSave={handleToggleSave}
                      onSelectJob={handleSelectJobClick}
                      onPostJobClick={() => handleTabChange('recruiter')}
                    />
                  )
                )}

                {activeTab === 'applications' && (
                  <MyApplications applications={applications} />
                )}

                {activeTab === 'feed' && (
                  <CareerFeed userName={userName} userTitle={userTitle} />
                )}

                {activeTab === 'reviewer' && (
                  <ResumeReviewer onAnalyzeCV={handleAnalyzeCV} />
                )}

                {activeTab === 'interview' && (
                  <MockInterview
                    jobs={jobs}
                    onStartInterview={handleStartInterview}
                    onSendMessage={handleSendInterviewMsg}
                  />
                )}

                {activeTab === 'profile' && (
                  <UserProfile />
                )}

                {activeTab === 'recruiter' && (
                  <RecruiterDashboard
                    jobs={jobs}
                    applications={applications}
                    onPostJob={handlePostJob}
                    onDeleteJob={handleDeleteJob}
                    onUpdateAppStatus={handleUpdateAppStatus}
                    onGenerateAIJD={handleGenerateAIJD}
                  />
                )}
              </div>
            </div>

            {/* COLUMN 4: RIGHT PANEL (Career trends, updates, guidelines) */}
            <div className="lg:col-span-1 hidden lg:block space-y-4">
              
              {/* Trending Job Fields in Indonesia Widget */}
              <div className="bg-white rounded-lg border border-[#e0e0e0] p-4 shadow-sm">
                <h4 className="font-bold text-slate-800 text-[12px] uppercase tracking-wider mb-3">
                  Wawasan Karir Terkini
                </h4>
                
                <div className="space-y-3">
                  <div>
                    <p className="text-[12px] font-semibold text-slate-700 hover:underline hover:text-[#0a66c2] cursor-pointer">
                      Pakar Generative AI Melonjak
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Permintaan naik • 1.204 lowongan baru
                    </p>
                  </div>
                  <div>
                    <p className="text-[12px] font-semibold text-slate-700 hover:underline hover:text-[#0a66c2] cursor-pointer">
                      Peluang Remote Work 2026
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Paling banyak dicari • 850 kandidat
                    </p>
                  </div>
                  <div>
                    <p className="text-[12px] font-semibold text-slate-700 hover:underline hover:text-[#0a66c2] cursor-pointer">
                      Kenaikan Gaji Tech Indonesia
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Rata-rata 12% YoY • Selengkapnya di tab Gaji
                    </p>
                  </div>
                </div>
              </div>

              {/* AI Coaching Tips */}
              <div className="bg-white rounded-lg border border-[#e0e0e0] p-4 shadow-sm text-xs text-slate-500 space-y-2.5">
                <div className="flex items-center gap-1.5 text-[#0a66c2] font-bold">
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span className="uppercase tracking-wider text-[10px] font-bold">Smart Guide</span>
                </div>
                <p className="leading-relaxed">
                  Lengkapi <strong>Profil Anda</strong> secara lengkap untuk otomatis memperoleh rekomendasi kecocokan CV ATS tertinggi langsung dari portal pencarian.
                </p>
                <div className="pt-1.5">
                  <button 
                    onClick={() => handleTabChange('profile')}
                    className="w-full py-1.5 hover:bg-blue-50 text-[#0a66c2] font-semibold border border-[#0a66c2] rounded-full text-center hover:text-[#004182] transition duration-150 cursor-pointer"
                  >
                    Lengkapi Profil & Draf CV
                  </button>
                </div>
              </div>

              {/* Developer Attribution Card */}
              <div className="bg-gradient-to-br from-slate-50 to-blue-50/25 rounded-lg border border-[#e0e0e0] p-3 text-center text-[10px] text-slate-400 space-y-1 shadow-sm">
                <p className="font-semibold text-slate-600">Simpel & User friendly UI</p>
                <p>Direkayasa untuk efisiensi penempatan kerja instan.</p>
              </div>

            </div>

          </div>
        )}
      </main>

      {/* Mobile Responsive Bottom Dock Navigation */}
      <footer className="md:hidden sticky bottom-0 z-50 bg-white/95 backdrop-blur-md border-t border-[#e0e0e0] px-2 py-2 flex justify-around items-center text-[10px] font-medium text-slate-500 shadow-md">
        <button
          onClick={() => handleTabChange('jobs')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'jobs' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <Briefcase className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Lowongan</span>
        </button>
        <button
          onClick={() => handleTabChange('feed')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'feed' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <Share2 className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Feed</span>
        </button>
        <button
          onClick={() => handleTabChange('applications')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'applications' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Lamaran</span>
        </button>
        <button
          onClick={() => handleTabChange('reviewer')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'reviewer' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Saran CV</span>
        </button>
        <button
          onClick={() => handleTabChange('interview')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'interview' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Interview</span>
        </button>
        <button
          onClick={() => handleTabChange('profile')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'profile' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Profil</span>
        </button>
        <button
          onClick={() => handleTabChange('recruiter')}
          className={`flex flex-col items-center justify-center p-1 cursor-pointer transition ${
            activeTab === 'recruiter' ? 'text-[#0a66c2] font-semibold' : 'hover:text-slate-800'
          }`}
        >
          <Landmark className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">HR</span>
        </button>
      </footer>
    </div>
  );
}
