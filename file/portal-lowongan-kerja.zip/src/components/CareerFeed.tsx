import React, { useState, useEffect } from 'react';
import { FeedPost, FeedComment } from '../types';
import { Heart, ThumbsUp, MessageSquare, Send, Share2, Award, Bookmark, Filter, FileText, CheckCircle, PlusCircle, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CareerFeedProps {
  userName: string;
  userTitle: string;
}

export default function CareerFeed({ userName, userTitle }: CareerFeedProps) {
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filter Selection state
  const [activeFilter, setActiveFilter] = useState<'all' | 'status_update' | 'career_advice' | 'company_culture'>('all');

  // Input States for New Post
  const [isCreatingPost, setIsCreatingPost] = useState(false);
  const [postType, setPostType] = useState<'status_update' | 'career_advice' | 'company_culture'>('status_update');
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newTag, setNewTag] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Expand Comments map (postId -> boolean)
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  // New Comment input map (postId -> string)
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchFeed();
  }, []);

  const fetchFeed = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/feed');
      if (!res.ok) {
        throw new Error('Gagal memuat Career Feed.');
      }
      const data = await res.json();
      setPosts(data);
    } catch (err: any) {
      setError(err?.message || 'Gagal tersambung dengan server.');
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;

    setIsSubmitting(true);
    try {
      // Determine default tag based on post type if user hasn't specified
      let finalTag = newTag.trim();
      if (!finalTag) {
        if (postType === 'career_advice') finalTag = '#TipsKarir';
        else if (postType === 'company_culture') finalTag = '#BudayaKerja';
        else finalTag = '#Pemberitahuan';
      } else if (!finalTag.startsWith('#')) {
        finalTag = '#' + finalTag;
      }

      const res = await fetch('/api/feed', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          authorName: userName,
          authorTitle: userTitle,
          authorRole: 'kandidat',
          type: postType,
          title: postType !== 'status_update' ? newTitle.trim() : undefined,
          content: newContent.trim(),
          tag: finalTag,
        }),
      });

      if (!res.ok) {
        throw new Error('Gagal menerbitkan postingan.');
      }

      const createdPost = await res.json();
      setPosts((prev) => [createdPost, ...prev]);

      // Reset forms
      setNewContent('');
      setNewTitle('');
      setNewTag('');
      setIsCreatingPost(false);
    } catch (err: any) {
      alert(err.message || 'Gagal menerbitkan postingan baru.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLikePost = async (postId: string) => {
    // Optimistic Update
    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (post.id === postId) {
          const alreadyLiked = post.likes.includes(userName);
          return {
            ...post,
            likes: alreadyLiked
              ? post.likes.filter((u) => u !== userName)
              : [...post.likes, userName],
          };
        }
        return post;
      })
    );

    try {
      const res = await fetch(`/api/feed/${postId}/like`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userName }),
      });

      if (!res.ok) {
        throw new Error('Gagal memproses tombol suka.');
      }
      
      const updatedPost = await res.json();
      // Re-sync correct list of likes from backend
      setPosts((prevPosts) =>
        prevPosts.map((p) => (p.id === postId ? updatedPost : p))
      );
    } catch (err) {
      console.error('Like request error:', err);
    }
  };

  const handleAddComment = async (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const txt = commentInputs[postId]?.trim();
    if (!txt) return;

    // Clear comment text box optimistically
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));

    try {
      const res = await fetch(`/api/feed/${postId}/comment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          authorName: userName,
          authorTitle: userTitle,
          content: txt,
        }),
      });

      if (!res.ok) {
        throw new Error('Gagal mengirimkan komentar.');
      }

      const updatedPost = await res.json();
      // Re-sync comments
      setPosts((prevPosts) =>
        prevPosts.map((p) => (p.id === postId ? updatedPost : p))
      );
    } catch (err: any) {
      alert(err.message || 'Komentar gagal terkirim.');
    }
  };

  const toggleCommentsSection = (postId: string) => {
    setExpandedComments((prev) => ({
      ...prev,
      [postId]: !prev[postId],
    }));
  };

  const handleCommentInputChange = (postId: string, val: string) => {
    setCommentInputs((prev) => ({
      ...prev,
      [postId]: val,
    }));
  };

  const filteredPosts = posts.filter((post) => {
    if (activeFilter === 'all') return true;
    return post.type === activeFilter;
  });

  return (
    <div className="space-y-4" id="career-feed-root">
      {/* Feed Filter Header Section */}
      <div className="bg-white rounded-lg border border-[#e0e0e0] p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Share2 className="w-5 h-5 text-[#0a66c2]" />
              <span>Feed Karir & Budaya Kerja</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Bagikan pencapaian karir, ulasan saran, dan diskusikan dunia profesional.
            </p>
          </div>

          <button
            onClick={() => setIsCreatingPost(!isCreatingPost)}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#0a66c2] hover:bg-[#004182] text-white font-bold text-xs rounded-full transition-all duration-150 shadow-sm cursor-pointer shrink-0"
            id="btn-create-feed-post"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Bagikan Update</span>
          </button>
        </div>

        {/* Filter Badges */}
        <div className="flex items-center gap-1.5 mt-4 overflow-x-auto pb-1 scrollbar-none border-t border-slate-100 pt-3">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer shrink-0 select-none ${
              activeFilter === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Semua
          </button>
          <button
            onClick={() => setActiveFilter('status_update')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer shrink-0 select-none ${
              activeFilter === 'status_update'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            💡 Status & Pembaruan
          </button>
          <button
            onClick={() => setActiveFilter('career_advice')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer shrink-0 select-none ${
              activeFilter === 'career_advice'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            📚 Tips & Artikel Karir
          </button>
          <button
            onClick={() => setActiveFilter('company_culture')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer shrink-0 select-none ${
              activeFilter === 'company_culture'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            🏢 Budaya Kantor & HR
          </button>
        </div>
      </div>

      {/* Expandable Creation Card with Motion */}
      <AnimatePresence>
        {isCreatingPost && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white rounded-lg border border-[#0a66c2]/30 p-4 shadow-md space-y-3"
            id="panel-create-post"
          >
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-[#0a66c2]" />
                Buat Kiriman Profesional Anda
              </span>
              <button
                onClick={() => setIsCreatingPost(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-medium cursor-pointer"
              >
                Batal
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-3">
              {/* Post Type Selector */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPostType('status_update')}
                  className={`p-2.5 rounded-lg border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    postType === 'status_update'
                      ? 'border-[#0a66c2] bg-blue-50/50 text-[#0a66c2] font-semibold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  <span className="text-[10px]">Status Karir</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPostType('career_advice')}
                  className={`p-2.5 rounded-lg border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    postType === 'career_advice'
                      ? 'border-[#0a66c2] bg-blue-50/50 text-[#0a66c2] font-semibold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  <span className="text-[10px]">Artikel Tips</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPostType('company_culture')}
                  className={`p-2.5 rounded-lg border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    postType === 'company_culture'
                      ? 'border-[#0a66c2] bg-blue-50/50 text-[#0a66c2] font-semibold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                  <span className="text-[10px]">Info Budaya</span>
                </button>
              </div>

              {/* Title input (Visible for articles and culture posts) */}
              {postType !== 'status_update' && (
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                    Judul Artikel / Informasi
                  </label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Contoh: 'Strategi Jitu Menembus Interview HR'"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#0a66c2]"
                  />
                </div>
              )}

              {/* Tag Input */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                  Tagar / Topik (Opsional)
                </label>
                <input
                  type="text"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="Contoh: 'TipsKarir' atau 'Pemberitahuan'"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#0a66c2]"
                />
              </div>

              {/* Content Input */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                  Isi Postingan
                </label>
                <textarea
                  required
                  rows={4}
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder={
                    postType === 'status_update'
                      ? 'Bagikan update, proyek teranyar atau pemikiran karir Anda...'
                      : 'Tulis naskah lengkap bimbingan karir atau rincian budaya kantor...'
                  }
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#0a66c2] leading-relaxed"
                />
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  disabled={isSubmitting || !newContent.trim()}
                  className="px-5 py-1.5 bg-[#0a66c2] disabled:bg-slate-300 hover:bg-[#004182] text-white font-bold text-xs rounded-full flex items-center gap-1.5 transition cursor-pointer"
                >
                  {isSubmitting ? (
                    <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="w-3 h-3" />
                  )}
                  <span>Terbitkan Sekarang</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading state */}
      {loading && (
        <div className="p-12 text-center space-y-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <div className="w-8 h-8 border-3 border-slate-200 border-t-[#0a66c2] rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500 animate-pulse font-semibold uppercase tracking-wider">
            Memuat Data Feed Aktual...
          </p>
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <div className="p-5 text-center bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs flex items-center justify-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
          <button
            onClick={fetchFeed}
            className="underline font-bold ml-2 text-rose-900 cursor-pointer"
          >
            Coba Lagi
          </button>
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && filteredPosts.length === 0 && (
        <div className="p-12 text-center bg-white rounded-lg border border-slate-200 text-slate-400 space-y-2">
          <FileText className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="font-bold text-xs uppercase tracking-wider text-slate-500">
            Feed Kosong
          </p>
          <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
            Tidak ada kiriman untuk kategori ini. Jadilah yang pertama membagikan update karir atau saran hari ini!
          </p>
        </div>
      )}

      {/* Feed List */}
      {!loading && !error && filteredPosts.length > 0 && (
        <div className="space-y-4">
          {filteredPosts.map((post) => {
            const hasLiked = post.likes.includes(userName);
            const isRecruiter = post.authorRole === 'rekruter';
            
            // Generate simple initials for avatar
            const initials = post.authorName ? post.authorName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'U';

            return (
              <div
                key={post.id}
                className={`bg-white rounded-lg border border-[#e0e0e0] shadow-sm overflow-hidden transition hover:shadow-md ${
                  isRecruiter ? 'ring-1 ring-[#0a66c2]/15' : ''
                }`}
                id={`feed-card-${post.id}`}
              >
                {/* Header author details */}
                <div className="p-4 flex gap-3 items-start select-none">
                  {/* Dynamic Initials Avatar */}
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 border border-slate-100 ${
                    isRecruiter 
                      ? 'bg-gradient-to-tr from-[#0a66c2] to-blue-500 text-white' 
                      : 'bg-emerald-50 text-emerald-700'
                  }`}>
                    {initials}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm hover:underline hover:text-[#0a66c2] cursor-pointer">
                        {post.authorName}
                      </h4>
                      {isRecruiter && (
                        <span className="bg-[#0a66c2]/10 text-[#0a66c2] text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider">
                          Recruiter ✔
                        </span>
                      )}
                    </div>
                    
                    <p className="text-[10px] sm:text-xs text-slate-500 font-medium truncate">
                      {post.authorTitle}
                    </p>
                    
                    <p className="text-[9px] text-slate-400 font-normal mt-0.5">
                      {post.createdAt}
                    </p>
                  </div>

                  {/* Category Type Badge */}
                  <div className="shrink-0 text-right">
                    <span className={`px-2 py-0.5 text-[8px] font-extrabold uppercase tracking-widest rounded-full border ${
                      post.type === 'career_advice'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : post.type === 'company_culture'
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }`}>
                      {post.type === 'career_advice'
                        ? 'Tips Karir'
                        : post.type === 'company_culture'
                        ? 'Budaya Kerja'
                        : 'Pemberitahuan'}
                    </span>
                  </div>
                </div>

                {/* Main Post Content */}
                <div className="px-4 pb-3 space-y-2">
                  {post.title && (
                    <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 tracking-tight leading-snug">
                      {post.title}
                    </h3>
                  )}

                  {/* Body Text */}
                  <div className="text-[11px] sm:text-xs text-slate-700 leading-relaxed whitespace-pre-line break-words">
                    {post.content}
                  </div>

                  {/* Optional tag */}
                  {post.tag && (
                    <p className="text-[10px] font-bold text-[#0a66c2] hover:underline cursor-pointer inline-block mt-1">
                      {post.tag}
                    </p>
                  )}
                </div>

                {/* Stats row */}
                <div className="px-4 py-1.5 bg-slate-50/50 border-t border-slate-100 flex justify-between items-center text-[10px] text-slate-500 font-medium select-none">
                  <div className="flex items-center gap-1">
                    <span className="flex items-center justify-center w-4 h-4 rounded-full bg-blue-100 text-[#0a66c2]">
                      <ThumbsUp className="w-2.5 h-2.5 fill-[#0a66c2]" />
                    </span>
                    <span>{post.likes.length} menyukai</span>
                  </div>

                  <button
                    onClick={() => toggleCommentsSection(post.id)}
                    className="hover:underline hover:text-slate-800 cursor-pointer text-slate-500 text-[10px]"
                  >
                    {post.comments.length} komentar
                  </button>
                </div>

                {/* Interaction Action Row */}
                <div className="px-1 border-t border-b border-slate-100 flex items-center select-none">
                  <button
                    onClick={() => handleLikePost(post.id)}
                    className={`flex-1 py-2 hover:bg-slate-50 flex items-center justify-center gap-1.5 text-xs font-semibold cursor-pointer transition duration-150 rounded-[4px] ${
                      hasLiked ? 'text-[#0a66c2]' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <ThumbsUp className={`w-4 h-4 ${hasLiked ? 'fill-[#0a66c2] text-[#0a66c2]' : ''}`} />
                    <span>Lapor Suka</span>
                  </button>

                  <button
                    onClick={() => toggleCommentsSection(post.id)}
                    className="flex-1 py-2 hover:bg-slate-50 flex items-center justify-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer transition duration-150 rounded-[4px]"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Komentar ({post.comments.length})</span>
                  </button>
                </div>

                {/* Comment Expansion Panel */}
                <AnimatePresence>
                  {expandedComments[post.id] && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="bg-slate-50/50 divide-y divide-slate-100 border-b border-slate-150 overflow-hidden"
                    >
                      {/* Comments list */}
                      {post.comments.length > 0 && (
                        <div className="p-3 space-y-2.5 max-h-60 overflow-y-auto">
                          {post.comments.map((comment) => {
                            const cInitials = comment.authorName ? comment.authorName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'K';
                            return (
                              <div key={comment.id} className="flex gap-2.5 items-start text-[11px]">
                                <div className="w-6 h-6 rounded-full bg-slate-200 text-slate-700 font-extrabold flex items-center justify-center text-[9px] shrink-0 border border-slate-300">
                                  {cInitials}
                                </div>
                                <div className="flex-1 bg-white border border-slate-200 rounded-xl p-2.5 relative shadow-xs">
                                  <div className="flex justify-between items-center select-none">
                                    <span className="font-bold text-slate-800 text-[10px]">
                                      {comment.authorName}
                                    </span>
                                    <span className="text-[9px] text-slate-400 font-medium">
                                      {comment.createdAt}
                                    </span>
                                  </div>
                                  <p className="text-[9px] text-slate-400 -mt-0.5 mb-1 truncate max-w-[190px]">
                                    {comment.authorTitle}
                                  </p>
                                  <p className="text-slate-700 leading-relaxed text-[11px] font-normal leading-normal whitespace-pre-wrap break-words">
                                    {comment.content}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Comment Form */}
                      <form
                        onSubmit={(e) => handleAddComment(post.id, e)}
                        className="p-3 bg-white flex gap-2 items-center"
                      >
                        <div className="w-7.5 h-7.5 rounded-full bg-emerald-50 text-emerald-700 font-extrabold flex items-center justify-center text-xs border border-emerald-200 shrink-0 select-none">
                          {userName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                        </div>
                        <input
                          type="text"
                          required
                          value={commentInputs[post.id] || ''}
                          onChange={(e) => handleCommentInputChange(post.id, e.target.value)}
                          placeholder="Tulis ulasan opini Anda..."
                          className="flex-1 bg-slate-100 border border-transparent hover:bg-slate-200/70 focus:bg-white focus:ring-1 focus:ring-[#0a66c2] rounded-full px-3.5 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none transition duration-150"
                        />
                        <button
                          type="submit"
                          disabled={!commentInputs[post.id]?.trim()}
                          className="w-8 h-8 rounded-full bg-[#0a66c2]/10 text-[#0a66c2] hover:bg-[#0a66c2] hover:text-white disabled:bg-slate-50 disabled:text-slate-300 flex items-center justify-center transition cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </form>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
