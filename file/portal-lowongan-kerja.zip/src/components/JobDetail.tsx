import React, { useState, useEffect } from 'react';
import { Job } from '../types';
import { ArrowLeft, MapPin, Briefcase, Banknote, Clock, Sparkles, Send, FileText, CheckCircle2, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

interface JobDetailProps {
  job: Job;
  jobs?: Job[];
  savedJobIds?: string[];
  onToggleSave?: (jobId: string) => void;
  onBack: () => void;
  onSubmitApplication: (applicationData: {
    candidateName: string;
    candidateEmail: string;
    candidatePhone: string;
    linkedinUrl: string;
    cvText: string;
    coverLetter: string;
  }) => Promise<void>;
  isSubmitting: boolean;
}

export default function JobDetail({ 
  job, 
  jobs = [], 
  savedJobIds = [], 
  onToggleSave, 
  onBack, 
  onSubmitApplication, 
  isSubmitting 
}: JobDetailProps) {
  const [name, setName] = useState(() => {
    try {
      return localStorage.getItem('cari_kerja_user_name') || '';
    } catch {
      return '';
    }
  });
  const [email, setEmail] = useState(() => {
    try {
      return localStorage.getItem('cari_kerja_user_email') || '';
    } catch {
      return '';
    }
  });
  const [phone, setPhone] = useState(() => {
    try {
      return localStorage.getItem('cari_kerja_user_phone') || '';
    } catch {
      return '';
    }
  });
  const [linkedin, setLinkedin] = useState(() => {
    try {
      return localStorage.getItem('cari_kerja_user_linkedin') || '';
    } catch {
      return '';
    }
  });
  const [cvText, setCvText] = useState(() => {
    try {
      return localStorage.getItem('cari_kerja_user_cv') || '';
    } catch {
      return '';
    }
  });
  const [cover, setCover] = useState('');
  const [showApplyForm, setShowApplyForm] = useState(false);
  const [successApply, setSuccessApply] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isGeneratingCover, setIsGeneratingCover] = useState(false);

  const handleGenerateCoverLetter = async () => {
    if (!cvText || !cvText.trim()) {
      alert("Silakan isi ringkasan CV Anda terlebih dahulu agar AI memiliki informasi kualifikasi Anda.");
      return;
    }

    setIsGeneratingCover(true);
    try {
      const res = await fetch('/api/ai/generate-cover-letter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          cvText: cvText,
          jobTitle: job.title,
          jobCompany: job.company,
          jobDescription: job.description || (job.requirements ? job.requirements.join(', ') : ''),
          candidateName: name || 'Kandidat Papan Karir',
        }),
      });

      if (!res.ok) {
        throw new Error('Gagal memproses pembuatan draf oleh AI.');
      }

      const data = await res.json();
      if (data.coverLetter) {
        setCover(data.coverLetter);
      } else {
        throw new Error('Gagal menghasilkan teks dari AI.');
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Gagal membuat draf surat pengantar. Silakan periksa koneksi Anda.");
    } finally {
      setIsGeneratingCover(false);
    }
  };

  // Persist candidate data to localStorage on changes
  useEffect(() => {
    try {
      localStorage.setItem('cari_kerja_user_name', name);
      localStorage.setItem('cari_kerja_user_email', email);
      localStorage.setItem('cari_kerja_user_phone', phone);
      localStorage.setItem('cari_kerja_user_linkedin', linkedin);
      localStorage.setItem('cari_kerja_user_cv', cvText);
    } catch (err) {
      console.error("Failed to persist data with localStorage", err);
    }
  }, [name, email, phone, linkedin, cvText]);

  const isSaved = savedJobIds.includes(job.id);

  // Helper to parse salary range string (e.g., "Rp 16.000.000 - Rp 24.000.000") to numbers (in millions)
  const parseSalary = (salaryStr: string) => {
    const cleanNum = (str: string) => {
      const parsed = parseInt(str.replace(/[^\d]/g, ''), 10);
      return isNaN(parsed) ? 0 : parsed;
    };

    const parts = salaryStr.split('-');
    if (parts.length === 2) {
      const min = cleanNum(parts[0]);
      const max = cleanNum(parts[1]);
      return { min, max, avg: (min + max) / 2 };
    } else {
      const val = cleanNum(salaryStr);
      return { min: val, max: val, avg: val };
    }
  };

  // Helper to calculate dynamic CV Match Score and list matched/missing industry skills
  const getMatchDetails = (cv: string, jobData: Job) => {
    if (!cv || !cv.trim()) {
      return { 
        score: 0, 
        matched: [], 
        missing: [], 
        level: 'Belum Ada CV', 
        color: 'text-slate-400 bg-slate-50 border-slate-200',
        totalCount: 0
      };
    }

    const targetKeywords = new Set<string>();
    
    // Comprehensive industry skill list for matching
    const commonSkills = [
      'react', 'node', 'express', 'javascript', 'typescript', 'figma', 'ui/ux', 'ux', 'ui', 'design', 'desain',
      'laravel', 'php', 'python', 'django', 'flask', 'marketing', 'sales', 'seo', 'copywriting', 'financial', 
      'accounting', 'analisis', 'analytics', 'vue', 'angular', 'flutter', 'android', 'ios', 'kotlin', 'java', 
      'sql', 'postgres', 'mysql', 'mongodb', 'css', 'tailwind', 'sass', 'aws', 'cloud', 'docker', 'git', 'github', 
      'english', 'inggris', 'komunikasi', 'negosiasi', 'project management', 'agile', 'scrum', 'excel', 'word', 
      'hrd', 'recruitment', 'sourcing', 'training', 'b2b', 'crm', 'cold calling', 'social media', 'advertising',
      'content creator', 'video editing', 'photoshop', 'illustrator', 'premier', 'rest api', 'graphql', 'next.js'
    ];

    // Parse job title, category, and requirements to look for skills
    const textToScan = [
      jobData.title,
      jobData.category,
      jobData.description,
      ...(jobData.requirements || [])
    ].join(' ').toLowerCase();

    commonSkills.forEach(skill => {
      if (textToScan.includes(skill)) {
        targetKeywords.add(skill);
      }
    });

    // Also extract proper nouns/technical words (words with numbers or specific formats, or longer than 3 letters)
    const words = textToScan.match(/[A-Za-z0-9+#.-]+/g) || [];
    const ignoreList = [
      'dan', 'yang', 'untuk', 'dengan', 'dari', 'atau', 'pada', 'bisa', 'dapat', 'memiliki', 'menguasai', 'minimal', 'tahun',
      'kerja', 'dalam', 'serta', 'kemampuan', 'pengalaman', 'keahlian', 'posisi', 'bukan', 'ia', 'jika', 'kami', 'saya', 'anda',
      'di', 'ke', 'dari', 'sebagai', 'adalah', 'secara', 'baik', 'bisa', 'tinggi', 'mampu', 'melakukan', 'membuat', 'mengelola'
    ];
    words.forEach(word => {
      const wClean = word.replace(/[.,;:()]/g, '').toLowerCase();
      if (wClean.length >= 3 && wClean.length <= 15 && !ignoreList.includes(wClean) && isNaN(Number(wClean))) {
        if (/^[a-zA-Z0-9+#.-]+$/.test(wClean) && !targetKeywords.has(wClean)) {
          if ((jobData.requirements || []).some(r => r.toLowerCase().includes(wClean))) {
            targetKeywords.add(wClean);
          }
        }
      }
    });

    if (targetKeywords.size === 0) {
      ['komunikasi', 'kerja tim', 'analisis', 'adaptasi'].forEach(s => targetKeywords.add(s));
    }

    const targets = Array.from(targetKeywords);
    const cvLower = cv.toLowerCase();
    const matched: string[] = [];
    const missing: string[] = [];

    targets.forEach(skill => {
      const escaped = skill.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
      const regex = new RegExp(`\\b${escaped}\\b|${escaped}`, 'i');
      if (cvLower.includes(skill) || regex.test(cvLower)) {
        matched.push(skill);
      } else {
        missing.push(skill);
      }
    });

    let score = targets.length > 0 ? Math.round((matched.length / targets.length) * 100) : 0;
    
    if (cv.trim().length > 100 && score < 30) {
      score = Math.min(35, 10 + Math.floor(cv.trim().length / 20));
    }

    score = Math.max(0, Math.min(100, score));

    let level = 'Kecocokan Rendah';
    let color = 'text-rose-600 bg-rose-50 border-rose-200';
    if (score >= 80) {
      level = 'Sangat Cocok';
      color = 'text-emerald-600 bg-emerald-50 border-emerald-200';
    } else if (score >= 50) {
      level = 'Cukup Cocok';
      color = 'text-amber-600 bg-amber-50 border-amber-200';
    }

    return {
      score,
      matched,
      missing,
      level,
      color,
      totalCount: targets.length
    };
  };

  const matchDetails = getMatchDetails(cvText, job);

  // Group all available jobs by category to calculate averages
  const categorySalaries: { [key: string]: { minSum: number; maxSum: number; count: number } } = {};
  const allJobs = jobs.length > 0 ? jobs : [job];

  allJobs.forEach((j) => {
    const { min, max } = parseSalary(j.salary);
    if (min > 0 && max > 0) {
      if (!categorySalaries[j.category]) {
        categorySalaries[j.category] = { minSum: 0, maxSum: 0, count: 0 };
      }
      categorySalaries[j.category].minSum += min;
      categorySalaries[j.category].maxSum += max;
      categorySalaries[j.category].count += 1;
    }
  });

  const chartData = Object.keys(categorySalaries).map((category) => {
    const info = categorySalaries[category];
    const avgMinMillions = parseFloat(((info.minSum / info.count) / 1000000).toFixed(1));
    const avgMaxMillions = parseFloat(((info.maxSum / info.count) / 1000000).toFixed(1));
    return {
      category: category.length > 15 ? category.substring(0, 15) + '...' : category,
      fullCategory: category,
      "Min rata-rata": avgMinMillions,
      "Max rata-rata": avgMaxMillions,
    };
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!name || !email || !cvText) {
      setErrorMsg("Harap isi Nama Lengkap, Email, dan teks CV Anda.");
      return;
    }

    try {
      await onSubmitApplication({
        candidateName: name,
        candidateEmail: email,
        candidatePhone: phone,
        linkedinUrl: linkedin,
        cvText: cvText,
        coverLetter: cover
      });
      setSuccessApply(true);
    } catch (err) {
      console.error(err);
      setErrorMsg("Gagal mengirim lamaran. Silakan coba lagi.");
    }
  };

  return (
    <div className="space-y-6">
      {/* Header back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500 hover:text-[#0a66c2] transition cursor-pointer"
        id="btn-back-to-jobs"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Kembali ke Daftar Lowongan</span>
      </button>

      {/* Main Container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: Job Specifications */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg p-5 md:p-6 border border-[#e0e0e0] shadow-sm space-y-6">
            {/* Header info */}
            <div className="flex flex-wrap justify-between items-start gap-4">
              <div className="space-y-2.5 flex-1 min-w-[200px]">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-1 bg-blue-50 text-[#0a66c2] rounded-lg text-[10px] font-bold uppercase tracking-widest border border-blue-100">
                    {job.category}
                  </span>
                  {cvText && (
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest border flex items-center gap-1 ${
                      matchDetails.score >= 80 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                        : matchDetails.score >= 50 
                        ? 'bg-amber-50 text-amber-700 border-amber-200' 
                        : 'bg-rose-50 text-rose-700 border-rose-200'
                    }`}>
                      <Sparkles className="w-3 h-3 text-current" />
                      ATS MATCH: {matchDetails.score}%
                    </span>
                  )}
                </div>
                <h1 className="text-xl md:text-2xl font-bold text-slate-950 leading-tight">
                  {job.title}
                </h1>
                <p className="text-xs font-bold text-[#0a66c2] uppercase tracking-wider">
                  {job.company}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {onToggleSave && (
                  <button
                    onClick={() => onToggleSave(job.id)}
                    className={`p-2 border rounded-full transition duration-150 cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                      isSaved
                        ? 'bg-rose-50 border-rose-200 text-rose-500 hover:bg-rose-100'
                        : 'bg-white border-slate-250 text-slate-600 hover:text-[#0a66c2] hover:bg-slate-50'
                    }`}
                    id="btn-toggle-save-header"
                  >
                    <Heart className={`w-4 h-4 ${isSaved ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span className="hidden sm:inline">{isSaved ? 'Disimpan' : 'Simpan'}</span>
                  </button>
                )}

                <div className="px-3.5 py-2 bg-slate-50 rounded-lg border border-slate-200 text-right">
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Gaji Bulanan</p>
                  <p className="text-xs font-extrabold text-[#0a66c2]">{job.salary}</p>
                </div>
              </div>
            </div>

            {/* Quick specifications */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 border-t border-b border-dashed border-[#e);] border-slate-200 py-4">
              <div className="flex items-center gap-2.5">
                <MapPin className="w-4 h-4 text-[#0a66c2]" />
                <div className="text-xs">
                  <p className="text-slate-400 font-medium">Lokasi</p>
                  <p className="font-bold text-slate-700">{job.location}</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Briefcase className="w-4 h-4 text-[#0a66c2]" />
                <div className="text-xs">
                  <p className="text-slate-400 font-medium">Tipe Kontrak</p>
                  <p className="font-bold text-slate-700">{job.type}</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#0a66c2]" />
                <div className="text-xs">
                  <p className="text-slate-400 font-medium">Tanggal Posting</p>
                  <p className="font-bold text-slate-700">{job.postedAt}</p>
                </div>
              </div>
            </div>

            {/* General description */}
            <div className="space-y-2">
              <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider border-l-2 border-[#0a66c2] pl-2.5">Deskripsi Pekerjaan</h3>
              <p className="text-slate-600 text-xs md:text-xs leading-relaxed whitespace-pre-line antialiased">
                {job.description}
              </p>
            </div>

            {/* Requirements list */}
            {job.requirements && job.requirements.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider border-l-2 border-[#0a66c2] pl-2.5">Persyaratan Utama</h3>
                <ul className="space-y-2">
                  {job.requirements.map((req, i) => (
                    <li key={i} className="flex gap-2.5 text-slate-600 text-xs align-top leading-relaxed antialiased">
                      <span className="font-bold text-[#0a66c2] pt-0.5">•</span>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Benefits list */}
            {job.benefits && job.benefits.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider border-l-2 border-emerald-500 pl-2.5">Fasilitas & Keuntungan</h3>
                <ul className="space-y-2">
                  {job.benefits.map((ben, i) => (
                    <li key={i} className="flex gap-2.5 text-slate-600 text-xs align-top leading-relaxed antialiased">
                      <span className="font-bold text-emerald-500 pt-0.5">✔</span>
                      <span>{ben}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Match Score ATS Analysis */}
          <div className="bg-white rounded-lg p-5 border border-[#e0e0e0] shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#f3f2f0] font-sans">
              <div className="flex items-center gap-2.5">
                <span className="p-1.5 bg-blue-50 border border-blue-100 rounded-lg flex items-center justify-center text-[#0a66c2]">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </span>
                <div>
                  <h3 className="font-bold text-slate-950 text-xs uppercase tracking-wider">
                    ANALISIS KECOCOKAN CV (AI ATS DETECTOR)
                  </h3>
                  <p className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wider font-mono">
                    Sistem Penilaian Kelayakan Lamaran Kerja
                  </p>
                </div>
              </div>
              
              {/* Dynamic Badge */}
              {cvText && (
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider border text-center ${
                  matchDetails.score >= 80 
                    ? 'text-emerald-700 bg-emerald-50 border-emerald-200' 
                    : matchDetails.score >= 50 
                    ? 'text-amber-700 bg-amber-50 border-amber-200' 
                    : 'text-rose-700 bg-rose-50 border-rose-200'
                }`}>
                  {matchDetails.level}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              {/* Left grid: Match score visual ring */}
              <div className="md:col-span-4 flex flex-col items-center text-center p-4 bg-slate-50 border border-slate-100 rounded-xl relative justify-center min-h-[160px]">
                {/* Visual Ring */}
                <div className="relative w-28 h-28 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    {/* Circle Background */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      className="stroke-slate-200"
                      strokeWidth="8"
                      fill="transparent"
                    />
                    {/* Circle Progress */}
                    <motion.circle
                      cx="50"
                      cy="50"
                      r="40"
                      className={`${
                        matchDetails.score >= 80 
                          ? 'stroke-emerald-500' 
                          : matchDetails.score >= 50 
                          ? 'stroke-amber-500' 
                          : 'stroke-rose-500'
                      } transition-all duration-1000 ease-out`}
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={`${2 * Math.PI * 40}`}
                      strokeDashoffset={`${2 * Math.PI * 40 * (1 - matchDetails.score / 100)}`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-extrabold text-slate-800 leading-none">
                      {matchDetails.score}%
                    </span>
                    <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide mt-1">
                      Kecocokan
                    </span>
                  </div>
                </div>
                
                {cvText ? (
                  <p className="text-[10px] text-slate-500 font-medium mt-3">
                    Terdeteksi <strong className="text-slate-800">{matchDetails.matched.length}</strong> dari <strong className="text-slate-800">{matchDetails.totalCount}</strong> kualifikasi utama.
                  </p>
                ) : (
                  <p className="text-[10px] text-slate-400 font-medium mt-3">
                    CV belum dikonfigurasi
                  </p>
                )}
              </div>

              {/* Right grid: Live explanation and actions */}
              <div className="md:col-span-8 space-y-4">
                {!cvText ? (
                  <div className="space-y-3">
                    <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wide">
                      Mulai Deteksi Skor CV Anda Instan
                    </h4>
                    <p className="text-slate-500 text-xs leading-relaxed">
                      Bagaimana tingkat kesiapan draf CV Anda menghadapi kriteria saringan perusahaan ini? Silakan tulis atau tempel kelengkapan dari CV Anda (Keahlian, Pengalaman kerja, tools/techstack, dll.) di kotak input berikut:
                    </p>
                    <textarea
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-sans leading-relaxed transition"
                      rows={3}
                      placeholder="Tempel ringkasan keahlian, teknologi (React, Node, Laravel, SEO dll), atau riwayat karir Anda..."
                      value={cvText}
                      onChange={(e) => setCvText(e.target.value)}
                      id="ats-cv-quick-input"
                    />
                    <p className="text-[10px] text-indigo-500 font-bold uppercase tracking-wider flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Data CV akan tersimpan secara otomatis untuk mempermudah pendaftaran!</span>
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wide">
                        Analisis Keahlian Kunci
                      </h4>
                      <p className="text-slate-500 text-[11px] leading-relaxed">
                        Kami membandingkan isi CV Anda secara real-time dengan persyaratan yang dicari oleh <strong className="text-slate-700">{job.company}</strong>:
                      </p>
                    </div>

                    {/* Matched Pill list */}
                    <div className="space-y-2">
                      {matchDetails.matched.length > 0 && (
                        <div className="space-y-1.5">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Keahlian yang Sesuai:
                          </span>
                          <div className="flex flex-wrap gap-1.5 font-mono">
                            {matchDetails.matched.map((skill, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-150 rounded-lg text-[10px] font-semibold flex items-center gap-1 uppercase tracking-wider font-mono"
                              >
                                <span>✓</span>
                                <span>{skill}</span>
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Missing Pill list */}
                      {matchDetails.missing.length > 0 && (
                        <div className="space-y-1.5">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Disarankan untuk Ditambahkan:
                          </span>
                          <div className="flex flex-wrap gap-1.5 font-mono">
                            {matchDetails.missing.map((skill, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-500 border border-dashed border-slate-300 rounded-lg text-[10px] font-medium flex items-center gap-1 uppercase tracking-wider font-mono hover:text-indigo-600 hover:border-indigo-300 cursor-pointer transition duration-150 select-none"
                                title="Klik untuk menyisipkan ke dalam CV draf Anda"
                                onClick={() => {
                                  setCvText(prev => {
                                    const trimmed = prev.trim();
                                    return trimmed ? `${trimmed}\n- Memiliki keahlian ${skill}` : `Memiliki keahlian ${skill}`;
                                  });
                                }}
                              >
                                <span className="text-indigo-500 font-bold font-sans">+</span>
                                <span>{skill}</span>
                              </span>
                            ))}
                          </div>
                          <p className="text-[10.5px] text-slate-400 leading-relaxed font-sans mt-1 italic">
                            Tip: Klik tombol <span className="font-extrabold text-slate-500 font-mono">+</span> di atas untuk menyisipkan keahlian tersebut, atau edit CV agar memuat kata kunci di atas.
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Action buttons */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-4">
                      <p className="text-[10px] text-slate-400 max-w-xs leading-relaxed">
                        Data CV Anda disinkronkan secara real-time dengan formulir pendaftaran kerja di bagian kanan.
                      </p>
                      
                      <button
                        onClick={() => {
                          const el = document.getElementById('ats-cv-quick-input-modal-trigger');
                          if (el) {
                            el.classList.toggle('hidden');
                          }
                        }}
                        className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-lg text-[10px] transition uppercase tracking-wider border border-slate-200 cursor-pointer flex items-center gap-1"
                        id="btn-edit-quickcv"
                      >
                        <FileText className="w-3.5 h-3.5 text-slate-500" />
                        <span>Edit Draf CV</span>
                      </button>
                    </div>

                    {/* Collapsible Edit Area */}
                    <div id="ats-cv-quick-input-modal-trigger" className="hidden border-t border-slate-100 pt-3.5 space-y-2">
                      <div className="flex justify-between items-center bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-xl">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-none">
                          Draf Teks CV Anda:
                        </label>
                        <button
                          onClick={() => {
                            setCvText('');
                          }}
                          className="text-slate-400 hover:text-red-500 text-[9px] uppercase font-bold"
                          type="button"
                        >
                          Hapus Semua
                        </button>
                      </div>
                      <textarea
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] text-xs font-sans leading-relaxed transition bg-white"
                        rows={4}
                        value={cvText}
                        onChange={(e) => setCvText(e.target.value)}
                        id="ats-cv-quick-input-edit"
                      />
                      <div className="flex justify-between items-center bg-slate-50 border border-slate-100 p-2 rounded-lg">
                        <span className="text-[9px] text-slate-400 font-medium font-mono">Panjang: {cvText.length} karakter</span>
                        <button
                          onClick={() => {
                            const el = document.getElementById('ats-cv-quick-input-modal-trigger');
                            if (el) el.classList.add('hidden');
                          }}
                          className="px-2 py-1 bg-[#0a66c2] hover:bg-[#004182] text-white font-bold rounded-lg text-[9px] transition uppercase tracking-wider cursor-pointer"
                          type="button"
                        >
                          Selesai Edit
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Salary Comparison Chart Card */}
          <div className="bg-white rounded-lg p-5 border border-[#e0e0e0] shadow-sm space-y-4">
            <div className="flex items-center gap-2.5 pb-2 border-b border-[#f3f2f0]">
              <span className="p-1.5 bg-blue-50 border border-blue-100 rounded-lg flex items-center justify-center">
                <Banknote className="w-5 h-5 text-[#0a66c2]" />
              </span>
              <div>
                <h3 className="font-bold text-slate-950 text-xs uppercase tracking-wider">
                  Analisis Tren Gaji Industri
                </h3>
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                  Rata-rata Gaji Bulanan berdasarkan Kategori Pekerjaan (Juta Rp)
                </p>
              </div>
            </div>

            {chartData && chartData.length > 0 ? (
              <div className="h-60 w-full" id="salary-recharts-container" style={{ fontSize: '10px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 15, right: 10, left: -20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="category" 
                      tick={{ fill: '#64748b', fontSize: 10 }}
                      axisLine={{ stroke: '#cbd5e1' }}
                      tickLine={{ stroke: '#cbd5e1' }}
                    />
                    <YAxis 
                      tick={{ fill: '#64748b', fontSize: 10 }}
                      axisLine={{ stroke: '#cbd5e1' }}
                      tickLine={{ stroke: '#cbd5e1' }}
                      unit=" jt"
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#ffffff', 
                        border: '1px solid #cbd5e1', 
                        borderRadius: '8px',
                        fontSize: '11px',
                        color: '#334155'
                      }}
                      labelStyle={{ fontWeight: 'bold', color: '#1e293b' }}
                    />
                    <Legend 
                      verticalAlign="top" 
                      height={32} 
                      iconType="circle"
                      iconSize={8}
                      wrapperStyle={{ fontSize: 11, fontWeight: 'bold', color: '#475569' }}
                    />
                    <Bar 
                      dataKey="Min rata-rata" 
                      fill="#0a66c2" 
                      radius={[3, 3, 0, 0]} 
                      name="Min Rata-rata"
                    />
                    <Bar 
                      dataKey="Max rata-rata" 
                      fill="#3da0f5" 
                      radius={[3, 3, 0, 0]} 
                      name="Max Rata-rata"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="p-6 text-center text-slate-400 border border-dashed border-slate-200 rounded-lg bg-slate-50 text-xs">
                Data gaji untuk analisis tidak memadai.
              </div>
            )}
            
            <div className="p-3.5 bg-blue-50/50 border border-blue-100 rounded-lg flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-[#0a66c2] shrink-0 mt-0.5" />
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Posisi Anda sebagai <strong className="text-slate-800">{job.title}</strong> di kategori <strong className="text-[#0a66c2] font-semibold uppercase text-[10px] tracking-wider">{job.category}</strong> menawarkan gaji <strong className="text-slate-900 font-bold">{job.salary}</strong>. Komparasi ini dihitung secara dinamis berdasarkan seluruh lowongan aktif di platform Papan Karir.
              </p>
            </div>
          </div>
        </div>

        {/* Right column: Action Board & Application Form */}
        <div className="space-y-6">
          {!successApply ? (
            <div className="bg-white rounded-lg p-5 border border-[#e0e0e0] shadow-sm space-y-4">
              {!showApplyForm ? (
                <>
                  <h3 className="font-bold text-slate-950 text-xs uppercase tracking-wider">Langkah Pelamaran</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Kirim lamaran Anda secara instan di sini. Data kualifikasi Anda akan secara otomatis dideteksi dan dicocokkan dengan persyaratan kerja menggunakan **Gemini AI Review**.
                  </p>
                  
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowApplyForm(true)}
                      className="flex-1 py-2.5 bg-[#0a66c2] hover:bg-[#004182] text-white font-bold rounded-lg hover:shadow-none transition cursor-pointer text-xs uppercase tracking-wider"
                      id="btn-open-apply-form"
                    >
                      Lamar Pekerjaan Ini
                    </button>
                    {onToggleSave && (
                      <button
                        onClick={() => onToggleSave(job.id)}
                        className={`px-3.5 py-2.5 border rounded-lg transition duration-200 cursor-pointer flex items-center justify-center ${
                          isSaved
                            ? 'bg-rose-50 border-rose-200 text-rose-500 hover:bg-rose-100'
                            : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                        }`}
                        title={isSaved ? 'Hapus dari Tersimpan' : 'Simpan Pekerjaan'}
                        id="btn-toggle-save-detail"
                      >
                        <Heart className={`w-4 h-4 ${isSaved ? 'fill-rose-500 text-rose-500' : ''}`} />
                      </button>
                    )}
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <h3 className="font-semibold text-slate-950 text-xs uppercase tracking-wider flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-[#0a66c2]" />
                      <span>Kirim Lamaran</span>
                    </h3>
                    <button
                      onClick={() => setShowApplyForm(false)}
                      className="text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-red-500 cursor-pointer"
                    >
                      Batal
                    </button>
                  </div>

                  {errorMsg && (
                    <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs font-medium">
                      {errorMsg}
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-slate-600 font-bold mb-1">Nama Lengkap *</label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs transition"
                        placeholder="Contoh: Budi Santoso"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        id="form-apply-name"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-600 font-bold mb-1">Email *</label>
                        <input
                          type="email"
                          required
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs transition"
                          placeholder="budi@example.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          id="form-apply-email"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 font-bold mb-1">No.Telepon</label>
                        <input
                          type="tel"
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs transition"
                          placeholder="0812345678"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          id="form-apply-phone"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1">LinkedIn URL</label>
                      <input
                        type="url"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs transition"
                        placeholder="https://linkedin.com/in/username"
                        value={linkedin}
                        onChange={(e) => setLinkedin(e.target.value)}
                        id="form-apply-linkedin"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 font-bold mb-1 font-sans flex items-center justify-between">
                        <span>Ringkasan CV (Pengalaman & Keahlian) *</span>
                        <span className="text-[9px] text-[#0a66c2] font-bold font-mono uppercase tracking-wider">Dianalisis oleh AI</span>
                      </label>
                      <textarea
                        required
                        rows={6}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-700 leading-relaxed font-sans transition"
                        placeholder="Tuliskan posisi kerja sebelumnya, pencapaian karir, keahlian utama, dan pendidikan Anda secara terperinci agar AI HRD dapat menganalisis kecocokan secara maksimal..."
                        value={cvText}
                        onChange={(e) => setCvText(e.target.value)}
                        id="form-apply-cvtext"
                      />
                      <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                        Tip: Cantumkan techstack atau keahlian utama yang relevan dengan syarat lowongan ini.
                      </p>
                    </div>

                     <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-slate-600 font-bold">Surat Pengantar (Cover Letter)</label>
                        <button
                          type="button"
                          disabled={isGeneratingCover}
                          onClick={handleGenerateCoverLetter}
                          className="text-[10px] text-[#0a66c2] hover:text-[#004182] font-bold flex items-center gap-1 cursor-pointer disabled:text-slate-400 disabled:cursor-not-allowed transition"
                          id="btn-generate-cover-letter"
                        >
                          {isGeneratingCover ? (
                            <>
                              <div className="w-3 h-3 border-2 border-[#0a66c2]/40 border-t-[#0a66c2] rounded-full animate-spin" />
                              <span>Membuat draf...</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3 h-3.5" />
                              <span>Buat draf dengan AI</span>
                            </>
                          )}
                        </button>
                      </div>
                      
                      {!cvText || !cvText.trim() ? (
                        <p className="text-[10px] text-amber-600 mb-1.5 leading-normal italic">
                          💡 Isi Ringkasan CV di atas terlebih dahulu untuk drafting otomatis AI yang akurat.
                        </p>
                      ) : null}

                      <textarea
                        rows={12}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs transition leading-relaxed font-sans"
                        placeholder="Tulis alasan kenapa Anda bersemangat atau klik tombol 'Buat draf dengan AI' untuk menjadikannya otomatis..."
                        value={cover}
                        onChange={(e) => setCover(e.target.value)}
                        id="form-apply-cover"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-2.5 bg-[#0a66c2] hover:bg-[#004182] disabled:bg-slate-350 text-white font-bold rounded-lg transition text-xs flex justify-center items-center gap-2 cursor-pointer uppercase tracking-wider shadow-none"
                      id="form-apply-submit"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                          <span>Menganalisis CV dengan AI...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>Kirim Lamaran Sekarang</span>
                        </>
                      )}
                    </button>
                    
                    <p className="text-[9px] text-slate-450 text-center leading-relaxed mt-2 p-2 bg-[#f3f2f0] border border-slate-200 rounded-lg">
                      Dengan menekan kirim, CV Anda akan dievaluasi oleh Gemini AI secara otomatis untuk memprediksi kecocokan kerja.
                    </p>
                  </form>
                </div>
              )}
            </div>
          ) : (
            <motion.div
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-emerald-55 border border-emerald-200 rounded-lg p-5 text-center space-y-4 font-inherit shadow-none"
            >
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
              <div className="space-y-1">
                <h3 className="font-bold text-emerald-800 text-xs uppercase tracking-wider">Lamaran Berhasil Kirim!</h3>
                <p className="text-xs text-emerald-700 leading-relaxed font-inherit">
                  Terima kasih, **{name}**. Berkas lamaran Anda telah berhasil disubmit ke **{job.company}** untuk posisi **{job.title}**.
                </p>
              </div>

              <div className="p-3.5 bg-white rounded-lg text-left border border-slate-200 text-xs space-y-1.5 leading-relaxed">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <Sparkles className="w-3.5 h-3.5 text-[#0a66c2] animate-pulse" />
                  <span>Cek Hasil AI Screening</span>
                </div>
                <p className="text-slate-500 text-[11px] leading-relaxed font-inherit">
                  Kami telah menganalisis kelayakan CV Anda menggunakan AI. Navigasikan ke tab **"Lamaran Saya"** di menu navigasi utama untuk membaca ulasan skor, kelebihan, kelemahan, serta tips peningkatannya.
                </p>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    const btn = document.getElementById('tab-btn-applications');
                    if (btn) btn.click();
                  }}
                  className="w-full py-2 bg-[#0a66c2] hover:bg-[#004182] text-white font-bold rounded-lg text-xs cursor-pointer transition uppercase tracking-wider shadow-none"
                >
                  Lihat Analisis CV Saya
                </button>
                <button
                  onClick={onBack}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-lg cursor-pointer transition uppercase tracking-wider border border-slate-200"
                >
                  Kembali ke Lowongan
                </button>
              </div>
            </motion.div>
          )}

          {/* AI Info Card */}
          <div className="bg-slate-50 border border-[#e0e0e0] rounded-lg p-4 space-y-2.5 shadow-none font-inherit">
            <div className="flex items-center gap-2">
              <span className="p-1 px-1.5 bg-blue-50 border border-blue-100 rounded text-[#0a66c2] font-bold text-[9px] uppercase font-mono tracking-wider">
                AI Tech
              </span>
              <h4 className="font-bold text-slate-950 text-xs uppercase tracking-wider">Simulasi Wawancara AI</h4>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Tahukah Anda? Anda dapat berlatih wawancara kerja secara langsung untuk posisi **{job.title}** menggunakan chatbot Pewawancara AI interaktif kami!
            </p>
            <button
              onClick={() => {
                const mockInterviewNav = document.getElementById('tab-btn-interview');
                if (mockInterviewNav) {
                  localStorage.setItem('auto_select_job_id', job.id);
                  mockInterviewNav.click();
                }
              }}
              className="inline-flex items-center gap-1 font-bold text-[#0a66c2] text-xs hover:underline cursor-pointer"
            >
              <span>Mulai Latihan Wawancara AI</span>
              <span>&rarr;</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
