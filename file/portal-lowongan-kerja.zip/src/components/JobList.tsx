import React, { useState, useEffect } from 'react';
import { Job } from '../types';
import { Search, MapPin, Briefcase, Banknote, Sparkles, Clock, ChevronRight, Heart } from 'lucide-react';
import { motion } from 'motion/react';

interface JobListProps {
  jobs: Job[];
  savedJobIds: string[];
  onToggleSave: (jobId: string) => void;
  onSelectJob: (job: Job) => void;
  onPostJobClick: () => void;
}

export default function JobList({ jobs, savedJobIds, onToggleSave, onSelectJob, onPostJobClick }: JobListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('Semua');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [selectedLocation, setSelectedLocation] = useState<string>('Semua');
  const [viewMode, setViewMode] = useState<'all' | 'saved'>('all');

  // Synchronize global search updates from the header
  useEffect(() => {
    const handleGlobalSearch = (e: any) => {
      setSearchTerm(e.detail || '');
    };
    
    // Check initial global search
    const initial = localStorage.getItem('cari_kerja_global_search');
    if (initial) {
      setSearchTerm(initial);
      localStorage.removeItem('cari_kerja_global_search'); // consume
    }

    const handleShowSaved = () => {
      setViewMode('saved');
    };

    window.addEventListener('globalSearchUpdated', handleGlobalSearch as any);
    window.addEventListener('showSavedJobs', handleShowSaved);
    
    return () => {
      window.removeEventListener('globalSearchUpdated', handleGlobalSearch as any);
      window.removeEventListener('showSavedJobs', handleShowSaved);
    };
  }, []);

  // Categories extraction
  const categories = ['Semua', ...Array.from(new Set(jobs.map((j) => j.category)))];
  const locations = ['Semua', ...Array.from(new Set(jobs.map((j) => j.location)))];
  const jobTypes = ['Semua', 'Full-Time', 'Part-Time', 'Kontrak', 'Internship', 'Remote'];

  // Filter logic
  const filteredJobs = jobs.filter((job) => {
    if (viewMode === 'saved' && !savedJobIds.includes(job.id)) {
      return false;
    }

    const matchesSearch =
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = selectedType === 'Semua' || job.type === selectedType;
    const matchesCategory = selectedCategory === 'Semua' || job.category === selectedCategory;
    const matchesLocation = selectedLocation === 'Semua' || job.location === selectedLocation;

    return matchesSearch && matchesType && matchesCategory && matchesLocation;
  });

  return (
    <div className="space-y-5 font-inherit">
      {/* LinkedIn Sleek Blue Info Header Banner */}
      <div className="bg-gradient-to-r from-[#0a66c2] to-[#004182] text-white rounded-lg p-5 shadow-sm relative overflow-hidden select-none">
        <div className="absolute right-[-10%] top-[-20%] w-60 h-60 bg-blue-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white/10 text-white rounded-full text-[10px] font-semibold border border-white/15 uppercase tracking-wide">
              <Sparkles className="w-3 h-3 text-yellow-300 fill-yellow-300" />
              <span>Rekomendasi Loker AI Aktif</span>
            </div>
            <h2 className="text-lg md:text-xl font-bold tracking-tight mt-1.5">
              Peluang Karir Impian Anda Menanti
            </h2>
            <p className="text-blue-105 text-xs max-w-xl font-light">
              Gunakan asisten kecerdasan buatan untuk menguji keakuratan CV ATS Anda terhadap lowongan pilihan secara langsung di sini.
            </p>
          </div>
          <button
            onClick={onPostJobClick}
            className="px-4 py-2 bg-white hover:bg-slate-50 text-[#0a66c2] font-bold rounded-full text-xs cursor-pointer shadow-sm border border-transparent transition-all self-start md:self-center shrink-0 uppercase tracking-wider"
            id="btn-hero-post-job"
          >
            Pasang Lowongan +
          </button>
        </div>
      </div>

      {/* Modern Integrated Search & Advanced Filter Console */}
      <div className="bg-white rounded-lg border border-[#e0e0e0] p-4 shadow-sm space-y-4 font-inherit">
        <div className="p-1 rounded-md bg-slate-50 border border-slate-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-1 md:divide-x md:divide-slate-200">
            {/* Column 1: Keyword Search */}
            <div className="relative p-1.5 flex items-center">
              <Search className="absolute left-3 w-4 h-4 text-slate-400 shrink-0" />
              <input
                id="input-search-jobs"
                type="text"
                placeholder="Cari lowongan atau perusahaan..."
                className="w-full pl-8 pr-3 py-1 bg-transparent border-0 focus:outline-none focus:ring-0 text-xs font-medium text-slate-700 placeholder-slate-400 font-inherit"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Column 2: Location Select */}
            <div className="relative p-1.5 flex items-center">
              <MapPin className="absolute left-3 w-4 h-4 text-slate-400 shrink-0" />
              <select
                id="select-location"
                className="w-full pl-8 pr-3 py-1 bg-transparent border-0 focus:outline-none focus:ring-0 text-xs font-medium text-slate-700 font-inherit cursor-pointer"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
              >
                <option value="Semua">Semua Lokasi</option>
                {locations.filter(l => l !== 'Semua').map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            {/* Column 3: Job Type Selector */}
            <div className="relative p-1.5 flex items-center">
              <Briefcase className="absolute left-3 w-4 h-4 text-slate-400" />
              <select
                id="select-employment-type"
                className="w-full pl-8 pr-3 py-1 bg-transparent border-0 focus:outline-none focus:ring-0 text-xs font-medium text-slate-700 font-inherit cursor-pointer"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
              >
                {jobTypes.map((type) => (
                  <option key={type} value={type}>
                    {type === 'Semua' ? 'Semua Tipe Karir' : type}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Dynamic & Beautiful Horizontal Categories Slider */}
        <div className="flex flex-col gap-2 pt-1 font-inherit">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-inherit">Telusuri Bidang:</span>
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-[11px] font-semibold transition duration-200 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#0a66c2] text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-250'
                }`}
                id={`btn-filter-category-${cat}`}
              >
                {cat === 'Semua' ? 'Semua Bidang' : cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Results Container */}
      <div className="space-y-4 font-inherit">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-250 pb-3 px-1 font-inherit">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setViewMode('all')}
              className={`pb-1 text-xs uppercase tracking-wider font-bold transition cursor-pointer relative ${
                viewMode === 'all' ? 'text-[#0a66c2]' : 'text-slate-400 hover:text-slate-600'
              }`}
              id="btn-view-mode-all"
            >
              Semua Lowongan ({jobs.length})
              {viewMode === 'all' && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[3px] bg-[#0a66c2] rounded-full animate-none" />
              )}
            </button>
            <button
              onClick={() => setViewMode('saved')}
              className={`pb-1 text-xs uppercase tracking-wider font-bold transition cursor-pointer relative flex items-center gap-1.5 ${
                viewMode === 'saved' ? 'text-[#0a66c2]' : 'text-slate-400 hover:text-slate-600'
              }`}
              id="btn-view-mode-saved"
            >
              <Heart className={`w-3.5 h-3.5 ${viewMode === 'saved' ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span>Disimpan ({savedJobIds.length})</span>
              {viewMode === 'saved' && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[3px] bg-[#0a66c2] rounded-full animate-none" />
              )}
            </button>
          </div>
          
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-inherit bg-slate-200/85 px-2.5 py-1 rounded-md">
            Ditemukan {filteredJobs.length} Lowongan Kerja
          </span>
        </div>

        {filteredJobs.length === 0 ? (
          viewMode === 'saved' ? (
            <div className="bg-white border border-[#e0e0e0] rounded-lg p-12 text-center text-slate-500 space-y-4 shadow-sm font-inherit">
              <span className="inline-flex p-3 bg-rose-50 border border-rose-100 rounded-full text-rose-500 shrink-0 mx-auto">
                <Heart className="w-6 h-6 fill-rose-500 text-rose-500" />
              </span>
              <div className="space-y-1 font-inherit">
                <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Belum ada lowongan tersimpan</h3>
                <p className="text-xs max-w-sm mx-auto text-slate-400 leading-relaxed font-inherit">
                  Temukan lowongan yang menarik perhatian Anda, lalu simpan dengan menekan ikon hati untuk melacaknya di sini.
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-[#e0e0e0] rounded-lg p-12 text-center text-slate-500 space-y-3 shadow-sm font-inherit">
              <Briefcase className="w-8 h-8 text-slate-400 mx-auto" />
              <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Tidak ada lowongan kerja yang cocok</h3>
              <p className="text-xs max-w-sm mx-auto text-slate-400 leading-relaxed font-inherit">
                Kata kunci atau penyaringan Anda tidak menemukan kecocokan aktif saat ini. Coba bersihkan atau ganti kueri Anda.
              </p>
            </div>
          )
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-inherit">
            {filteredJobs.map((job, idx) => {
              const getIcon = (type: string, company: string) => {
                return (
                  <span className={`w-12 h-12 rounded-lg shrink-0 ${job.logoBg || 'bg-slate-100 text-slate-700'} flex items-center justify-center font-bold text-sm border border-slate-200 text-center select-none shadow-sm`}>
                    {(company || type).substring(0, 2).toUpperCase()}
                  </span>
                );
              };

              const isSaved = savedJobIds.includes(job.id);

              return (
                <motion.div
                  key={job.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, delay: Math.min(idx * 0.03, 0.2) }}
                  onClick={() => onSelectJob(job)}
                  className="bg-white p-4 rounded-lg border border-[#e0e0e0] hover:bg-slate-55 cursor-pointer transition duration-150 flex flex-col justify-between h-full group font-inherit shadow-none"
                  id={`job-card-${job.id}`}
                >
                  <div className="space-y-3 font-inherit">
                    {/* Top Section */}
                    <div className="flex justify-between items-start font-inherit">
                      <div className="flex items-start gap-3">
                        {getIcon(job.title, job.company)}
                        <div>
                          <p className="font-semibold text-[#0a66c2] text-[11px] uppercase tracking-wide font-inherit">
                            {job.company}
                          </p>
                          <h3 className="font-bold text-slate-950 group-hover:underline text-sm md:text-sm leading-snug font-inherit">
                            {job.title}
                          </h3>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1.5 shrink-0">
                        {job.isFeatured && (
                          <span className="px-2 py-0.5 bg-blue-50 text-[#0a66c2] font-semibold text-[9px] rounded tracking-wide border border-blue-100">
                            Terpopuler
                          </span>
                        )}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleSave(job.id);
                          }}
                          className={`p-1.5 rounded-full border transition duration-150 cursor-pointer ${
                            isSaved
                              ? 'bg-rose-50 border-rose-200 text-rose-500 hover:bg-rose-100'
                              : 'bg-white border-slate-250 text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                          }`}
                          title={isSaved ? 'Hapus' : 'Simpan'}
                          id={`btn-save-job-${job.id}`}
                        >
                          <Heart className={`w-3.5 h-3.5 ${isSaved ? 'fill-rose-500 text-rose-500' : ''}`} />
                        </button>
                      </div>
                    </div>

                    {/* Meta stats structured into organic tags */}
                    <div className="flex flex-wrap gap-1.5 text-[11px] pt-1 font-inherit">
                      <span className="flex items-center gap-1 font-medium text-slate-600 bg-slate-100/90 px-2 py-0.5 rounded">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{job.location}</span>
                      </span>
                      <span className="flex items-center gap-1 font-medium text-slate-600 bg-slate-100/90 px-2 py-0.5 rounded">
                        <Briefcase className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{job.type}</span>
                      </span>
                      <span className="flex items-center gap-1 font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100/70">
                        <Banknote className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{job.salary}</span>
                      </span>
                    </div>
                  </div>

                  {/* Footer Line */}
                  <div className="flex items-center justify-between mt-4 pt-2.5 border-t border-[#f3f2f0] font-inherit">
                    <span className="flex items-center gap-1 text-[10px] font-medium text-slate-400">
                      <Clock className="w-3 h-3" />
                      <span>{job.postedAt}</span>
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-bold text-[#0a66c2] hover:text-[#004182] group-hover:translate-x-0.5 transition duration-150 font-inherit">
                      <span>Lamar Sekarang</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
