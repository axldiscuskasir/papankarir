import React, { useState, useEffect, useRef } from 'react';
import { Job, Message } from '../types';
import { Play, Send, Sparkles, MessageSquare, Briefcase, Award, AlertCircle, FileText, Redo } from 'lucide-react';
import { motion } from 'motion/react';

interface MockInterviewProps {
  jobs: Job[];
  onStartInterview: (jobId: string, candidateName: string) => Promise<any>;
  onSendMessage: (sessionId: string, text: string, forceComplete?: boolean) => Promise<any>;
}

export default function MockInterview({ jobs, onStartInterview, onSendMessage }: MockInterviewProps) {
  const [candidateName, setCandidateName] = useState('');
  const [selectedJobId, setSelectedJobId] = useState('');
  const [session, setSession] = useState<any | null>(null);
  const [inputText, setInputText] = useState('');
  const [starting, setStarting] = useState(false);
  const [sending, setSending] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.messages, sending]);

  // Load target job selected previously if any
  useEffect(() => {
    const cachedJobId = localStorage.getItem('auto_select_job_id');
    if (cachedJobId) {
      setSelectedJobId(cachedJobId);
      localStorage.removeItem('auto_select_job_id');
    } else if (jobs.length > 0 && !selectedJobId) {
      setSelectedJobId(jobs[0].id);
    }
  }, [jobs]);

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!candidateName || !selectedJobId) {
      setErrorMsg("Harap masukkan Nama Anda dan pilih Pekerjaan untuk disimulasikan.");
      return;
    }

    setStarting(true);
    try {
      const activeSession = await onStartInterview(selectedJobId, candidateName);
      setSession(activeSession);
    } catch (err) {
      console.error(err);
      setErrorMsg("Gagal memulai wawancara. Silakan coba memulai ulang.");
    } finally {
      setStarting(false);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!inputText.trim() || sending || !session) return;

    const userText = inputText;
    setInputText('');
    setSending(true);

    try {
      const updatedSession = await onSendMessage(session.id, userText, false);
      setSession(updatedSession);
    } catch (err) {
      console.error(err);
      setErrorMsg("Gagal mengirim tanggapan. Silakan coba kembali.");
    } finally {
      setSending(false);
    }
  };

  const handleForceComplete = async () => {
    if (!session || completing) return;
    setErrorMsg('');
    setCompleting(true);
    try {
      const finalSession = await onSendMessage(session.id, "", true);
      setSession(finalSession);
    } catch (err) {
      console.error(err);
      setErrorMsg("Gagal menghitung penilaian akhir.");
    } finally {
      setCompleting(false);
    }
  };

  const scoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600 border-emerald-300 bg-emerald-50';
    if (score >= 65) return 'text-amber-600 border-amber-300 bg-amber-50';
    return 'text-red-600 border-red-300 bg-red-50';
  };

  // Turn tracking (calculates user responses vs maximum recommendation)
  const getUserTurns = () => {
    if (!session) return 0;
    return session.messages.filter((m: Message) => m.sender === 'user').length;
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="space-y-1.5 font-inherit">
        <h2 className="text-lg md:text-xl font-semibold text-slate-800 flex items-center gap-2 tracking-tight">
          <MessageSquare className="w-5 h-5 text-indigo-500 animate-pulse" />
          <span>Latihan Wawancara AI (Simulasi)</span>
        </h2>
        <p className="text-slate-500 text-xs md:text-sm leading-relaxed max-w-2xl font-inherit">
          Uji kesiapan hardskill dan pembawaan komunikasi Anda secara interaktif. Jawab pertanyaan pewawancara, selesaikan 4 pertanyaan, dan dapatkan penilaian komprehensif.
        </p>
      </div>

      {errorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-medium">
          {errorMsg}
        </div>
      )}

      {/* Screen Selection: Initial form or Active Chat */}
      {!session ? (
        <div className="max-w-xl mx-auto bg-white border border-slate-200 shadow-sm rounded-3xl overflow-hidden mt-6">
          <div className="bg-indigo-600 p-6 text-white text-center space-y-2">
            <Sparkles className="w-8 h-8 text-amber-300 mx-auto animate-pulse" />
            <h3 className="text-base font-extrabold uppercase tracking-wider">Mulai Sesi Wawancara Baru</h3>
            <p className="text-xs text-indigo-100 leading-relaxed max-w-sm mx-auto leading-relaxed">
              Simulasi interaktif ini akan dipandu oleh AI HRD dalam Bahasa Indonesia formal sesuai konteks jabatan yang dipilih.
            </p>
          </div>

          <form onSubmit={handleStart} className="p-6 md:p-8 space-y-5 text-xs">
            <div>
              <label className="block text-slate-600 font-bold mb-1.5">Nama Anda *</label>
              <input
                type="text"
                required
                placeholder="Contoh: Rian Anggara"
                className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition"
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                id="interview-name-input"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-bold mb-1.5">Pilih Jabatan Pekerjaan *</label>
              <select
                required
                className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs text-slate-700 font-medium transition"
                value={selectedJobId}
                onChange={(e) => setSelectedJobId(e.target.value)}
                id="interview-job-select"
              >
                <option value="" disabled>Pilih Posisi Lowongan...</option>
                {jobs.map((job) => (
                  <option key={job.id} value={job.id}>
                    {job.title} ({job.company})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              disabled={starting}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-sm transition flex justify-center items-center gap-2 cursor-pointer text-xs uppercase tracking-wider"
              id="interview-start-btn"
            >
              {starting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  <span>Mempersiapkan Pewawancara AI...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Mulai Simulasi Wawancara</span>
                </>
              )}
            </button>
          </form>
        </div>
      ) : (
        /* Active Chat Workspace Grid */
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[550px]">
          {/* Main Chat Area */}
          <div className="lg:col-span-3 bg-white border border-slate-200 shadow-sm rounded-2xl flex flex-col justify-between overflow-hidden relative">
            {/* Top header stats */}
            <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse" />
                <div>
                  <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">Wawancara: {session.jobTitle}</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">Interviewer: {session.companyName} AI Assistant</p>
                </div>
              </div>

              {session.status === 'active' && (
                <div className="flex items-center gap-3">
                  <span className="hidden sm:inline-block px-2.5 py-1 bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold rounded-lg font-mono">
                    Pertanyaan: {getUserTurns()} / 4
                  </span>
                  <button
                    onClick={handleForceComplete}
                    disabled={completing}
                    className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-lg transition border border-rose-200 cursor-pointer uppercase tracking-wider"
                    id="interview-force-finish-btn"
                  >
                    {completing ? 'Menghitung...' : 'Minta Penilaian'}
                  </button>
                </div>
              )}
            </div>

            {/* Scrollable messages container */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-50/40">
              {session.messages.map((message: Message) => {
                const isAI = message.sender === 'ai';
                return (
                  <div
                    key={message.id}
                    className={`flex ${isAI ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed space-y-1 shadow-sm border ${
                      isAI
                        ? 'bg-white text-slate-800 rounded-tl-none border-slate-200 font-sans'
                        : 'bg-indigo-600 text-white rounded-tr-none border-indigo-700'
                    }`}>
                      <p className="whitespace-pre-line text-[11px] md:text-xs">
                        {message.text}
                      </p>
                      <div className={`text-[9px] text-right font-mono font-medium ${isAI ? 'text-slate-400' : 'text-indigo-200'}`}>
                        {message.timestamp}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Bot typing simulation */}
              {sending && (
                <div className="flex justify-start">
                  <div className="bg-white text-slate-600 rounded-2xl border border-slate-200 rounded-tl-none p-4 text-xs flex items-center gap-1.5 shadow-sm">
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" />
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Bottom input area */}
            <div className="p-4 bg-white border-t border-slate-200">
              {session.status === 'active' ? (
                <form onSubmit={handleSend} className="flex gap-2 text-xs">
                  <input
                    type="text"
                    disabled={sending}
                    placeholder="Tulis tanggapan Anda di sini... (Saran: ceritakan pengalaman terarah Anda)"
                    className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    id="interview-chat-input"
                  />
                  <button
                    type="submit"
                    disabled={!inputText.trim() || sending}
                    className="px-5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition flex items-center justify-center cursor-pointer shadow-sm"
                    id="interview-chat-send-btn"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <div className="text-center p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
                  <p className="text-emerald-800 font-extrabold text-xs uppercase tracking-wider">Simulasi Wawancara Selesai</p>
                  <p className="text-[10px] text-emerald-600 leading-relaxed mt-0.5">
                    Sesi Anda telah berhasil dinilai. Baca laporan penilaian kustom Anda di panel kanan untuk evaluasi lengkap.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right Evaluation Panel */}
          <div className="lg:col-span-1 bg-white border border-slate-200 shadow-sm rounded-2xl flex flex-col justify-between overflow-hidden">
            <h4 className="px-4 py-3 bg-slate-50 border-b border-slate-200 text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-4 h-4 text-indigo-500" />
              <span>Raport Penilaian</span>
            </h4>

            {session.status === 'active' ? (
              <div className="flex-1 p-6 text-center space-y-4 flex flex-col justify-center items-center text-slate-400 text-xs bg-slate-50/10">
                <AlertCircle className="w-10 h-10 text-slate-300 animate-pulse" />
                <div className="space-y-1">
                  <h5 className="font-bold text-slate-600 uppercase tracking-wide">Sedang Berlangsung</h5>
                  <p className="text-[10px] leading-relaxed text-slate-400">
                    Ulasan nilai dan saran detail akan tampil setelah Anda menjawab 4 pertanyaan atau menekan tombol **"Minta Penilaian"**.
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs bg-slate-50/10">
                {session.feedback ? (
                  <div className="space-y-4">
                    {/* Circle Score */}
                    <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <div className={`w-12 h-12 rounded-full border flex items-center justify-center font-black text-sm ${scoreColor(session.feedback.score)}`}>
                        {session.feedback.score}
                      </div>
                      <div>
                        <p className="text-[9px] text-slate-400 uppercase tracking-widest font-mono font-bold">Nilai Komunikasi</p>
                        <p className="font-extrabold text-slate-700">
                          {session.feedback.score >= 80 ? 'Sangat Berpotensi' : session.feedback.score >= 65 ? 'Cukup Layak' : 'Butuh Latihan'}
                        </p>
                      </div>
                    </div>

                    {/* Evaluation paragraph */}
                    <div className="space-y-1.5 bg-indigo-50/25 p-3.5 rounded-xl border border-indigo-100 leading-relaxed text-[11px] text-slate-600 text-left">
                      <p className="font-bold text-indigo-900 border-b border-indigo-100/50 pb-0.5 uppercase tracking-wider">Hasil Analisis</p>
                      <p className="whitespace-pre-line font-sans">{session.feedback.evaluation}</p>
                    </div>

                    {/* Quick Tips */}
                    <div className="space-y-2 pb-2">
                      <p className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-indigo-500" />
                        <span>Saran Perbaikan</span>
                      </p>
                      <ul className="space-y-2 text-[11px] text-slate-600 font-sans leading-relaxed">
                        {session.feedback.tips.map((tp: string, idx: number) => (
                          <li key={idx} className="flex gap-1.5">
                            <span className="font-bold text-indigo-500 font-mono">{idx + 1}.</span>
                            <span>{tp}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <p className="text-slate-400 text-center leading-relaxed py-6">
                    Memuat hasil penilaian kompetensi...
                  </p>
                )}
              </div>
            )}

            {/* Bottom Panel Actions */}
            <div className="p-3 bg-slate-50 border-t border-slate-200">
              <button
                onClick={() => setSession(null)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg transition flex items-center justify-center gap-1.5 text-xs cursor-pointer uppercase tracking-wider shadow-sm"
                id="interview-restart-session-btn"
              >
                <Redo className="w-3.5 h-3.5" />
                <span>Mulai Ulang Sesi</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
