import React, { useState } from 'react';
import { JobApplication } from '../types';
import { Eye, Clock, Building2, Briefcase, Sparkles, AlertCircle, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface MyApplicationsProps {
  applications: JobApplication[];
}

export default function MyApplications({ applications }: MyApplicationsProps) {
  // Expansion controls
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);

  const getStatusBadge = (status: string) => {
    const defaultClasses = "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ";
    switch (status) {
      case 'Terkirim':
        return <span className={defaultClasses + "bg-blue-50 text-blue-700 border border-blue-200"}>Terkirim</span>;
      case 'Review':
        return <span className={defaultClasses + "bg-amber-50 text-amber-700 border border-amber-200"}>Review Kelayakan</span>;
      case 'Wawancara':
        return <span className={defaultClasses + "bg-blue-50 text-[#0a66c2] border border-blue-200"}>Sesi Wawancara</span>;
      case 'Diterima':
        return <span className={defaultClasses + "bg-emerald-50 text-emerald-700 border border-emerald-200"}>Diterima</span>;
      case 'Ditolak':
        return <span className={defaultClasses + "bg-rose-50 text-rose-700 border border-rose-200"}>Ditolak</span>;
      default:
        return <span className={defaultClasses + "bg-slate-50 text-slate-700 border border-slate-200"}>{status}</span>;
    }
  };

  return (
    <div className="space-y-6 font-inherit">
      <div className="space-y-1.5 font-inherit">
        <h2 className="text-lg md:text-xl font-semibold text-slate-800 flex items-center gap-2 tracking-tight">
          <Clock className="w-5 h-5 text-[#0a66c2]" />
          <span>Status Lamaran Saya</span>
        </h2>
        <p className="text-slate-500 text-xs md:text-sm max-w-2xl leading-relaxed">
          Ulas daftar pekerjaan yang sudah Anda lamar. Baca ulasan kesesuaian bimbingan rincian AI secara berkala sesuai update rekruter harian.
        </p>
      </div>

      {applications.length === 0 ? (
        <div className="p-12 text-center text-slate-400 border border-dashed border-[#e0e0e0] rounded-lg bg-white space-y-3">
          <Briefcase className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-semibold text-slate-700 text-xs uppercase tracking-wider">Belum ada lamaran terkirim</h3>
          <p className="text-xs max-w-sm mx-auto text-slate-400 leading-relaxed">
            Telusuri pekerjaan impian Anda di tab <strong>"Cari Lowongan"</strong> dan mulailah mengirimkan kualifikasi terbaik Anda!
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {applications.map((app) => {
            const isExpanded = selectedAppId === app.id;
            const hasAIResult = app.aiAnalysis;

            return (
              <div
                key={app.id}
                className={`bg-white border rounded-lg shadow-none transition overflow-hidden ${
                  isExpanded ? 'border-[#0a66c2] ring-2 ring-blue-50' : 'border-[#e0e0e0]'
                }`}
                id={`my-app-card-${app.id}`}
              >
                {/* Collapsed view */}
                <div
                  onClick={() => setSelectedAppId(isExpanded ? null : app.id)}
                  className="p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 cursor-pointer hover:bg-slate-50 transition"
                  id={`my-app-header-${app.id}`}
                >
                  <div className="space-y-1">
                    <h3 className="font-bold text-slate-950 text-sm md:text-base leading-tight">
                      {app.jobTitle}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 font-medium">
                      <span className="text-slate-700 font-bold uppercase text-[10px] tracking-wider">{app.companyName}</span>
                      <span className="text-slate-300">•</span>
                      <span className="font-mono text-[10px] uppercase font-semibold tracking-wider text-slate-400">{app.appliedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {hasAIResult && (
                      <span className="px-2 py-0.5 bg-blue-50 text-[#0a66c2] font-semibold text-[9px] rounded tracking-wide uppercase border border-blue-100">
                        Skor AI: {hasAIResult.score}%
                      </span>
                    )}

                    <div className="flex items-center gap-2">
                      {getStatusBadge(app.status)}
                      <button className="p-1 px-2.5 bg-slate-100 hover:bg-blue-50 hover:text-[#0a66c2] rounded text-[10px] font-bold transition flex items-center gap-1 cursor-pointer uppercase tracking-wider">
                        <Eye className="w-3.5 h-3.5" />
                        <span>{isExpanded ? 'Tutup' : 'Ulasan'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded view showcasing AI CV feedback */}
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="px-5 pb-5 border-t border-[#f3f2f0] bg-slate-50/50 pt-5 space-y-4 text-xs text-slate-700"
                  >
                    {/* General Submitted info */}
                    <div className="bg-white p-4 rounded-lg border border-[#e0e0e0] space-y-2">
                      <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider border-l-2 border-[#0a66c2] pl-2 bg-slate-50/40">Identitas Pengiriman</h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px] text-slate-600">
                        <div>
                          <p className="text-slate-400 font-medium">Nama Pelamar</p>
                          <p className="font-bold text-slate-800">{app.candidateName}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-medium">Email Kontak</p>
                          <p className="font-bold text-slate-800">{app.candidateEmail}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-medium">No. Telepon</p>
                          <p className="font-bold text-slate-800">{app.candidatePhone || '-'}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-medium">Status Aplikasi</p>
                          <p className="font-extrabold text-[#0a66c2] uppercase tracking-wider text-[10px]">{app.status}</p>
                        </div>
                      </div>
                    </div>

                    {/* AI Feedback Report (if available) */}
                    {hasAIResult ? (
                      <div className="bg-blue-50/30 p-4 rounded-lg border border-blue-100 space-y-4">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-[#0a66c2] animate-pulse" />
                          <h4 className="font-bold text-[#0a66c2] text-xs uppercase tracking-wider">Hasil Pemindaian AI CV</h4>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="md:col-span-2 space-y-1">
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold">Ulasan Kompatibilitas</p>
                            <p className="text-slate-600 leading-relaxed text-xs antialiased">
                              {hasAIResult.summary}
                            </p>
                          </div>

                          <div className="p-3 bg-white border border-[#e0e0e0] rounded-lg text-center flex flex-col justify-center shadow-none">
                            <span className="text-[9px] text-slate-400 uppercase tracking-widest font-mono font-bold">Skor Berkas</span>
                            <span className="text-2xl font-black text-[#0a66c2]">{hasAIResult.score}%</span>
                            <span className="text-[10px] font-bold text-[#0a66c2] uppercase tracking-[0.1em]">{hasAIResult.fitLevel}</span>
                          </div>
                        </div>

                        {/* Split details */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                          <div className="bg-white p-3 rounded-lg border border-[#e0e0e0] space-y-1.5 shadow-none">
                            <p className="font-bold text-emerald-800 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                              <span>Sisi Unggul Resume:</span>
                            </p>
                            <ul className="space-y-1 text-slate-600 pl-4 list-disc antialiased">
                              {hasAIResult.strengths.map((str, i) => (
                                <li key={i}>{str}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="bg-white p-3 rounded-lg border border-[#e0e0e0] space-y-1.5 shadow-none">
                            <p className="font-bold text-amber-800 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                              <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
                              <span>Kekurangan / Gap Syarat:</span>
                            </p>
                            <ul className="space-y-1 text-slate-600 pl-4 list-disc antialiased">
                              {hasAIResult.gaps.map((gp, i) => (
                                <li key={i}>{gp}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Tips */}
                        <div className="p-3.5 bg-blue-50/55 border border-blue-100 rounded-lg text-xs leading-relaxed text-slate-700">
                          <p className="font-bold text-[#0a66c2] mb-1 flex items-center gap-1 uppercase tracking-wider text-[10px]">
                            <Sparkles className="w-3.5 h-3.5 text-[#0a66c2]" />
                            <span>Saran Optimasi Persiapan:</span>
                          </p>
                          <ul className="space-y-1 list-none font-medium text-slate-600">
                            {hasAIResult.tips.map((tp, i) => (
                              <li key={i} className="flex gap-2">
                                <span className="font-bold text-[#0a66c2] font-mono">{i + 1}.</span>
                                <span className="antialiased">{tp}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ) : (
                      <p className="text-slate-400 text-center leading-relaxed">
                        Data pemindaian AI sedang dimuat...
                      </p>
                    )}
                  </motion.div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
