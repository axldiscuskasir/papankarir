import React, { useState } from 'react';
import { Job, JobApplication } from '../types';
import { Plus, Trash2, Users, FileText, Sparkles, Send, CheckCircle2, XCircle, Clock, ChevronRight, CornerDownRight, Landmark } from 'lucide-react';
import { motion } from 'motion/react';

interface RecruiterDashboardProps {
  jobs: Job[];
  applications: JobApplication[];
  onPostJob: (jobData: any) => Promise<void>;
  onDeleteJob: (jobId: string) => Promise<void>;
  onUpdateAppStatus: (appId: string, status: string) => Promise<void>;
  onGenerateAIJD: (title: string, company: string, category: string, keywords: string) => Promise<{
    title: string;
    description: string;
    requirements: string[];
    benefits: string[];
  }>;
}

export default function RecruiterDashboard({
  jobs,
  applications,
  onPostJob,
  onDeleteJob,
  onUpdateAppStatus,
  onGenerateAIJD
}: RecruiterDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<'listings' | 'applicants'>('listings');
  const [showAddForm, setShowAddForm] = useState(false);
  const [loadingAI, setLoadingAI] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Post job form states
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [category, setCategory] = useState('Software Engineering');
  const [location, setLocation] = useState('Jakarta Hybrid');
  const [type, setType] = useState<'Full-Time' | 'Part-Time' | 'Kontrak' | 'Internship' | 'Remote'>('Full-Time');
  const [salary, setSalary] = useState('Rp 8.000.000 - Rp 12.000.000');
  const [description, setDescription] = useState('');
  const [reqInput, setReqInput] = useState(''); // text area separated by newlines
  const [benInput, setBenInput] = useState(''); // text area separated by newlines
  const [aiKeywords, setAiKeywords] = useState(''); // additional prompt for AI JD writing

  // Active expansion of applicant detail
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);

  // Trigger Gemini to Autofilled Job Description
  const handleAIFill = async () => {
    setStatusMsg(null);
    if (!title || !company) {
      setStatusMsg({ text: "Harap isi Posisi Pekerjaan dan Nama Perusahaan terlebih dahulu agar AI memahami konteksnya.", type: 'error' });
      return;
    }

    setLoadingAI(true);
    try {
      const generated = await onGenerateAIJD(title, company, category, aiKeywords);
      setDescription(generated.description);
      setReqInput(generated.requirements.join('\n'));
      setBenInput(generated.benefits.join('\n'));
      setStatusMsg({ text: "Bimbingan deskripsi & syarat telah diisi otomatis oleh AI!", type: 'success' });
    } catch (err) {
      console.error(err);
      setStatusMsg({ text: "Gagal memanggil AI. Pastikan model AI server-side dikonfigurasi dengan benar.", type: 'error' });
    } finally {
      setLoadingAI(false);
    }
  };

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);
    if (!title || !company || !location || !salary) {
      setStatusMsg({ text: "Harap lengkapi semua kolom bertanda bintang (*).", type: 'error' });
      return;
    }

    const requirements = reqInput.split('\n').map(r => r.trim()).filter(r => r.length > 0);
    const benefits = benInput.split('\n').map(b => b.trim()).filter(b => b.length > 0);

    try {
      await onPostJob({
        title,
        company,
        category,
        location,
        type,
        salary,
        description,
        requirements,
        benefits,
        isFeatured: true
      });
      
      // Cleanup states
      setTitle('');
      setCompany('');
      setAiKeywords('');
      setDescription('');
      setReqInput('');
      setBenInput('');
      setShowAddForm(false);
      setStatusMsg({ text: "Lowongan kerja baru berhasil diposting!", type: 'success' });
    } catch (err) {
      console.error(err);
      setStatusMsg({ text: "Gagal menambahkan lowongan baru.", type: 'error' });
    }
  };

  const handleDeleteJobClick = async (jobId: string, jobTitle: string) => {
    setStatusMsg(null);
    try {
      await onDeleteJob(jobId);
      setStatusMsg({ text: `Lowongan "${jobTitle}" berhasil dihapus.`, type: 'success' });
    } catch (err) {
      console.error(err);
      setStatusMsg({ text: "Gagal menghapus lowongan kerja.", type: 'error' });
    }
  };

  // Status Badge utility
  const getStatusBadge = (status: string) => {
    const defaultClasses = "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ";
    switch (status) {
      case 'Terkirim':
        return <span className={defaultClasses + "bg-blue-50 text-blue-700 border border-blue-200"}>Terkirim</span>;
      case 'Review':
        return <span className={defaultClasses + "bg-amber-50 text-amber-700 border border-amber-200"}>Sedang Review</span>;
      case 'Wawancara':
        return <span className={defaultClasses + "bg-indigo-50 text-indigo-700 border border-indigo-200"}>Wawancara</span>;
      case 'Diterima':
        return <span className={defaultClasses + "bg-emerald-50 text-emerald-700 border border-emerald-200"}>Diterima</span>;
      case 'Ditolak':
        return <span className={defaultClasses + "bg-rose-50 text-rose-700 border border-rose-200"}>Ditolak</span>;
      default:
        return <span className={defaultClasses + "bg-slate-50 text-slate-700 border border-slate-200"}>{status}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2 uppercase tracking-wider">
            <Landmark className="w-5 h-5 text-indigo-500" />
            <span>Dashboard Perusahaan & Rekruter</span>
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed max-w-2xl">
            Kelola penayangan lowongan kerja instan Anda, gunakan asisten AI untuk memobilisasi tulisan persyaratan, serta pantau lamaran masuk lengkap dengan kecocokan CV Kandidat.
          </p>
        </div>

        <button
          onClick={() => {
            setShowAddForm(!showAddForm);
            setStatusMsg(null);
          }}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer uppercase tracking-wider"
          id="btn-toggle-add-job-form"
        >
          <Plus className="w-4 h-4" />
          <span>{showAddForm ? 'Lihat Semua Lowongan' : 'Pasang Lowongan Baru'}</span>
        </button>
      </div>

      {statusMsg && (
        <div className={`p-3.5 rounded-xl text-xs font-semibold border ${
          statusMsg.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'
        }`}>
          {statusMsg.text}
        </div>
      )}

      {/* Screen view router */}
      {!showAddForm ? (
        <>
          {/* Sub Navigation tabs */}
          <div className="flex border-b border-slate-200 gap-6">
            <button
              onClick={() => {
                setActiveSubTab('listings');
                setStatusMsg(null);
              }}
              className={`pb-3 text-xs uppercase tracking-wider font-extrabold transition cursor-pointer relative ${
                activeSubTab === 'listings' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
              }`}
              id="btn-subtab-listings"
            >
              <span>Lowongan Terbit ({jobs.length})</span>
              {activeSubTab === 'listings' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600 rounded-full" />
              )}
            </button>
            <button
              onClick={() => {
                setActiveSubTab('applicants');
                setStatusMsg(null);
              }}
              className={`pb-3 text-xs uppercase tracking-wider font-extrabold transition cursor-pointer relative ${
                activeSubTab === 'applicants' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
              }`}
              id="btn-subtab-applicants"
            >
              <span>Ulasan Pelamar ({applications.length})</span>
              {activeSubTab === 'applicants' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600 rounded-full" />
              )}
            </button>
          </div>

          {/* Tab 1: Active Listings */}
          {activeSubTab === 'listings' && (
            <div className="space-y-4">
              {jobs.length === 0 ? (
                <div className="p-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-2xl bg-slate-50">
                  <FileText className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="font-extrabold uppercase text-xs tracking-wider">Belum ada lowongan terbit</p>
                  <p className="text-xs max-w-sm mx-auto leading-relaxed mt-1">Klik tombol Pasang Lowongan Baru untuk menerbitkan iklan karir pertama Anda harian.</p>
                </div>
              ) : (
                <div className="overflow-x-auto bg-white rounded-2xl border border-slate-200 shadow-sm">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-extrabold uppercase tracking-wider text-[10px]">
                        <th className="p-4">Perusahaan & Jabatan</th>
                        <th className="p-4">Kategori / Lokasi</th>
                        <th className="p-4">Kontrak & Gaji</th>
                        <th className="p-4 text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {jobs.map((job) => (
                        <tr key={job.id} className="hover:bg-slate-50/50 transition">
                          <td className="p-4">
                            <p className="font-extrabold text-slate-900 text-sm leading-tight">{job.title}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{job.company}</p>
                          </td>
                          <td className="p-4">
                            <p className="font-semibold text-slate-700">{job.category}</p>
                            <p className="text-[10px] text-slate-400 font-medium">{job.location}</p>
                          </td>
                          <td className="p-4">
                            <p className="font-extrabold text-indigo-700 uppercase tracking-wider text-[10px]">{job.type}</p>
                            <p className="text-emerald-700 font-bold font-mono">{job.salary}</p>
                          </td>
                          <td className="p-4 text-center">
                            <button
                              onClick={() => handleDeleteJobClick(job.id, job.title)}
                              className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title="Hapus Lowongan"
                              id={`delete-job-${job.id}`}
                            >
                              <Trash2 className="w-4 h-4 mx-auto" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Applicants Screener list */}
          {activeSubTab === 'applicants' && (
            <div className="space-y-4">
              {applications.length === 0 ? (
                <div className="p-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-2xl bg-slate-50">
                  <Users className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="font-extrabold uppercase text-xs tracking-wider">Belum ada pelamar masuk</p>
                  <p className="text-xs max-w-sm mx-auto leading-relaxed mt-1">Iklankan lowongan kerja Anda agar pelamar dapat mensubmit kualifikasi akademis mereka.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {applications.map((app) => {
                    const isExpanded = selectedAppId === app.id;
                    const hasAIResult = app.aiAnalysis;

                    return (
                      <div
                        key={app.id}
                        className={`bg-white border rounded-2xl shadow-sm transition overflow-hidden ${
                          isExpanded ? 'border-indigo-400 ring-2 ring-indigo-50/50' : 'border-slate-200 hover:border-slate-300'
                        }`}
                        id={`app-card-${app.id}`}
                      >
                        {/* Brief Summary line */}
                        <div
                          onClick={() => setSelectedAppId(isExpanded ? null : app.id)}
                          className="p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 cursor-pointer"
                        >
                          <div className="space-y-1 md:flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-extrabold text-slate-900 text-sm md:text-base">
                                {app.candidateName}
                              </h4>
                              <span className="text-[10px] text-slate-400 font-mono">
                                ({app.appliedAt})
                              </span>
                            </div>
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                              <span>Melamar sebagai:</span>
                              <span className="font-bold text-slate-700">{app.jobTitle}</span>
                              <span className="text-slate-300">|</span>
                              <span>{app.candidateEmail}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            {hasAIResult && (
                              <div className="text-right">
                                <span className="text-[9px] text-slate-400 block font-mono font-bold uppercase tracking-wider">Kecocokan AI</span>
                                <span className="px-2 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-md font-bold text-[10px] tracking-wider uppercase">
                                  {hasAIResult.score}% ({hasAIResult.fitLevel})
                                </span>
                              </div>
                            )}
                            
                            <div className="flex items-center gap-2">
                              {getStatusBadge(app.status)}
                              <ChevronRight className={`w-4 h-4 text-slate-400 transition transform ${isExpanded ? 'rotate-90' : ''}`} />
                            </div>
                          </div>
                        </div>

                        {/* Expanded details */}
                        {isExpanded && (
                          <div className="px-5 pb-6 border-t border-slate-200 bg-slate-50/30 pt-5 space-y-5 text-xs text-slate-700">
                            {/* Technical information */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
                                <h5 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider border-l-2 border-indigo-600 pl-2">Kontak & Sosial</h5>
                                <p><strong>Email:</strong> {app.candidateEmail}</p>
                                <p><strong>No. Telp:</strong> {app.candidatePhone || '-'}</p>
                                {app.linkedinUrl && (
                                  <p>
                                    <strong>LinkedIN:</strong>{' '}
                                    <a
                                      href={app.linkedinUrl}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="text-indigo-600 hover:underline"
                                    >
                                      {app.linkedinUrl}
                                    </a>
                                  </p>
                                )}
                              </div>

                              <div className="space-y-1.5 p-4 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
                                <div>
                                  <h5 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">Keputusan Status Lamaran</h5>
                                  <p className="text-[10px] text-slate-400 mb-2 leading-relaxed">Ubah status pelamar di bawah ini untuk disinkronisasikan ke kandidat:</p>
                                </div>
                                <div className="flex flex-wrap gap-1.5">
                                  {['Review', 'Wawancara', 'Diterima', 'Ditolak'].map((st) => (
                                    <button
                                      key={st}
                                      onClick={() => onUpdateAppStatus(app.id, st)}
                                      className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer uppercase tracking-wider ${
                                        app.status === st
                                          ? 'bg-indigo-600 text-white shadow-sm'
                                          : 'bg-white hover:bg-slate-50 text-slate-600 border border-slate-200'
                                      }`}
                                      id={`btn-update-status-${app.id}-${st}`}
                                    >
                                      {st}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Letter / CV Text split */}
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm space-y-1.5">
                                <h5 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">Isi CV Pelamar</h5>
                                <p className="text-[11px] text-slate-600 whitespace-pre-wrap leading-relaxed bg-slate-50 p-3 rounded-lg max-h-48 overflow-y-auto">
                                  {app.cvText}
                                </p>
                              </div>
                              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm space-y-1.5">
                                <h5 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">Surat Pengantar (Cover Letter)</h5>
                                <p className="text-[11px] text-slate-600 whitespace-pre-wrap leading-relaxed bg-slate-50 p-3 rounded-lg max-h-48 overflow-y-auto">
                                  {app.coverLetter || 'Tidak menyertakan Cover Letter spesifik.'}
                                </p>
                              </div>
                            </div>

                            {/* AI MATCH CARD (The master detail) */}
                            {hasAIResult && (
                              <div className="bg-gradient-to-br from-indigo-50 via-indigo-50/30 to-blue-50/20 p-5 rounded-xl border border-indigo-100 space-y-4">
                                <div className="flex items-center gap-2">
                                  <Sparkles className="w-4 h-4 text-indigo-700 animate-pulse" />
                                  <h5 className="font-extrabold text-indigo-900 text-xs uppercase tracking-wider">Analisis Penapisan AI HRD</h5>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                  <div className="md:col-span-2 space-y-1">
                                    <p className="text-[9px] uppercase text-slate-400 font-mono font-bold tracking-wider">Simpulan Kecocokan</p>
                                    <p className="text-slate-600 leading-relaxed text-xs">
                                      {hasAIResult.summary}
                                    </p>
                                  </div>

                                  <div className="p-3 bg-white rounded-xl border border-slate-200 text-center flex flex-col justify-center shadow-sm">
                                    <span className="text-[9px] text-slate-400 uppercase tracking-widest font-mono font-bold">Kecocokan</span>
                                    <span className="text-2xl font-black text-indigo-700">{hasAIResult.score}%</span>
                                    <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-[0.1em]">{hasAIResult.fitLevel}</span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs">
                                  <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                                    <p className="font-extrabold text-emerald-800 mb-2 uppercase tracking-wider text-[10px]">Kekuatan Utama:</p>
                                    <ul className="space-y-1 list-disc pl-4 text-slate-600">
                                      {hasAIResult.strengths.map((st, i) => (
                                        <li key={i}>{st}</li>
                                      ))}
                                    </ul>
                                  </div>
                                  <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                                    <p className="font-extrabold text-amber-800 mb-2 uppercase tracking-wider text-[10px]">Gap Syarat / Kelemahan:</p>
                                    <ul className="space-y-1 list-disc pl-4 text-slate-600">
                                      {hasAIResult.gaps.map((gp, i) => (
                                        <li key={i}>{gp}</li>
                                      ))}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </>
      ) : (
        /* Recruiter: Post Job form including Gemini JD Writer */
        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-sm">
          <form onSubmit={handlePostSubmit} className="space-y-6 text-xs">
            {/* AI Generator Tool Banner */}
            <div className="bg-gradient-to-r from-indigo-50 to-indigo-100 border border-indigo-200 p-5 rounded-2xl flex flex-col md:flex-row justify-between gap-4 items-start md:items-center">
              <div className="space-y-1 md:flex-1">
                <h4 className="font-extrabold text-indigo-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
                  <span>Asisten Penulisan Lowongan AI</span>
                </h4>
                <p className="text-slate-600 text-[11px] leading-relaxed max-w-xl">
                  Ketik posisi pekerjaan dan nama perusahaan di form bawah, lalu isi instruksi singkat (opsional), klik tombol di kanan untuk membiarkan AI menulis deskripsi serta list persyaratan secara lengkap!
                </p>
              </div>

              <div>
                <button
                  type="button"
                  onClick={handleAIFill}
                  disabled={loadingAI}
                  className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-bold rounded-xl shadow-sm transition flex items-center gap-1.5 text-xs border border-amber-300 cursor-pointer uppercase tracking-wider"
                  id="btn-ai-autofill-jd"
                >
                  {loadingAI ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-indigo-950/40 border-t-indigo-950 rounded-full animate-spin" />
                      <span>Menulis Skenario...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Tulis Deskripsi Kerja</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Main Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-slate-600 font-bold mb-1">Posisi Lowongan Kerja *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Senior UI Designer, Digital Marketing Manager"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  id="post-job-title"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Nama Perusahaan / Organisasi *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PT Teknologi Bangsa, GoTo Group"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  id="post-job-company"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Kategori Bidang Pekerjaan *</label>
                <select
                  required
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs font-medium text-slate-700 transition"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  id="post-job-category"
                >
                  <option value="Software Engineering">Software Engineering</option>
                  <option value="Desain & Kreatif">Desain & Kreatif</option>
                  <option value="Pemasaran & Konten">Pemasaran & Konten</option>
                  <option value="Data & AI">Data & AI</option>
                  <option value="Layanan Pelanggan">Layanan Pelanggan</option>
                  <option value="Administrasi & Finance">Administrasi & Finance</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Lokasi Kerja *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Jakarta Barat (Hybrid), Bandung (Remote)"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  id="post-job-location"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Tipe Kontrak *</label>
                <select
                  required
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs font-medium text-slate-700 transition"
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  id="post-job-type"
                >
                  <option value="Full-Time">Full-Time</option>
                  <option value="Part-Time">Part-Time</option>
                  <option value="Kontrak">Kontrak</option>
                  <option value="Internship">Internship</option>
                  <option value="Remote">Remote</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Kisaran Gaji Bulanan *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Rp 8.000.000 - Rp 11.000.000"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition animate-none"
                  value={salary}
                  onChange={(e) => setSalary(e.target.value)}
                  id="post-job-salary"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-600 font-bold mb-1">Catatan/Keywords Tambahan untuk AI (Opsional)</label>
              <input
                type="text"
                placeholder="Contoh: Harus bisa Next.js, tawarkan laptop gratis, ada bonus umroh"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs transition"
                value={aiKeywords}
                onChange={(e) => setAiKeywords(e.target.value)}
                id="post-job-ai-keywords"
              />
            </div>

            <div className="border-t border-slate-200 pt-4">
              <label className="block text-slate-600 font-bold mb-1">Deskripsi Utama Pekerjaan</label>
              <textarea
                rows={5}
                placeholder="Tulis draf detail pekerjaan di sini atau biarkan asisten AI di atas menulis secara otomatis..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs text-slate-600 font-sans transition"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                id="post-job-description"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-600 font-bold mb-1 font-sans">
                  <span>Daftar Persyaratan (Satu baris per syarat)</span>
                </label>
                <textarea
                  rows={6}
                  placeholder={`Mempunyai minimal 2 tahun pengalaman kerja\nMahir dalam Git & Github\nMampu berkomunikasi lancar`}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs text-slate-600 font-sans transition"
                  value={reqInput}
                  onChange={(e) => setReqInput(e.target.value)}
                  id="post-job-reqlist"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1 font-sans">
                  <span>Daftar Keuntungan / Perks (Satu baris per benefit)</span>
                </label>
                <textarea
                  rows={6}
                  placeholder={`Asuransi kesehatan lengkap\nLaptop MacBook Pro kerja disediakan\nUang lembur & makan siang harian`}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-xs text-slate-600 font-sans transition"
                  value={benInput}
                  onChange={(e) => setBenInput(e.target.value)}
                  id="post-job-benlist"
                />
              </div>
            </div>

            {/* Buttons Submit */}
            <div className="border-t border-slate-200 pt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowAddForm(false);
                  setStatusMsg(null);
                }}
                className="px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl text-xs transition cursor-pointer uppercase tracking-wider"
                id="btn-add-form-cancel"
              >
                Batal & Kembali
              </button>
              
              <button
                type="submit"
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-sm transition flex items-center gap-1.5 cursor-pointer uppercase tracking-wider"
                id="btn-add-form-submit"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Terbitkan Lowongan Kerja</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
