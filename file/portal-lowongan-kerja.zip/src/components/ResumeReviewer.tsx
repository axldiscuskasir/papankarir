import React, { useState, useEffect } from 'react';
import { Sparkles, CheckCircle, Lightbulb, AlertTriangle, FileText, Download, Copy, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { jsPDF } from 'jspdf';

interface ResumeReviewerProps {
  onAnalyzeCV: (cvText: string, targetJob: string) => Promise<{
    score: number;
    fitLevel: string;
    summary: string;
    strengths: string[];
    gaps: string[];
    tips: string[];
    optimizedCv?: string;
  }>;
}

export default function ResumeReviewer({ onAnalyzeCV }: ResumeReviewerProps) {
  const [cvText, setCvText] = useState('');
  const [targetJob, setTargetJob] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  
  // State for editable AI-Optimized CV
  const [editableCv, setEditableCv] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (result && result.optimizedCv) {
      setEditableCv(result.optimizedCv);
    } else {
      setEditableCv('');
    }
  }, [result]);

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!cvText) {
      setErrorMsg("Harap tempel teks ringkasan CV Anda.");
      return;
    }

    setLoading(true);
    try {
      const response = await onAnalyzeCV(cvText, targetJob);
      setResult(response);
    } catch (err) {
      console.error(err);
      setErrorMsg("Gagal menganalisis CV. Silakan coba lagi nanti.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = () => {
    if (!editableCv) return;
    navigator.clipboard.writeText(editableCv);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  const handleDownloadPDF = () => {
    if (!editableCv) return;

    // Create a new A4 PDF page
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 20;
    const maxLineWidth = pageWidth - (margin * 2);
    
    let y = margin;

    // Helper function to output dynamic lines and manage vertical flow with automated pagination
    const writeParagraph = (text: string, fontSize = 10, isBold = false, spaceAfter = 4) => {
      doc.setFontSize(fontSize);
      doc.setFont('Helvetica', isBold ? 'bold' : 'normal');
      
      const lines = doc.splitTextToSize(text, maxLineWidth);
      
      for (let i = 0; i < lines.length; i++) {
        // Leave ample safety margins before adding new page
        if (y + 6 > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(lines[i], margin, y);
        y += 6; // Standard spacing
      }
      y += spaceAfter;
    };

    // Split candidate draft and write iteratively
    const lines = editableCv.split('\n');
    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed) {
        y += 3; // Minimal spacing for blank line
        return;
      }

      // Format detection for key section headings (e.g. uppercase, dividers)
      const isHeader = 
        (trimmed === trimmed.toUpperCase() && trimmed.length > 3 && !trimmed.includes(':') && !trimmed.includes('@')) ||
        trimmed.startsWith('===') ||
        trimmed.endsWith('===') ||
        trimmed.startsWith('RINGKASAN') ||
        trimmed.startsWith('KEAHLIAN') ||
        trimmed.startsWith('PENGALAMAN') ||
        trimmed.startsWith('PENDIDIKAN') ||
        trimmed.startsWith('CURRICULUM');

      if (isHeader) {
        const cleanHeading = trimmed.replace(/[=]/g, '').trim();
        // Spacing before headings
        y += 2;
        writeParagraph(cleanHeading, 12, true, 2);
        
        // Add minimalist header ruler underneath section judul
        doc.setDrawColor(200, 205, 215);
        doc.setLineWidth(0.2);
        doc.line(margin, y - 1, pageWidth - margin, y - 1);
        y += 2;
      } else if (trimmed.startsWith('-') || trimmed.startsWith('•') || trimmed.startsWith('*')) {
        // Bullet points get nice clean formatting
        writeParagraph(trimmed, 9.5, false, 1.5);
      } else {
        // General text paragraphs
        writeParagraph(trimmed, 9.5, false, 2);
      }
    });

    const docName = targetJob 
      ? `CV_Teroptimasi_${targetJob.replace(/\s+/g, '_')}.pdf`
      : `CV_Teroptimasi_AI_PapanKarir.pdf`;

    doc.save(docName);
  };

  const scoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600 border-emerald-300 bg-emerald-50';
    if (score >= 60) return 'text-amber-600 border-amber-300 bg-amber-50';
    return 'text-red-600 border-red-300 bg-red-50';
  };

  return (
    <div className="space-y-6">
      {/* Title with inherited minimalist headings */}
      <div className="space-y-1 font-inherit">
        <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2 uppercase tracking-wide">
          <Sparkles className="w-5 h-5 text-[#0a66c2] animate-pulse" />
          <span>Optimalisasi CV berbasis AI</span>
        </h2>
        <p className="text-xs text-slate-500 leading-relaxed max-w-2xl font-inherit">
          Ulas kelayakan draf resume / CV Anda secara instan. Ketahui area mana yang perlu ditambahkan agar lolos seleksi berkas HRD Indonesia.
        </p>
      </div>

      {errorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs font-medium font-inherit">
          {errorMsg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Form panel */}
        <form onSubmit={handleReviewSubmit} className="lg:col-span-2 bg-white p-5 rounded-lg border border-slate-200 shadow-none space-y-4 text-xs h-fit font-inherit">
          <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-2 font-inherit">
            <FileText className="w-4 h-4 text-[#0a66c2]" />
            <span>Masukkan Ringkasan CV</span>
          </h3>

          <div>
            <label className="block text-slate-600 font-medium mb-1">Target Jabatan Pekerjaan (Opsional)</label>
            <input
              type="text"
              placeholder="Contoh: Digital Marketing Senior, Backend Node.js"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs transition font-inherit"
              value={targetJob}
              onChange={(e) => setTargetJob(e.target.value)}
              id="reviewer-target-job"
            />
          </div>

          <div>
            <label className="block text-slate-600 font-medium mb-1">Teks CV / Keahlian Anda *</label>
            <textarea
              required
              rows={12}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-700 font-sans leading-relaxed transition"
              placeholder="Tempel kelengkapan dari CV Anda di sini (Keahlian, Pengalaman kerja di perusahaan sebelumnya, proyek yang pernah dikerjakan, deskripsi riwayat akademis, dsb)..."
              value={cvText}
              onChange={(e) => setCvText(e.target.value)}
              id="reviewer-cv-text"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-[#0a66c2] hover:bg-[#004182] text-white font-medium rounded-lg shadow-none transition flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider text-xs font-inherit"
            id="reviewer-submit-btn"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                <span>AI sedang menilai kurikulum vitae...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300" />
                <span>Evaluasi Kelayakan CV</span>
              </>
            )}
          </button>
        </form>

        {/* Results Panel */}
        <div className="lg:col-span-3">
          {!result && !loading ? (
            <div className="bg-slate-50 border border-dashed border-slate-200 rounded-lg p-12 text-center text-slate-400 space-y-4 h-full flex flex-col justify-center items-center font-inherit">
              <Sparkles className="w-16 h-16 text-slate-300" />
              <div className="space-y-1">
                <h3 className="font-semibold text-slate-700 text-xs uppercase tracking-wider font-inherit">Menunggu Input Anda</h3>
                <p className="text-xs max-w-sm mx-auto leading-relaxed">
                  Tempel CV Anda di form sebelah kiri untuk memulai peninjauan. AI akan mengurai strengths, gaps, dan tips perbaikan kustom.
                </p>
              </div>
            </div>
          ) : loading ? (
            <div className="bg-white p-8 rounded-lg border border-slate-200 shadow-none text-center space-y-4 h-full flex flex-col justify-center items-center font-inherit">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-slate-100 border-t-[#0a66c2] rounded-full animate-spin" />
                <Sparkles className="w-6 h-6 text-[#0a66c2] absolute top-5 left-5 animate-pulse" />
              </div>
              <div className="space-y-1 font-inherit">
                <h3 className="font-semibold text-slate-700 text-xs uppercase tracking-wider">Mengevaluasi Susunan CV Anda</h3>
                <p className="text-xs text-slate-400 max-w-xs leading-relaxed animate-pulse">
                  Gemini AI sedang membaca tata bahasa, mencocokkan kata kunci industri, serta membandingkan kualifikasi Anda...
                </p>
              </div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-lg border border-[#e0e0e0] shadow-none space-y-6 font-inherit"
            >
              {/* Header result score */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-slate-50 border border-slate-200 rounded-lg gap-4 font-inherit">
                <div className="space-y-1">
                  <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Review Selesai!</h3>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium font-inherit">
                    <span>Target Posisi:</span>
                    <span className="font-bold text-slate-800">{targetJob || 'Umum'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className={`w-14 h-14 rounded-full border flex items-center justify-center font-bold text-lg ${scoreColor(result.score)}`}>
                    {result.score}
                  </div>
                  <div className="font-inherit">
                    <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-medium">Tingkat Kecocokan</p>
                    <p className="text-sm font-semibold text-slate-700">{result.fitLevel}</p>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="space-y-2 font-inherit border-b border-slate-150 pb-4">
                <h4 className="font-semibold text-slate-800 text-xs uppercase tracking-wider font-inherit">Kesimpulan AI</h4>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed bg-blue-50/20 p-4 rounded-lg border border-blue-100 font-sans">
                  {result.summary}
                </p>
              </div>

              {/* Strengths & Gaps split */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-inherit">
                {/* Strengths */}
                <div className="bg-emerald-50/35 p-4 rounded-lg border border-emerald-100/70 space-y-2">
                  <h5 className="font-semibold text-emerald-800 text-xs flex items-center gap-1.5 uppercase tracking-wider font-inherit">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Kelebihan CV & Profil</span>
                  </h5>
                  <ul className="space-y-2 text-xs text-slate-600 leading-relaxed font-inherit">
                    {result.strengths.map((st: string, idx: number) => (
                      <li key={idx} className="flex gap-2 align-top">
                        <span className="text-emerald-500 select-none">•</span>
                        <span>{st}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Gaps */}
                <div className="bg-amber-50/35 p-4 rounded-lg border border-amber-100/70 space-y-2 font-inherit">
                  <h5 className="font-semibold text-amber-800 text-xs flex items-center gap-1.5 uppercase tracking-wider font-inherit">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Area yang Kurang / Gap</span>
                  </h5>
                  <ul className="space-y-2 text-xs text-slate-600 leading-relaxed font-inherit">
                    {result.gaps.map((gp: string, idx: number) => (
                      <li key={idx} className="flex gap-2 align-top font-inherit">
                        <span className="text-amber-500 select-none font-inherit">•</span>
                        <span>{gp}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Tips */}
              <div className="p-4 bg-blue-50/20 border border-blue-100 rounded-lg space-y-2 font-inherit pb-4">
                <h5 className="font-semibold text-slate-900 text-xs flex items-center gap-1.5 uppercase tracking-wider font-inherit">
                  <Lightbulb className="w-4 h-4 text-[#0a66c2]" />
                  <span>Saran Optimasi Konstruktif</span>
                </h5>
                <ul className="space-y-2 text-xs text-slate-600 leading-relaxed font-inherit">
                  {result.tips.map((tp: string, idx: number) => (
                    <li key={idx} className="flex gap-2 align-top font-inherit">
                      <span className="font-medium text-[#0a66c2] font-mono">{idx + 1}.</span>
                      <span>{tp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* PDF EXPORT & DRAFT CV GENERATOR PANEL */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 space-y-4 font-inherit">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
                  <div className="space-y-0.5">
                    <h4 className="font-semibold text-slate-800 text-xs uppercase tracking-wide font-inherit flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-[#0a66c2]" />
                      <span>Draf CV Teroptimasi AI</span>
                    </h4>
                    <p className="text-[10px] text-slate-400 font-inherit uppercase tracking-widest font-mono font-medium">Bebas Unduh Berkualitas ATS</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyText}
                      disabled={!editableCv}
                      type="button"
                      className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 font-medium text-[10px] uppercase tracking-wider rounded transition duration-200 cursor-pointer flex items-center gap-1"
                      title="Salin Teks ke Clipboard"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600 animate-scale" />
                          <span className="text-emerald-700">Tersalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-500" />
                          <span>Salin Teks</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={handleDownloadPDF}
                      disabled={!editableCv}
                      type="button"
                      className="px-2.5 py-1.5 bg-[#0a66c2] hover:bg-[#004182] text-white font-semibold text-[10px] uppercase tracking-wider rounded transition duration-200 shadow-none cursor-pointer flex items-center gap-1"
                      title="Unduh CV Anda sebagai PDF Resmi"
                    >
                      <Download className="w-3.5 h-3.5 text-white" />
                      <span>Unduh PDF</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-medium text-slate-400 uppercase tracking-widest block font-inherit">Draf CV (Bisa Di-edit Secara Langsung):</span>
                  <textarea
                    className="w-full bg-white border border-slate-200 text-xs font-mono p-4 rounded text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#0a66c2] leading-relaxed shadow-none"
                    rows={12}
                    value={editableCv}
                    onChange={(e) => setEditableCv(e.target.value)}
                    placeholder="Draf teks CV sedang dimuat..."
                  />
                  <div className="flex items-start gap-1 text-[10px] text-slate-400 leading-normal font-inherit">
                    <span>💡</span>
                    <span><strong>Tips format:</strong> Teks berhuruf kapital penuh (UPPERCASE) otomatis akan digabungkan menjadi tajuk bab dengan garis batas pemisah saat dicetak ke dokumen PDF.</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
