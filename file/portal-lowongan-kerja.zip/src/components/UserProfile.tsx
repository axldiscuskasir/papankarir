import React, { useState, useEffect } from 'react';
import { 
  User, Mail, Phone, Linkedin, FileText, Sparkles, Plus, Trash2, 
  Coins, Scale, Trophy, GraduationCap, Briefcase, ChevronRight, 
  Send, HelpCircle, CheckCircle2, ShieldCheck, ArrowRight, CornerDownRight 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Profile interface definition
interface WorkExperience {
  id: string;
  company: string;
  position: string;
  duration: string;
  description: string;
}

interface EducationExperience {
  id: string;
  school: string;
  degree: string;
  year: string;
}

interface UserProfileData {
  fullName: string;
  title: string;
  email: string;
  phone: string;
  linkedin: string;
  summary: string;
  skills: string[];
  experience: WorkExperience[];
  education: EducationExperience[];
}

export default function UserProfile() {
  const [innerTab, setInnerTab] = useState<'profile' | 'salary' | 'coach'>('profile');
  
  // ----------------------------------------
  // 1. STATE: USER PROFILE & LOCAL STORAGE
  // ----------------------------------------
  const [profile, setProfile] = useState<UserProfileData>(() => {
    try {
      const stored = localStorage.getItem('papan_karir_user_profile');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.error(e);
    }
    // Default initial profile values
    return {
      fullName: 'Axl Discus',
      title: 'Full Stack Engineer',
      email: 'axldiscus@gmail.com',
      phone: '081234567890',
      linkedin: 'linkedin.com/in/axldiscus',
      summary: 'Spesialis pengembang aplikasi web dengan pengalaman merancang arsitektur full-stack, RESTful API, dan optimasi kecerdasan buatan. Berkeinginan tinggi menghasilkan kode bersih yang higienis serta performatif.',
      skills: ['React', 'TypeScript', 'Node.js', 'Express', 'Tailwind CSS', 'PostgreSQL', 'AI Prompting'],
      experience: [
        {
          id: 'exp-1',
          company: 'Solusi Teknologi Nusantara',
          position: 'Senior Frontend Developer',
          duration: 'Jan 2024 - Sekarang',
          description: 'Memimpin tim pengembang beranggotakan 4 orang dalam mengoptimalkan performa web hingga 35% lebih cepat serta merancang modul visual dasbor real-time.'
        },
        {
          id: 'exp-2',
          company: 'Mitra Cipta digital',
          position: 'Junior Software Engineer',
          duration: 'Jul 2022 - Des 2023',
          description: 'Mengembangkan komponen UI reusable berbasis React serta mengintegrasikan API pihak ketiga untuk otentikasi aman akun pengguna.'
        }
      ],
      education: [
        {
          id: 'edu-1',
          school: 'Universitas Indonesia',
          degree: 'Sarjana Ilmu Komputer',
          year: '2018 - 2022'
        }
      ]
    };
  });

  // Persist Profile to local storage
  useEffect(() => {
    localStorage.setItem('papan_karir_user_profile', JSON.stringify(profile));
    localStorage.setItem('cari_kerja_user_name', profile.fullName);
    localStorage.setItem('cari_kerja_user_email', profile.email);
    localStorage.setItem('cari_kerja_user_phone', profile.phone);
    localStorage.setItem('cari_kerja_user_linkedin', profile.linkedin);
    localStorage.setItem('cari_kerja_user_cv', profile.summary);
  }, [profile]);

  // Profile completeness score formula
  const calculateCompleteness = () => {
    let score = 0;
    if (profile.fullName.trim()) score += 15;
    if (profile.title.trim()) score += 10;
    if (profile.email.trim()) score += 10;
    if (profile.phone.trim()) score += 10;
    if (profile.linkedin.trim()) score += 10;
    if (profile.summary.trim()) score += 15;
    if (profile.skills.length > 0) score += 10;
    if (profile.experience.length > 0) score += 10;
    if (profile.education.length > 0) score += 10;
    return score;
  };

  const completeness = calculateCompleteness();

  // Dynamic Skills insertion
  const [newSkill, setNewSkill] = useState('');
  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newSkill.trim();
    if (clean && !profile.skills.includes(clean)) {
      setProfile(prev => ({
        ...prev,
        skills: [...prev.skills, clean]
      }));
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skill: string) => {
    setProfile(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skill)
    }));
  };

  // Dynamic Experience controls
  const [expCompany, setExpCompany] = useState('');
  const [expPosition, setExpPosition] = useState('');
  const [expDuration, setExpDuration] = useState('');
  const [expDesc, setExpDesc] = useState('');

  const handleAddExperience = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expCompany || !expPosition) return;
    const newItem: WorkExperience = {
      id: `exp-${Date.now()}`,
      company: expCompany,
      position: expPosition,
      duration: expDuration || 'Sekarang',
      description: expDesc
    };
    setProfile(prev => ({
      ...prev,
      experience: [newItem, ...prev.experience]
    }));
    setExpCompany('');
    setExpPosition('');
    setExpDuration('');
    setExpDesc('');
  };

  const handleRemoveExperience = (id: string) => {
    setProfile(prev => ({
      ...prev,
      experience: prev.experience.filter(item => item.id !== id)
    }));
  };

  // Dynamic Education controls
  const [eduSchool, setEduSchool] = useState('');
  const [eduDegree, setEduDegree] = useState('');
  const [eduYear, setEduYear] = useState('');

  const handleAddEducation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eduSchool || !eduDegree) return;
    const newItem: EducationExperience = {
      id: `edu-${Date.now()}`,
      school: eduSchool,
      degree: eduDegree,
      year: eduYear || 'Baru'
    };
    setProfile(prev => ({
      ...prev,
      education: [newItem, ...prev.education]
    }));
    setEduSchool('');
    setEduDegree('');
    setEduYear('');
  };

  const handleRemoveEducation = (id: string) => {
    setProfile(prev => ({
      ...prev,
      education: prev.education.filter(item => item.id !== id)
    }));
  };


  // ----------------------------------------
  // 2. STATE & LOGIC: SALARY INDONESIA & TAX CALCULATOR
  // ----------------------------------------
  const [grossSalary, setGrossSalary] = useState<number>(12000000); // 12jt default
  const [ptkpStatus, setPtkpStatus] = useState<string>('TK/0'); 
  const [includeJHT, setIncludeJHT] = useState(true);
  const [includeJP, setIncludeJP] = useState(true);
  const [includeBPJSKes, setIncludeBPJSKes] = useState(true);

  // PTKP (Penghasilan Tidak Kena Pajak) values per year
  const PTKP_VALUES: Record<string, { label: string; value: number }> = {
    'TK/0': { label: 'TK/0 - Lajang, Tanpa Tanggungan', value: 54000000 },
    'TK/1': { label: 'TK/1 - Lajang, 1 Tanggungan', value: 58500000 },
    'TK/2': { label: 'TK/2 - Lajang, 2 Tanggungan', value: 63000000 },
    'TK/3': { label: 'TK/3 - Lajang, 3 Tanggungan', value: 67500000 },
    'K/0': { label: 'K/0 - Menikah, Tanpa Tanggungan', value: 58500000 },
    'K/1': { label: 'K/1 - Menikah, 1 Tanggungan', value: 63000000 },
    'K/2': { label: 'K/2 - Menikah, 2 Tanggungan', value: 67500000 },
    'K/3': { label: 'K/3 - Menikah, 3 Tanggungan', value: 72000000 },
  };

  // Compute Indonesian Tax Breakdown
  const computePph21 = () => {
    const annualGross = grossSalary * 12;

    // BPJS Deductions (Employee contribution caps)
    // JHT (Jaminan Hari Tua): Employee 2.0%
    const jhtRate = includeJHT ? 0.02 : 0;
    const monthlyJht = grossSalary * jhtRate;

    // JP (Jaminan Pensiun): Employee 1.0% (capped at gross max salary cap, approx Rp 10.450.000 for 2026/latest standards)
    const jpMaxCap = 10450000;
    const jpRate = includeJP ? 0.01 : 0;
    const monthlyJp = Math.min(grossSalary, jpMaxCap) * jpRate;

    // BPJS Kesehatan: Employee 1.0% (capped at standard max wage, approx Rp 12.000.000)
    const kesMaxCap = 12000000;
    const kesRate = includeBPJSKes ? 0.01 : 0;
    const monthlyBPJSKes = Math.min(grossSalary, kesMaxCap) * kesRate;

    const totalMonthlyBPJS = monthlyJht + monthlyJp + monthlyBPJSKes;
    const annualBPJS = totalMonthlyBPJS * 12;

    // Biaya Jabatan (5% of Gross, capped at Rp 500,000 per month or Rp 6,000,000 per year)
    const monthlyPositionExpense = Math.min(grossSalary * 0.05, 500000);
    const annualPositionExpense = monthlyPositionExpense * 12;

    // Net Annual Income before PTKP
    const netAnnualIncome = annualGross - annualBPJS - annualPositionExpense;

    // PTKP Subtraction
    const ptkp = PTKP_VALUES[ptkpStatus]?.value || 54000000;
    const taxableAnnualIncome = Math.max(0, netAnnualIncome - ptkp);

    // Progressive tax brackets (UU HPP Indonesia standard)
    // - Up to Rp 60M: 5%
    // - Rp 60M to Rp 250M: 15%
    // - Rp 250M to Rp 500M: 25%
    // - Rp 500M to Rp 5B: 30%
    // - Above Rp 5B: 35%
    let calcTax = 0;
    let remaining = taxableAnnualIncome;

    if (remaining > 0) {
      const b1 = Math.min(remaining, 60000000);
      calcTax += b1 * 0.05;
      remaining -= b1;
    }
    if (remaining > 0) {
      const b2 = Math.min(remaining, 190000000); // 250 - 60
      calcTax += b2 * 0.15;
      remaining -= b2;
    }
    if (remaining > 0) {
      const b3 = Math.min(remaining, 250000000); // 500 - 250
      calcTax += b3 * 0.25;
      remaining -= b3;
    }
    if (remaining > 0) {
      const b4 = Math.min(remaining, 4500000000); // 5000 - 500
      calcTax += b4 * 0.30;
      remaining -= b4;
    }
    if (remaining > 0) {
      calcTax += remaining * 0.35;
    }

    const annualPph21 = calcTax;
    const monthlyPph21 = annualPph21 / 12;

    const netMonthlyTakeHomePay = grossSalary - totalMonthlyBPJS - monthlyPph21;

    return {
      monthlyJht,
      monthlyJp,
      monthlyBPJSKes,
      totalBPJS: totalMonthlyBPJS,
      biayaJabatan: monthlyPositionExpense,
      pkpPertahun: taxableAnnualIncome,
      pph21Annual: annualPph21,
      pph21Monthly: monthlyPph21,
      takeHomePay: netMonthlyTakeHomePay
    };
  };

  const taxDetails = computePph21();


  // ----------------------------------------
  // 3. STATE & LOGIC: AI CAREER COACH CHAT
  // ----------------------------------------
  const [messages, setMessages] = useState<Array<{ id: string; sender: 'user' | 'ai'; text: string }>>([
    {
      id: 'coach-init',
      sender: 'ai',
      text: 'Halo! Saya adalah **AI Career Coach** pribadi Anda. 🌟\n\nSaya di sini untuk membantu Anda mempersiapkan karir terbaik di Indonesia. Anda bisa menanyakan apa saja, mulailah dari strategi bernegosiasi gaji, beralih profesi (career switch), cara mengoptimasi profil agar lolos sistem ATS rekruter, atau cara menyiasati pertanyaan pewawancara sulit.\n\n_Pilih salah satu saran di bawah atau tulis pesan Anda sendiri!_'
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [coachLoading, setCoachLoading] = useState(false);

  const handleSendCoachMsg = async (textToSend: string) => {
    if (!textToSend.trim() || coachLoading) return;

    // Append user message
    const userMsg = {
      id: `u-${Date.now()}`,
      sender: 'user' as const,
      text: textToSend
    };
    setMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setCoachLoading(true);

    try {
      const response = await fetch('/api/ai/career-advice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: textToSend,
          history: messages.slice(-6) // Send recent turns for context
        })
      });

      if (!response.ok) {
        throw new Error('Server error');
      }

      const resData = await response.json();
      const aiResponse = {
        id: `ai-${Date.now()}`,
        sender: 'ai' as const,
        text: resData.reply || "Maaf, asisten karir sedang tidak responsif saat ini."
      };
      setMessages(prev => [...prev, aiResponse]);
    } catch (err) {
      console.error(err);
      const errResponse = {
        id: `ai-err-${Date.now()}`,
        sender: 'ai' as const,
        text: "Koneksi terputus. Silakan hubungkan Kunci API Gemini Anda di Secrets Panel untuk bimbingan AI real-time, atau pastikan jaringan internet Anda aktif."
      };
      setMessages(prev => [...prev, errResponse]);
    } finally {
      setCoachLoading(false);
    }
  };

  // Quick prompt suggestion actions
  const suggestionPrompts = [
    "Bagaimana strategi jitu negosiasi gaji di Indonesia?",
    "Saya mau Career Switch dari Admin ke IT. Mulai darimana?",
    "Bagaimana cara membuat CV agar 100% lolos sistem HRD ATS?",
    "Apa saja skill teknologi paling prospek tinggi di 2026?"
  ];

  // Lightweight markdown and newline renderer helper
  const parseMarkdownText = (text: string) => {
    // Escape simple html and handle newlines, bold, bullets
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      let trimmed = line.trim();
      
      // Check for bullet lists
      const isBullet = trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('• ');
      if (isBullet) {
        let content = trimmed.substring(2);
        // Bold replacement inside list
        content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        content = content.replace(/_(.*?)_/g, '<em>$1</em>');
        return (
          <li key={idx} className="ml-5 list-disc mb-1 text-slate-700 font-medium" 
              dangerouslySetInnerHTML={{ __html: content }} />
        );
      }
      
      // General paragraph formatting styles
      let htmlContent = line;
      // Replace bold markdown
      htmlContent = htmlContent.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      // Replace italic markdown
      htmlContent = htmlContent.replace(/_(.*?)_/g, '<em>$1</em>');

      if (!trimmed) {
        return <div key={idx} className="h-2" />;
      }
      
      return (
        <p key={idx} className="mb-2 leading-relaxed" 
           dangerouslySetInnerHTML={{ __html: htmlContent }} />
      );
    });
  };

  return (
    <div className="space-y-6 font-inherit">
      
      {/* Upper Tab Navigation Selector */}
      <div className="bg-white p-1 rounded-lg border border-[#e0e0e0] shadow-none max-w-2xl flex">
        <button
          onClick={() => setInnerTab('profile')}
          className={`flex-1 py-2 rounded text-xs font-semibold cursor-pointer transition-colors ${
            innerTab === 'profile' ? 'bg-[#0a66c2] text-white shadow-none' : 'text-slate-600 hover:text-slate-800'
          }`}
          id="profile-tab-btn-cv"
        >
          Profil & CV Digital
        </button>
        <button
          onClick={() => setInnerTab('salary')}
          className={`flex-1 py-2 rounded text-xs font-semibold cursor-pointer transition-colors ${
            innerTab === 'salary' ? 'bg-[#0a66c2] text-white shadow-none' : 'text-slate-600 hover:text-slate-800'
          }`}
          id="profile-tab-btn-sal"
        >
          Kalkulator Gaji & PPh 21
        </button>
        <button
          onClick={() => setInnerTab('coach')}
          className={`flex-1 py-2 rounded text-xs font-semibold cursor-pointer transition-colors ${
            innerTab === 'coach' ? 'bg-[#0a66c2] text-white shadow-none' : 'text-slate-600 hover:text-slate-800'
          }`}
          id="profile-tab-btn-coach"
        >
          AI Career Coach
        </button>
      </div>

      <AnimatePresence mode="wait">
        {/* TAB 1: USER PROFILE FORM & RESUME BUILDER */}
        {innerTab === 'profile' && (
          <motion.div
            key="profile-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-inherit"
          >
            {/* Left Column: Progress Meter & Profile Summary */}
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none text-center space-y-4">
                <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Kesiapan Berkas Melamar</h3>
                
                {/* Visual Circle Completeness Gauge */}
                <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90">
                    <circle cx="56" cy="56" r="48" className="stroke-slate-100 fill-none" strokeWidth="8"/>
                    <circle 
                      cx="56" 
                      cy="56" 
                      r="48" 
                      className="stroke-[#0a66c2] fill-none transition-all duration-500" 
                      strokeWidth="8"
                      strokeDasharray={2 * Math.PI * 48}
                      strokeDashoffset={2 * Math.PI * 48 * (1 - completeness / 100)}
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-bold text-slate-800 leading-tight">{completeness}%</span>
                    <span className="text-[9px] font-bold text-[#0a66c2] uppercase tracking-widest">Selesai</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <h4 className="text-sm font-semibold text-slate-800">{profile.fullName || 'Nama Lengkap'}</h4>
                  <p className="text-xs text-slate-400 font-medium">{profile.title || 'Pekerjaan Bidang Target'}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 text-left space-y-2.5 text-[11px] text-slate-500 font-medium">
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{profile.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{profile.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Linkedin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate text-[#0a66c2]">{profile.linkedin}</span>
                  </div>
                </div>

                {/* Status Advice Card */}
                <div className="bg-blue-50/40 p-3 rounded-lg text-left border border-blue-100/50 text-[10px] leading-relaxed text-slate-600">
                  <p className="font-semibold text-[#0a66c2] mb-0.5 uppercase tracking-widest">Tip AI:</p>
                  {completeness < 70 ? (
                    <span>Lengkapi data pekerjaan, pengalaman, dan keahlian Anda untuk mencapai skor 80% agar sistem AI HR memprioritaskan rekomendasi lamaran Anda.</span>
                  ) : (
                    <span>Profil Anda luar biasa! Data digital Anda sudah selaras untuk mendukung asisten AI melamar secara instan pada job feed kapan saja.</span>
                  )}
                </div>
              </div>

              {/* Dynamic Skills tagging zone */}
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Keahlian Saya ({profile.skills.length})</h3>
                  <span className="text-[10px] text-slate-400 font-bold">Kecakapan Teknis</span>
                </div>

                {/* Input action */}
                <form onSubmit={handleAddSkill} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Contoh: Python, SQL, Excel..."
                    className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0a66c2] text-xs font-medium text-slate-705 placeholder-slate-400"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                  />
                  <button 
                    type="submit" 
                    className="p-1 px-2.5 bg-[#0a66c2] hover:bg-[#004182] text-white text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah</span>
                  </button>
                </form>

                {/* Highlighted badges */}
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {profile.skills.length === 0 ? (
                    <span className="text-xs text-slate-400 italic">Belum ada keahlian ditambahkan.</span>
                  ) : (
                    profile.skills.map((skill) => (
                      <span 
                        key={skill} 
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 border border-slate-200 rounded-full text-xs font-semibold text-slate-700"
                      >
                        <span>{skill}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveSkill(skill)}
                          className="hover:text-rose-500 transition font-extrabold ml-0.5 text-slate-400 text-[10px]"
                        >
                          ×
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Right Column: Editable Resume Details Forms */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Profile Details Form section */}
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none space-y-5">
                <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider border-b border-slate-100 pb-2">Informasi Umum Profil</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-medium">
                  <div className="space-y-1">
                    <label htmlFor="p-name" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">Nama Lengkap</label>
                    <input
                      id="p-name"
                      type="text"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-800"
                      value={profile.fullName}
                      onChange={(e) => setProfile(prev => ({ ...prev, fullName: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="p-title" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">Pekerjaan/Spesialisasi</label>
                    <input
                      id="p-title"
                      type="text"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-800"
                      value={profile.title}
                      onChange={(e) => setProfile(prev => ({ ...prev, title: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="p-email" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">Email Registrasi</label>
                    <input
                      id="p-email"
                      type="email"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-800"
                      value={profile.email}
                      onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="p-phone" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">Nomor Kontak WhatsApp</label>
                    <input
                      id="p-phone"
                      type="text"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-800"
                      value={profile.phone}
                      onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label htmlFor="p-linkedin" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">URL Tautan LinkedIn</label>
                    <input
                      id="p-linkedin"
                      type="text"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-800"
                      value={profile.linkedin}
                      onChange={(e) => setProfile(prev => ({ ...prev, linkedin: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label htmlFor="p-summary" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">Surat Pengantar & Deskripsi Kualifikasi Ringkas (CV Digital)</label>
                    <textarea
                      id="p-summary"
                      rows={3}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a66c2] focus:bg-white text-xs text-slate-800 leading-relaxed"
                      value={profile.summary}
                      onChange={(e) => setProfile(prev => ({ ...prev, summary: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              {/* Dynamic Work Experience items mapping */}
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none space-y-6">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                  <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <Briefcase className="w-4 h-4 text-slate-400" />
                    <span>Riwayat Pengalaman Kerja</span>
                  </h3>
                  <span className="text-[10px] text-slate-400 font-bold">Karir Profesional</span>
                </div>

                {/* Mini Form inputs */}
                <form onSubmit={handleAddExperience} className="p-4 bg-slate-50 border border-slate-200 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-medium">
                  <div className="space-y-1">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Nama Perusahaan *</label>
                    <input
                      type="text"
                      placeholder="Contoh: PT Indonesia Makmur"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={expCompany}
                      onChange={(e) => setExpCompany(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Nama Jabatan / Posisi *</label>
                    <input
                      type="text"
                      placeholder="Contoh: Backend Admin"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={expPosition}
                      onChange={(e) => setExpPosition(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Masa Jabatan / Durasi</label>
                    <input
                      type="text"
                      placeholder="Contoh: 2023 - 2025"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={expDuration}
                      onChange={(e) => setExpDuration(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1 md:col-span-3">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Tanggung Jawab Utamamu</label>
                    <input
                      type="text"
                      placeholder="Ceritakan ringkas tugas dan pencapaian utamamu di kantor ini..."
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={expDesc}
                      onChange={(e) => setExpDesc(e.target.value)}
                    />
                  </div>
                  <div className="md:col-span-3 flex justify-end">
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-[#0a66c2] hover:bg-[#004182] text-white text-[11px] font-bold rounded transition flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambahkan Pekerjaan</span>
                    </button>
                  </div>
                </form>

                {/* Display list items with hover effects */}
                <div className="space-y-4 pt-1">
                  {profile.experience.length === 0 ? (
                    <p className="text-xs text-slate-400 italic text-center py-4">Belum ada pengalaman kerja tercantum.</p>
                  ) : (
                    profile.experience.map((exp, idx) => (
                      <div key={exp.id} className="relative flex gap-3 group">
                        {/* Connecting dot timeline */}
                        <div className="flex flex-col items-center">
                          <div className="w-2.5 h-2.5 rounded-full bg-[#0a66c2] border-2 border-white ring-4 ring-blue-50 shrink-0 mt-1" />
                          {idx !== profile.experience.length - 1 && (
                            <div className="w-0.5 h-full bg-slate-100 mt-1" />
                          )}
                        </div>

                        <div className="flex-1 bg-slate-50 p-3.5 rounded-lg border border-slate-150 flex items-start justify-between gap-4 hover:border-slate-300 transition">
                          <div className="text-xs space-y-1">
                            <h4 className="font-bold text-slate-900 leading-snug">{exp.position}</h4>
                            <p className="text-[11px] text-[#0a66c2] font-semibold uppercase tracking-wide leading-none">{exp.company}</p>
                            <p className="font-mono text-[9px] uppercase font-bold text-slate-400">{exp.duration}</p>
                            {exp.description && (
                              <p className="text-[11px] leading-relaxed text-slate-600 font-medium whitespace-pre-wrap pt-1">{exp.description}</p>
                            )}
                          </div>
                          
                          <button
                            onClick={() => handleRemoveExperience(exp.id)}
                            className="p-1.5 bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-250 text-slate-400 hover:text-rose-600 rounded transition shrink-0 cursor-pointer"
                            title="Hapus baris ini"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Dynamic Education mapping */}
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none space-y-6">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                  <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-[#0a66c2]" />
                    <span>Riwayat Pendidikan Resmi</span>
                  </h3>
                  <span className="text-[10px] text-slate-400 font-bold">Kualifikasi Akademis</span>
                </div>

                <form onSubmit={handleAddEducation} className="p-4 bg-slate-50 border border-slate-200 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-medium">
                  <div className="space-y-1">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Nama Sekolah / Universitas *</label>
                    <input
                      type="text"
                      placeholder="Contoh: Universitas Gadjah Mada"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={eduSchool}
                      onChange={(e) => setEduSchool(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Gelar / Jurusan *</label>
                    <input
                      type="text"
                      placeholder="Contoh: S1 Rekayasa Perangkat Lunak"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={eduDegree}
                      onChange={(e) => setEduDegree(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-slate-500 text-[10px] uppercase font-bold">Tahun Lulus / Angkatan</label>
                    <input
                      type="text"
                      placeholder="Contoh: 2019 - 2023"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-xs"
                      value={eduYear}
                      onChange={(e) => setEduYear(e.target.value)}
                    />
                  </div>
                  <div className="md:col-span-3 flex justify-end">
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-[#0a66c2] hover:bg-[#004182] text-white text-[11px] font-bold rounded transition flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambahkan Pendidikan</span>
                    </button>
                  </div>
                </form>

                <div className="space-y-3 pt-1">
                  {profile.education.length === 0 ? (
                    <p className="text-xs text-slate-400 italic text-center py-3">Belum ada riwayat akademis tercantum.</p>
                  ) : (
                    profile.education.map((edu) => (
                      <div key={edu.id} className="p-3.5 bg-slate-50 rounded-lg border border-slate-150 hover:border-slate-200 transition flex justify-between items-center text-xs">
                        <div className="space-y-0.5">
                          <h4 className="font-bold text-slate-800 leading-tight">{edu.degree}</h4>
                          <p className="font-medium text-slate-500">{edu.school}</p>
                          <p className="font-mono text-[9px] uppercase font-bold text-slate-400">{edu.year}</p>
                        </div>
                        <button
                          onClick={() => handleRemoveEducation(edu.id)}
                          className="p-1 px-2.5 bg-slate-50 hover:bg-rose-50 border border-slate-200 text-slate-400 hover:text-rose-600 rounded transition cursor-pointer"
                          title="Hapus baris"
                        >
                          Hapus
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          </motion.div>
        )}

        {/* TAB 2: INDONESIA SALARY & PPh 21 PROGRESSIVE TAX CALCULATOR */}
        {innerTab === 'salary' && (
          <motion.div
            key="salary-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="grid grid-cols-1 lg:grid-cols-5 gap-6 font-inherit"
          >
            {/* Left: Interactive Input Panel */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none space-y-5">
                <div className="flex items-center gap-1.5 border-b border-slate-100 pb-3">
                  <Coins className="w-5 h-5 text-[#0a66c2]" />
                  <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Simulasi Pendapatan Bersih (Take-Home-Pay)</h3>
                </div>

                {/* Slider bar for wage amount */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-500 uppercase tracking-widest text-[9px]">Gaji Kotor Bulanan (Gross)</span>
                    <span className="font-extrabold text-[#0a66c2] text-sm font-mono">Rp {grossSalary.toLocaleString('id-ID')}</span>
                  </div>
                  <input
                    type="range"
                    min={3500000}
                    max={50000000}
                    step={250000}
                    className="w-full accent-[#0a66c2] cursor-pointer h-2 bg-slate-100 rounded-lg"
                    value={grossSalary}
                    onChange={(e) => setGrossSalary(Number(e.target.value))}
                  />
                  <div className="flex justify-between text-[9px] font-mono font-bold text-slate-400">
                    <span>Rp 3,5 Juta</span>
                    <span>Rp 25 Juta</span>
                    <span>Rp 50 Juta</span>
                  </div>
                </div>

                {/* PTKP status selector */}
                <div className="space-y-1.5 font-medium">
                  <label htmlFor="select-ptkp" className="block text-slate-500 uppercase tracking-wider text-[9px] font-bold">Kategori PTKP Pajak (UU HPP Terkini)</label>
                  <select
                    id="select-ptkp"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0a66c2] text-xs text-slate-705 font-medium cursor-pointer"
                    value={ptkpStatus}
                    onChange={(e) => setPtkpStatus(e.target.value)}
                  >
                    {Object.entries(PTKP_VALUES).map(([key, item]) => (
                      <option key={key} value={key}>{item.label} (Peringanan setahun: Rp {(item.value).toLocaleString('id-ID')})</option>
                    ))}
                  </select>
                </div>

                {/* BPJS Checkboxes switches */}
                <div className="space-y-3 pt-2">
                  <h4 className="text-slate-500 uppercase tracking-wider text-[9px] font-bold">Iuran BPJS yang Dibayarkan Karyawan</h4>
                  
                  <div className="space-y-2 text-xs">
                    <label className="flex items-center gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        className="rounded border-slate-300 accent-[#0a66c2] w-4 h-4"
                        checked={includeJHT}
                        onChange={(e) => setIncludeJHT(e.target.checked)}
                      />
                      <span className="font-medium text-slate-700">BPJS Ketenagakerjaan JHT (2.0% dari gajimu)</span>
                    </label>

                    <label className="flex items-center gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        className="rounded border-slate-300 accent-[#0a66c2] w-4 h-4"
                        checked={includeJP}
                        onChange={(e) => setIncludeJP(e.target.checked)}
                      />
                      <span className="font-medium text-slate-700">BPJS Ketenagakerjaan JP Pensions (1.0% - batas gaji Rp 10.450.000)</span>
                    </label>

                    <label className="flex items-center gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        className="rounded border-slate-300 accent-[#0a66c2] w-4 h-4"
                        checked={includeBPJSKes}
                        onChange={(e) => setIncludeBPJSKes(e.target.checked)}
                      />
                      <span className="font-medium text-slate-700">BPJS Kesehatan (1.0% - batas gaji Rp 12.000.000)</span>
                    </label>
                  </div>
                </div>

                {/* Helpful information widget */}
                <div className="bg-slate-50 p-4 border border-slate-200 rounded-lg space-y-2 text-[11px] leading-relaxed text-slate-500 font-medium font-inherit">
                  <div className="flex items-center gap-1.5 text-slate-800 font-bold uppercase tracking-widest text-[9px]">
                    <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>Metodologi Perhitungan Resmi Pasca UU HPP</span>
                  </div>
                  <p>
                    Kalkulasi ini meniru proses penggajian riil tim HR di Indonesia. Menghitung BPJS Karyawan, Biaya Jabatan maksimal Rp 500ribu/bulan, Penghasilan Kena Pajak (PKP), dan menerapkan tarif progresif PPh 21 TER (Tarif Efektif Rata-Rata) & Progresif UU Pajak Harmonisasi Peraturan Perpajakan terkini.
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Calculation Breakdown Display Panel */}
            <div className="lg:col-span-3 space-y-6 font-inherit">
              <div className="bg-[#1d2226] border border-[#2d3236] text-white p-6 md:p-8 rounded-lg space-y-6 shadow-none font-inherit">
                
                {/* Outlining Take Home Pay clearly */}
                <div className="text-center space-y-1 md:space-y-1.5">
                  <p className="text-[10px] text-slate-300 uppercase tracking-widest font-semibold">Taksiran Gaji Bersih / Take Home Pay (Bulanan)</p>
                  <h2 className="text-2xl md:text-3.5xl font-extrabold text-white font-mono">
                    Rp {Math.round(taxDetails.takeHomePay).toLocaleString('id-ID')}
                  </h2>
                  <p className="text-slate-400 text-[10px] font-medium leading-none">
                    Atau sebesar {Math.round((taxDetails.takeHomePay / grossSalary) * 100)}% dari total pengupahan kotormu.
                  </p>
                </div>

                {/* Stacked breakdown visualize indicator */}
                <div className="space-y-1.5 font-inherit">
                  <p className="text-[9px] text-slate-300 uppercase tracking-widest font-semibold">Distribusi Anggaran Pendapatan Anda</p>
                  <div className="w-full h-3 rounded overflow-hidden flex bg-slate-800">
                    <div className="bg-emerald-500 h-full" style={{ width: `${(taxDetails.takeHomePay / grossSalary) * 100}%` }} title="Gaji Bersih" />
                    <div className="bg-amber-500 h-full" style={{ width: `${(taxDetails.totalBPJS / grossSalary) * 100}%` }} title="Iuran BPJS" />
                    <div className="bg-rose-500 h-full" style={{ width: `${(taxDetails.pph21Monthly / grossSalary) * 100}%` }} title="Pajak PPh 21" />
                  </div>
                  <div className="flex justify-between items-center text-[10px] font-semibold text-slate-300 pt-0.5">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-emerald-500 shrink-0"/> Bersih ({Math.round((taxDetails.takeHomePay / grossSalary) * 100)}%)</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-amber-500 shrink-0"/> BPJS ({Math.round((taxDetails.totalBPJS / grossSalary) * 100)}%)</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-rose-500 shrink-0"/> Pajak ({Math.round((taxDetails.pph21Monthly / grossSalary) * 100)}%)</span>
                  </div>
                </div>

                {/* Line Item Breakdown */}
                <div className="border-t border-slate-700 pt-4 space-y-3.5 text-xs font-inherit">
                  <div className="flex justify-between items-center text-slate-300">
                    <span>Gaji Bulanan Kotor (Gross)</span>
                    <span className="font-extrabold text-white">Rp {grossSalary.toLocaleString('id-ID')}</span>
                  </div>

                  <div className="collapse-item bg-white/5 border border-white/5 p-3 rounded-lg space-y-2 text-[11px] font-inherit">
                    <p className="font-semibold text-slate-305 uppercase tracking-wider text-[9px]">Pengurangan Bulanan:</p>
                    
                    <div className="flex justify-between text-slate-400">
                      <span>• Potongan BPJS JHT (2%)</span>
                      <span>Rp {Math.round(taxDetails.monthlyJht).toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>• Potongan BPJS JP (1%)</span>
                      <span>Rp {Math.round(taxDetails.monthlyJp).toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>• Potongan BPJS Kesehatan (1%)</span>
                      <span>Rp {Math.round(taxDetails.monthlyBPJSKes).toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-rose-350 font-semibold pt-1 border-t border-white/5">
                      <span>Total Biaya BPJS Pekerja</span>
                      <span>- Rp {Math.round(taxDetails.totalBPJS).toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-rose-350 font-semibold font-inherit">
                      <span>Pajak Bulanan PPh 21 Terhitung</span>
                      <span>- Rp {Math.round(taxDetails.pph21Monthly).toLocaleString('id-ID')}</span>
                    </div>
                  </div>

                  {/* Progressive detailed items */}
                  <div className="text-[10px] text-slate-400 font-medium space-y-1.5 leading-relaxed bg-black/25 p-3.5 rounded-lg font-inherit">
                    <p className="font-bold text-slate-300">DATA DETIL ESTIMASI SPT PERTAHUN:</p>
                    <div>• Tunjangan Biaya Jabatan (5% gross): Rp {Math.round(taxDetails.biayaJabatan * 12).toLocaleString('id-ID')} /tahun</div>
                    <div>• Pokok PTKP diringankan: Rp {PTKP_VALUES[ptkpStatus]?.value.toLocaleString('id-ID')} /tahun ({ptkpStatus})</div>
                    <div>• Penghasilan Kena Pajak (PKP): <strong className="text-blue-300">Rp {Math.round(taxDetails.pkpPertahun).toLocaleString('id-ID')}</strong> /tahun</div>
                    <div>• PPh 21 Tahunan Terutang: Rp {Math.round(taxDetails.pph21Annual).toLocaleString('id-ID')} /tahun</div>
                  </div>
                </div>

              </div>

              {/* Market comparison of standard wage sectors in Indonesia */}
              <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-none space-y-4">
                <h4 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Perbandingan Standar Gaji Sektoral Indonesia</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 border border-slate-100 bg-slate-50 rounded-lg space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <span>IT & Software dev</span>
                      <span className="text-[#0a66c2] font-mono">8jt - 35jt+/bln</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Kebutuhan tinggi spesialis Frontend, Backend, Data Scientist di Jakarta & BSD.</p>
                  </div>
                  <div className="p-3 border border-slate-100 bg-slate-50 rounded-lg space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <span>Digital Marketing</span>
                      <span className="text-[#0a66c2] font-mono">5jt - 18jt/bln</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Mencakup SEO, Copywriter, Social Media Specialist di agensi swasta.</p>
                  </div>
                  <div className="p-3 border border-slate-100 bg-slate-50 rounded-lg space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <span>Kreatif & Desain</span>
                      <span className="text-[#0a66c2] font-mono">4,5jt - 15jt/bln</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Desainer grafis, UI/UX, dan Video Editor di perusahaan rintisan.</p>
                  </div>
                  <div className="p-3 border border-slate-100 bg-slate-50 rounded-lg space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <span>Finansial / Akuntansi</span>
                      <span className="text-[#0a66c2] font-mono">5jt - 20jt/bln</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Auditor eksternal, analis keuangan, pembukuan pajak korporasi.</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* TAB 3: AI PERSONAL CAREER COACH ADVOCATE CHAT */}
        {innerTab === 'coach' && (
          <motion.div
            key="coach-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="grid grid-cols-1 lg:grid-cols-5 gap-6 font-inherit"
          >
            {/* Left side column: Chat dialogue board */}
            <div className="lg:col-span-3 flex flex-col h-[550px] bg-white rounded-lg border border-slate-200 shadow-none overflow-hidden font-inherit">
              
              {/* Box header indicator */}
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                  <div>
                    <h3 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Konseling Karir Gemini AI</h3>
                    <p className="text-[9px] text-[#0a66c2] font-bold tracking-widest uppercase">Mentor Karir Pribadi</p>
                  </div>
                </div>
                <HelpCircle className="w-4 h-4 text-slate-400" />
              </div>

              {/* Chat conversations scroll view */}
              <div className="flex-1 p-4 md:p-5 overflow-y-auto space-y-4">
                {messages.map((m) => (
                  <div 
                    key={m.id} 
                    className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-lg p-4 text-xs font-semibold ${
                      m.sender === 'user' 
                        ? 'bg-[#0a66c2] text-white rounded-tr-none' 
                        : 'bg-[#f3f2f0] border border-slate-200 text-slate-800 rounded-tl-none'
                    }`}>
                      {m.sender === 'ai' ? (
                        <div className="space-y-1.5 prose-sm text-slate-705">
                          {parseMarkdownText(m.text)}
                        </div>
                      ) : (
                        <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
                      )}
                    </div>
                  </div>
                ))}

                {coachLoading && (
                  <div className="flex justify-start">
                    <div className="bg-slate-100 border border-slate-200 rounded-lg p-4 text-xs text-slate-500 rounded-tl-none flex items-center gap-2 font-semibold">
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                      <span>Gemini Career Advisor sedang menyusun ulasan...</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Chat action box footer */}
              <div className="p-3 bg-slate-50 border-t border-slate-200 flex gap-2">
                <input
                  type="text"
                  placeholder="Tanyakan hal apa saja mengenai karir..."
                  className="flex-1 px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0a66c2] text-xs font-semibold text-slate-800 placeholder-slate-400"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendCoachMsg(chatInput)}
                  disabled={coachLoading}
                />
                <button
                  onClick={() => handleSendCoachMsg(chatInput)}
                  className="p-1 px-3 bg-[#0a66c2] hover:bg-[#004182] disabled:bg-slate-300 text-white rounded transition font-bold text-xs flex items-center justify-center shrink-0 cursor-pointer"
                  disabled={!chatInput.trim() || coachLoading}
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Right side column: Sidebar career resources advice */}
            <div className="lg:col-span-2 space-y-6 font-inherit">
              
              {/* Presets suggestions panel */}
              <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-none space-y-4">
                <div className="flex items-center gap-1.5 text-slate-805 font-bold">
                  <Sparkles className="w-4 h-4 text-[#0a66c2] shrink-0" />
                  <h4 className="text-slate-850 text-xs uppercase tracking-wider">Topik Bimbingan Karir Instan</h4>
                </div>
                <p className="text-[11px] text-slate-400 font-medium">Klik pada salah satu menu panduan taktis di bawah ini untuk memulai obrolan cerdas bersama AI Advisor kami:</p>
                
                <div className="flex flex-col gap-2">
                  {suggestionPrompts.map((p, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendCoachMsg(p)}
                      disabled={coachLoading}
                      className="px-3 py-2.5 bg-slate-50 hover:bg-[#f3f2f0] border border-slate-200 hover:border-[#0a66c2] rounded-lg text-left text-xs font-semibold text-slate-700 hover:text-[#0a66c2] transition duration-200 cursor-pointer disabled:bg-transparent"
                    >
                      <div className="flex items-start gap-1.5">
                        <CornerDownRight className="w-3.5 h-3.5 text-[#0a66c2] shrink-0 mt-0.5" />
                        <span>{p}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Career Checklist Widget */}
              <div className="bg-gradient-to-tr from-[#f3f2f0] to-[#eef3f8] p-5 rounded-lg border border-slate-200 space-y-3">
                <h4 className="font-extrabold text-slate-850 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Trophy className="w-4 h-4 text-[#0a66c2]" />
                  <span>Cek Kelayakan Melamar Pekerjaan</span>
                </h4>
                <div className="space-y-2 text-[11px] font-semibold leading-relaxed text-slate-600">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#0a66c2]" />
                    <span>Lolos Seleksi Administrasi ATS</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#0a66c2]" />
                    <span>Riset standar gaji regional</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#0a66c2]" />
                    <span>Praktik Wawancara AI minimum 4 Pertanyaan</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#0a66c2]" />
                    <span>Mentalitas berkembang & siap belajar</span>
                  </div>
                </div>
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
