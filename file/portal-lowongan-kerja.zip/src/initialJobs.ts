import { Job } from './types';

export const INITIAL_JOBS: Job[] = [
  {
    id: "job-1",
    title: "Senior Frontend Engineer (React/TypeScript)",
    company: "TokoIjo Internasional",
    logo: "Monitor",
    logoBg: "bg-emerald-100 text-emerald-600",
    location: "Jakarta Barat (Hybrid)",
    type: "Full-Time",
    category: "Software Engineering",
    salary: "Rp 16.000.000 - Rp 24.000.000",
    postedAt: "1 hari yang lalu",
    description: "Kami sedang mencari Senior Frontend Engineer yang berpengalaman dalam membangun aplikasi web skala besar menggunakan React, TypeScript, dan Tailwind CSS. Anda bertanggung jawab merancang arsitektur web yang efisien, responsif, dan mudah dipelihara.",
    requirements: [
      "Pengalaman kerja minimal 4 tahun di bidang pengembangan Frontend.",
      "Keahlian mendalam dalam React.js, TypeScript, dan modern state management (Zustand/Redux).",
      "Memahami responsive design, optimasi performa web, dan integrasi API RESTful.",
      "Memiliki portofolio aplikasi web yang interaktif dan berkinerja tinggi."
    ],
    benefits: [
      "Gaji kompetitif & Bonus performa tahunan.",
      "Asuransi kesehatan swasta kelas satu.",
      "Tunjangan kerja remote & fasilitas penunjang (Laptop MacBook Pro).",
      "Jam kerja fleksibel & peluang jenjang karir yang jelas."
    ],
    isFeatured: true
  },
  {
    id: "job-2",
    title: "UI/UX Designer",
    company: "GojekHub Nusantara",
    logo: "Palette",
    logoBg: "bg-purple-100 text-purple-600",
    location: "Jakarta Selatan (On-site)",
    type: "Full-Time",
    category: "Desain & Kreatif",
    salary: "Rp 11.000.000 - Rp 16.000.000",
    postedAt: "2 hari yang lalu",
    description: "Bergabunglah dengan tim desain kami untuk menciptakan rancangan antarmuka pengguna (UI/UX) terbaik yang akan digunakan oleh jutaan orang di Indonesia. Anda akan berkolaborasi erat dengan tim produk dan teknik dalam merancang alur pengguna, wireframe, hingga visual design resolusi tinggi.",
    requirements: [
      "Minimal 2 tahun pengalaman bekerja sebagai UI/UX Designer.",
      "Mahir menggunakan Figma, Adobe XD, atau aplikasi desain industri sejenis.",
      "Memiliki kepedulian tinggi terhadap detail visual, tipografi, konsistensi layout, dan kepuasan pengguna.",
      "Mampu melakukan User Research & Usability Testing sederhananya."
    ],
    benefits: [
      "Fasilitas kantor yang modern dan lengkap (Snack gratis, ruang gim).",
      "Asuransi kesehatan + BPJS Lengkap.",
      "Tunjangan peningkatan skill (kursus berbayar / sertifikasi)."
    ],
    isFeatured: true
  },
  {
    id: "job-3",
    title: "Social Media Specialist",
    company: "Kopi Kenangan Manis",
    logo: "Share2",
    logoBg: "bg-pink-100 text-pink-600",
    location: "Bandung (Remote)",
    type: "Remote",
    category: "Pemasaran & Konten",
    salary: "Rp 6.500.000 - Rp 9.000.000",
    postedAt: "3 hari yang lalu",
    description: "Mencari individu kreatif yang antusias untuk mengelola dan membesarkan akun media sosial kami di TikTok, Instagram, dan Twitter. Anda bertugas membuat strategi konten tahunan, menulis salinan promosi, dan berinteraksi langsung dengan pelanggan setia kami secara online.",
    requirements: [
      "Minimal 1 tahun pengalaman di posisi Social Media Marketing / Pembuat Konten.",
      "Memahami tren TikTok & Instagram Reels saat ini.",
      "Mampu mengedit video pendek dasar menggunakan CapCut / Premiere Pro.",
      "Memiliki kemampuan menulis copywriting yang persuatif dalam Bahasa Indonesia."
    ],
    benefits: [
      "Kerja 100% remote tanpa harus datang ke kantor Bandung.",
      "Gratis kuota kopi spesial harian.",
      "Bonus bulanan berdasarkan pencapaian engagement rate media sosial."
    ],
    isFeatured: false
  },
  {
    id: "job-4",
    title: "Data Analyst",
    company: "SatuData Finansial",
    logo: "BarChart3",
    logoBg: "bg-blue-100 text-blue-600",
    location: "Surabaya (Hybrid)",
    type: "Part-Time",
    category: "Data & AI",
    salary: "Rp 7.000.000 - Rp 11.000.000",
    postedAt: "5 hari yang lalu",
    description: "Kami mencari Data Analyst paruh waktu untuk membantu menerjemahkan data transaksi harian kami menjadi insights strategis bagi tim bisnis. Anda akan membuat dashboard visualisasi data interaktif dan merangkum tren perkembangan per kuartal.",
    requirements: [
      "Mampu menggunakan SQL untuk penarikan data secara mandiri.",
      "Mahir dalam visualisasi data menggunakan Tableau, Power BI, atau Google Looker Studio.",
      "Kemampuan analisis masalah yang logis & mampu mengkomunikasikan hasil data teknis dengan bahasa yang sederhana.",
      "Latar belakang pendidikan di Statistika / Matematika / Ilmu Komputer lebih diutamakan."
    ],
    benefits: [
      "Waktu kerja fleksibel (minimal 20 jam per minggu).",
      "Kesempatan diangkat menjadi karyawan penuh waktu jika performa memuaskan.",
      "Tunjangan internet bulanan."
    ],
    isFeatured: false
  },
  {
    id: "job-5",
    title: "Customer Success Officer",
    company: "Bhinneka E-Commerce",
    logo: "Users",
    logoBg: "bg-amber-100 text-amber-600",
    location: "Surabaya (On-site)",
    type: "Kontrak",
    category: "Layanan Pelanggan",
    salary: "Rp 5.200.000 - Rp 6.800.000",
    postedAt: "5 hari yang lalu",
    description: "Anda akan menjadi garda terdepan kami dalam melayani pelanggan dengan ramah, menjawab komplain produk, merespon obrolan keluhan, serta membantu pengguna menyelesaikan pemesanan mereka melalui live-chat.",
    requirements: [
      "Pendidikan minimal Diploma atau SMA sederajat dengan kualifikasi komunikasi baik.",
      "Memiliki kesabaran tinggi, orientasi solusi terhadap kepuasan pelanggan.",
      "Lancar mengetik cepat dengan akurasi tinggi dan Bahasa Indonesia formal.",
      "Bersedia bekerja dalam sistem shift mingguan."
    ],
    benefits: [
      "Gaji pokok kompetitif di atas UMR regional.",
      "Insentif performa CS bulanan.",
      "Pelatihan komunikasi profesional bersertifikat gratis dari perusahaan."
    ],
    isFeatured: false
  },
  {
    id: "job-6",
    title: "Internship Backend Developer (Node.js)",
    company: "PintarTech Edukasi",
    logo: "Terminal",
    logoBg: "bg-orange-100 text-orange-600",
    location: "Yogyakarta (Hybrid)",
    type: "Internship",
    category: "Software Engineering",
    salary: "Rp 2.500.000 - Rp 4.000.000",
    postedAt: "6 hari yang lalu",
    description: "Program magang intensif selama 6 bulan untuk Backend Developer berbakat. Di sini Anda akan dibimbing langsung oleh tim Tech Lead kami dalam mengembangkan sistem REST API menggunakan Node.js (Express), MongoDB, dan Redis.",
    requirements: [
      "Mahasiswa tingkat akhir atau baru lulus dari Sistem Informasi / Teknik Informatika.",
      "Memahami dasar-dasar pemrograman JavaScript/TypeScript serta konsep penulisan REST API.",
      "Pernah membuat proyek backend sederhana (menjadi nilai tambah).",
      "Kemauan belajar yang tinggi dan mampu bekerja sama dalam tim agile."
    ],
    benefits: [
      "Uang saku bulanan kompetitif.",
      "Mentoring langsung oleh Senior Developer berpengalaman.",
      "Sertifikat Magang Resmi & Peluang direkrut penuh waktu setelah evaluasi."
    ],
    isFeatured: false
  }
];
