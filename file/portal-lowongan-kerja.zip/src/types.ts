export interface Job {
  id: string;
  title: string;
  company: string;
  logo: string; // Icon name from lucide-react or initial
  logoBg: string; // Tailwind color class e.g. 'bg-blue-100 text-blue-600'
  location: string;
  type: 'Full-Time' | 'Part-Time' | 'Kontrak' | 'Internship' | 'Remote';
  category: string;
  salary: string;
  postedAt: string;
  description: string;
  requirements: string[]; // List of expectations
  benefits: string[]; // Perks of the job
  isFeatured?: boolean;
}

export interface JobApplication {
  id: string;
  jobId: string;
  jobTitle: string;
  companyName: string;
  candidateName: string;
  candidateEmail: string;
  candidatePhone: string;
  linkedinUrl?: string;
  cvText: string;
  coverLetter: string;
  status: 'Terkirim' | 'Review' | 'Wawancara' | 'Diterima' | 'Ditolak';
  appliedAt: string;
  aiAnalysis?: {
    score: number; // 0-100
    fitLevel: 'Sangat Cocok' | 'Cukup Cocok' | 'Kurang Cocok';
    summary: string;
    strengths: string[];
    gaps: string[];
    tips: string[];
  };
}

export interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

export interface InterviewSession {
  id: string;
  jobId: string;
  jobTitle: string;
  companyName: string;
  candidateName: string;
  messages: Message[];
  status: 'active' | 'completed';
  feedback?: {
    score: number;
    evaluation: string;
    tips: string[];
  };
}

export interface FeedComment {
  id: string;
  authorName: string;
  authorTitle: string;
  content: string;
  createdAt: string;
}

export interface FeedPost {
  id: string;
  authorName: string;
  authorTitle: string;
  authorRole: 'kandidat' | 'rekruter' | 'sistem';
  type: 'status_update' | 'career_advice' | 'company_culture';
  title?: string; // Optional title for articles or major updates
  content: string;
  likes: string[]; // List of user names/emails who liked this post
  comments: FeedComment[];
  createdAt: string;
  tag?: string; // e.g. '#TipsKarir', '#BudayaKerja', '#'
}

